import * as zip from '@zip.js/zip.js';
import type { PageRef } from '../types/ebookfy';
import { getBinaryBlob } from './db';

const MAX_OBJECT_URLS = 28;
const urlCache = new Map<string, string>();
const inFlight = new Map<string, Promise<string>>();

interface ArchiveSession {
  reader: zip.ZipReader<Blob>;
  entriesByPath: Map<string, zip.Entry>;
}

const archiveSessions = new Map<string, Promise<ArchiveSession>>();

async function getArchiveSession(archiveBlobKey: string): Promise<ArchiveSession | null> {
  const existing = archiveSessions.get(archiveBlobKey);
  if (existing) return existing;

  const promise = (async () => {
    const blob = await getBinaryBlob(archiveBlobKey);
    if (!blob) throw new Error('Arquivo local não encontrado.');
    const reader = new zip.ZipReader(new zip.BlobReader(blob));
    const entries = await reader.getEntries();
    const entriesByPath = new Map<string, zip.Entry>();
    for (const entry of entries) {
      entriesByPath.set(entry.filename, entry);
    }
    return { reader, entriesByPath };
  })();

  archiveSessions.set(archiveBlobKey, promise);
  try {
    return await promise;
  } catch {
    archiveSessions.delete(archiveBlobKey);
    return null;
  }
}

function touchLru(cacheKey: string, url: string) {
  if (urlCache.has(cacheKey)) {
    urlCache.delete(cacheKey);
  }
  urlCache.set(cacheKey, url);

  if (urlCache.size > MAX_OBJECT_URLS) {
    const oldestKey = urlCache.keys().next().value;
    if (oldestKey) {
      const oldUrl = urlCache.get(oldestKey);
      urlCache.delete(oldestKey);
      if (oldUrl && oldUrl.startsWith('blob:')) {
        URL.revokeObjectURL(oldUrl);
      }
    }
  }
}

export async function loadPageImageUrl(page: PageRef): Promise<string> {
  if (page.inlineUrl) return page.inlineUrl;

  const cacheKey = page.id;
  const cached = urlCache.get(cacheKey);
  if (cached) {
    touchLru(cacheKey, cached);
    return cached;
  }

  const pending = inFlight.get(cacheKey);
  if (pending) return pending;

  const task = (async () => {
    if (page.blobKey) {
      const blob = await getBinaryBlob(page.blobKey);
      if (!blob) throw new Error(`Imagem não encontrada: ${page.name}`);
      const url = URL.createObjectURL(blob);
      touchLru(cacheKey, url);
      return url;
    }

    if (page.archiveBlobKey && page.entryPath) {
      const session = await getArchiveSession(page.archiveBlobKey);
      if (!session) throw new Error('Arquivo compactado indisponível.');
      const entry = session.entriesByPath.get(page.entryPath);
      if (!entry || !('getData' in entry) || !entry.getData) {
        throw new Error(`Página não encontrada no arquivo: ${page.entryPath}`);
      }
      const rawBlob = await entry.getData(new zip.BlobWriter(page.mimeType));
      const url = URL.createObjectURL(rawBlob);
      touchLru(cacheKey, url);
      return url;
    }

    throw new Error('Fonte da página não configurada.');
  })();

  inFlight.set(cacheKey, task);
  try {
    return await task;
  } finally {
    inFlight.delete(cacheKey);
  }
}

export function clearPageUrlCache(): void {
  for (const url of urlCache.values()) {
    if (url.startsWith('blob:')) URL.revokeObjectURL(url);
  }
  urlCache.clear();
  for (const sessionPromise of archiveSessions.values()) {
    sessionPromise.then((s) => s.reader.close().catch(() => {})).catch(() => {});
  }
  archiveSessions.clear();
}
