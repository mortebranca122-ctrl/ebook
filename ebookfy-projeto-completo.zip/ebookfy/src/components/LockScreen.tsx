import React, { useState } from 'react';
import { Lock } from 'lucide-react';
import type { SecuritySettings } from '../types/ebookfy';
import { sha256Text, verifyPassword } from '../utils/crypto';
import { RoseEmblem } from './RoseEmblem';

interface LockScreenProps {
  security: SecuritySettings;
  onUnlock: () => void;
  onDisableViaRecovery: () => void;
}

export const LockScreen: React.FC<LockScreenProps> = ({
  security,
  onUnlock,
  onDisableViaRecovery,
}) => {
  const [input, setInput] = useState('');
  const [recoveryMode, setRecoveryMode] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (recoveryMode) {
      if (!security.recoveryCodeHash) {
        setError('Nenhum código de recuperação configurado.');
        return;
      }
      const hashed = await sha256Text(input.trim().toUpperCase());
      if (hashed === security.recoveryCodeHash) {
        onDisableViaRecovery();
        onUnlock();
      } else {
        setError('Código de recuperação inválido.');
      }
      return;
    }

    if (!security.passwordHash || !security.passwordSalt) {
      onUnlock();
      return;
    }

    const ok = await verifyPassword(input, security.passwordSalt, security.passwordHash);
    if (ok) {
      setInput('');
      onUnlock();
    } else {
      setError('Senha incorreta.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#070406] flex items-center justify-center p-4">
      <form onSubmit={handleSubmit} className="eb-surface w-full max-w-sm p-6 space-y-5 text-center">
        <div className="flex flex-col items-center">
          <RoseEmblem className="w-12 h-12 mb-2" />
          <h1 className="font-display-serif italic text-3xl font-semibold text-white">Ebookfy</h1>
          <p className="text-xs text-[#bfa9b0] mt-1">
            {recoveryMode ? 'Recuperação local de acesso' : 'Biblioteca protegida por senha'}
          </p>
        </div>

        <div className="text-left space-y-1.5">
          <label htmlFor="ebookfy-lock-input" className="text-xs text-[#bfa9b0] block">
            {recoveryMode ? 'Código de recuperação (XXXX-XXXX-XXXX)' : 'Digite sua senha'}
          </label>
          <input
            id="ebookfy-lock-input"
            type={recoveryMode ? 'text' : 'password'}
            autoFocus
            value={input}
            onChange={(e) => setInput(e.target.value)}
            className="w-full px-3.5 py-2.5 rounded-xl bg-black/60 border border-red-900/50 text-sm text-white focus:outline-none focus:border-red-500"
          />
        </div>

        {error && <p className="text-xs text-red-400">{error}</p>}

        <button
          type="submit"
          className="w-full eb-accent-btn py-2.5 rounded-xl text-sm font-semibold inline-flex items-center justify-center gap-2 cursor-pointer"
        >
          <Lock className="w-4 h-4" />
          <span>{recoveryMode ? 'Recuperar acesso' : 'Desbloquear'}</span>
        </button>

        {security.recoveryCodeHash && (
          <button
            type="button"
            onClick={() => {
              setRecoveryMode((m) => !m);
              setInput('');
              setError(null);
            }}
            className="text-xs text-[#9d8189] hover:text-red-300 cursor-pointer"
          >
            {recoveryMode ? 'Voltar para senha' : 'Usar código de recuperação local'}
          </button>
        )}
      </form>
    </div>
  );
};
