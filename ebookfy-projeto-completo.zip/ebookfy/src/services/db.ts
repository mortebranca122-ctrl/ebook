import type {
  Collection,
  HistoryEntry,
  ReaderSettings,
  ReadingProgress,
  SecuritySettings,
  ThemeSettings,
  Work,
} from '../types/ebookfy';

const DB_NAME = 'ebookfy_local_db';
const DB_VERSION = 1;

export const DEFAULT_THEME_SETTINGS: ThemeSettings = {
  preset: 'dark-romance',
  primaryColor: '#c81e2b',
  secondaryColor: '#881322',
  canvasBg: '#070406',
  surfaceAlpha: 0.9,
  blurIntensity: 14,
  borderRadius: 14,
  wallpaperDataUrl: null,
  enableAnimations: true,
  libraryViewMode: 'grid',
};

export const DEFAULT_READER_SETTINGS: ReaderSettings = {
  bookTheme: 'dark',
  bookFontFamily: 'serif',
  bookFontSize: 19,
  bookLineHeight: 1.75,
  bookMarginPx: 32,
  bookTextAlign: 'left',
  imageBgMode: 'pure-black',
  mangaDirection: 'rtl',
  mangaPageLayout: 'single',
  imageFitMode: 'width',
  webtoonGapPx: 0,
  webtoonMaxWidthPx: 820,
  preloadCount: 3,
  autoHideControlsMs: 3200,
  pdfTheme: 'dark',
};

export const DEFAULT_SECURITY_SETTINGS: SecuritySettings = {
  lockEnabled: false,
  passwordHash: null,
  passwordSalt: null,
  recoveryCodeHash: null,
  inactivityMinutes: 0,
  lockOnMinimize: false,
};

let dbPromise: Promise<IDBDatabase> | null = null;

function openDB(): Promise<IDBDatabase> {
  if (dbPromise) return dbPromise;
  dbPromise = new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains('works')) {
        db.createObjectStore('works', { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains('progress')) {
        db.createObjectStore('progress', { keyPath: 'workId' });
      }
      if (!db.objectStoreNames.contains('collections')) {
        db.createObjectStore('collections', { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains('history')) {
        db.createObjectStore('history', { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains('settings')) {
        db.createObjectStore('settings', { keyPath: 'key' });
      }
      if (!db.objectStoreNames.contains('blobs')) {
        db.createObjectStore('blobs', { keyPath: 'key' });
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
  return dbPromise;
}

function idbReq<T>(req: IDBRequest<T>): Promise<T> {
  return new Promise((resolve, reject) => {
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

async function getAllFromStore<T>(storeName: string): Promise<T[]> {
  const db = await openDB();
  const tx = db.transaction(storeName, 'readonly');
  return idbReq(tx.objectStore(storeName).getAll());
}

async function putInStore<T>(storeName: string, value: T): Promise<void> {
  const db = await openDB();
  const tx = db.transaction(storeName, 'readwrite');
  await idbReq(tx.objectStore(storeName).put(value));
}

async function deleteFromStore(storeName: string, key: IDBValidKey): Promise<void> {
  const db = await openDB();
  const tx = db.transaction(storeName, 'readwrite');
  await idbReq(tx.objectStore(storeName).delete(key));
}

async function clearStore(storeName: string): Promise<void> {
  const db = await openDB();
  const tx = db.transaction(storeName, 'readwrite');
  await idbReq(tx.objectStore(storeName).clear());
}

// --- Works ---
export async function getAllWorks(): Promise<Work[]> {
  const list = await getAllFromStore<Work>('works');
  return list.sort((a, b) => (b.lastReadAt ?? b.updatedAt) - (a.lastReadAt ?? a.updatedAt));
}

export async function saveWork(work: Work): Promise<void> {
  await putInStore('works', work);
}

export async function deleteWork(workId: string): Promise<void> {
  await deleteFromStore('works', workId);
  await deleteFromStore('progress', workId);
}

// --- Progress ---
export async function getAllProgress(): Promise<ReadingProgress[]> {
  return getAllFromStore<ReadingProgress>('progress');
}

export async function saveProgress(progress: ReadingProgress): Promise<void> {
  await putInStore('progress', progress);
}

// --- Collections ---
export async function getAllCollections(): Promise<Collection[]> {
  const list = await getAllFromStore<Collection>('collections');
  return list.sort((a, b) => b.createdAt - a.createdAt);
}

export async function saveCollection(col: Collection): Promise<void> {
  await putInStore('collections', col);
}

export async function deleteCollection(id: string): Promise<void> {
  await deleteFromStore('collections', id);
}

// --- History ---
export async function getAllHistory(): Promise<HistoryEntry[]> {
  const list = await getAllFromStore<HistoryEntry>('history');
  return list.sort((a, b) => b.timestamp - a.timestamp);
}

export async function addHistoryEntry(entry: HistoryEntry): Promise<void> {
  await putInStore('history', entry);
}

export async function clearHistory(): Promise<void> {
  await clearStore('history');
}

// --- Settings ---
export async function getSetting<T>(key: string, fallback: T): Promise<T> {
  const db = await openDB();
  const tx = db.transaction('settings', 'readonly');
  const res = await idbReq<{ key: string; value: T } | undefined>(tx.objectStore('settings').get(key));
  return res ? res.value : fallback;
}

export async function saveSetting<T>(key: string, value: T): Promise<void> {
  await putInStore('settings', { key, value });
}

// --- Binary Blob Storage (OPFS for large multi-GB files + IndexedDB fallback) ---
const OPFS_PREFIX = 'opfs:';

function sanitizeOpfsFilename(key: string): string {
  return key.replace(/[^a-zA-Z0-9._-]/g, '_');
}

async function getOpfsRoot(): Promise<FileSystemDirectoryHandle | null> {
  try {
    if (typeof navigator !== 'undefined' && navigator.storage && 'getDirectory' in navigator.storage) {
      return await navigator.storage.getDirectory();
    }
  } catch {
    // Fallback to IndexedDB
  }
  return null;
}

/**
 * Stores a File or Blob locally without memory spikes.
 * Uses OPFS streaming for files > 8 MB when supported, with IndexedDB fallback.
 */
export async function storeBinaryBlob(key: string, blob: Blob): Promise<string> {
  if (blob.size > 8 * 1024 * 1024) {
    const root = await getOpfsRoot();
    if (root) {
      try {
        const safeName = sanitizeOpfsFilename(key);
        const handle = await root.getFileHandle(safeName, { create: true });
        if ('createWritable' in handle) {
          const writable = await handle.createWritable();
          await blob.stream().pipeTo(writable);
          return `${OPFS_PREFIX}${safeName}`;
        }
      } catch {
        // Fallback to IndexedDB below
      }
    }
  }
  await putInStore('blobs', { key, blob, size: blob.size, updatedAt: Date.now() });
  return key;
}

export async function getBinaryBlob(storageKey: string): Promise<Blob | null> {
  if (!storageKey) return null;
  if (storageKey.startsWith(OPFS_PREFIX)) {
    const root = await getOpfsRoot();
    if (root) {
      try {
        const safeName = storageKey.slice(OPFS_PREFIX.length);
        const handle = await root.getFileHandle(safeName);
        return await handle.getFile();
      } catch {
        return null;
      }
    }
    return null;
  }
  const db = await openDB();
  const tx = db.transaction('blobs', 'readonly');
  const rec = await idbReq<{ key: string; blob: Blob } | undefined>(
    tx.objectStore('blobs').get(storageKey)
  );
  return rec?.blob ?? null;
}

export async function deleteBinaryBlob(storageKey: string): Promise<void> {
  if (!storageKey) return;
  if (storageKey.startsWith(OPFS_PREFIX)) {
    const root = await getOpfsRoot();
    if (root) {
      try {
        await root.removeEntry(storageKey.slice(OPFS_PREFIX.length));
      } catch {
        // ignore missing
      }
    }
    return;
  }
  await deleteFromStore('blobs', storageKey);
}

export async function getAllStoredBlobStats(): Promise<{
  totalBytes: number;
  count: number;
  keys: Array<{ key: string; size: number }>;
}> {
  const keys: Array<{ key: string; size: number }> = [];
  let totalBytes = 0;

  const db = await openDB();
  const tx = db.transaction('blobs', 'readonly');
  const idbEntries = await idbReq<Array<{ key: string; size?: number; blob?: Blob }>>(
    tx.objectStore('blobs').getAll()
  );
  for (const item of idbEntries) {
    const size = item.size ?? item.blob?.size ?? 0;
    totalBytes += size;
    keys.push({ key: item.key, size });
  }

  const root = await getOpfsRoot();
  if (root && 'entries' in root) {
    try {
      const iter = (root as unknown as { entries: () => AsyncIterable<[string, FileSystemHandle]> }).entries();
      for await (const [name, handle] of iter) {
        if (handle.kind === 'file') {
          const f = await (handle as FileSystemFileHandle).getFile();
          totalBytes += f.size;
          keys.push({ key: `${OPFS_PREFIX}${name}`, size: f.size });
        }
      }
    } catch {
      // ignore OPFS iteration errors
    }
  }

  return { totalBytes, count: keys.length, keys };
}

export async function clearAllAppData(): Promise<void> {
  await Promise.all([
    clearStore('works'),
    clearStore('progress'),
    clearStore('collections'),
    clearStore('history'),
    clearStore('blobs'),
  ]);
  const root = await getOpfsRoot();
  if (root && 'entries' in root) {
    try {
      const iter = (root as unknown as { entries: () => AsyncIterable<[string, FileSystemHandle]> }).entries();
      for await (const [name] of iter) {
        await root.removeEntry(name);
      }
    } catch {
      // ignore
    }
  }
}
