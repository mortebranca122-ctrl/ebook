import React from 'react';
import {
  BookOpen,
  Clock,
  Download,
  FolderHeart,
  HardDrive,
  Heart,
  Home,
  Palette,
  Settings,
  Shield,
  ArchiveRestore,
} from 'lucide-react';
import type { NavSection } from '../types/ebookfy';
import { RoseEmblem } from './RoseEmblem';

interface SidebarProps {
  activeSection: NavSection;
  onSelect: (section: NavSection) => void;
}

const PRIMARY_ITEMS: Array<{ id: NavSection; label: string; icon: React.ComponentType<{ className?: string }> }> = [
  { id: 'inicio', label: 'Início', icon: Home },
  { id: 'biblioteca', label: 'Biblioteca', icon: BookOpen },
  { id: 'favoritos', label: 'Favoritos', icon: Heart },
  { id: 'historico', label: 'Histórico', icon: Clock },
  { id: 'colecoes', label: 'Coleções', icon: FolderHeart },
];

const SECONDARY_ITEMS: Array<{ id: NavSection; label: string; icon: React.ComponentType<{ className?: string }> }> = [
  { id: 'importar', label: 'Importar', icon: Download },
  { id: 'armazenamento', label: 'Armazenamento', icon: HardDrive },
  { id: 'backup', label: 'Backup & Restore', icon: ArchiveRestore },
  { id: 'personalizacao', label: 'Personalização', icon: Palette },
  { id: 'seguranca', label: 'Segurança', icon: Shield },
  { id: 'configuracoes', label: 'Configurações', icon: Settings },
];

export const Sidebar: React.FC<SidebarProps> = ({ activeSection, onSelect }) => {
  const renderItem = (item: (typeof PRIMARY_ITEMS)[number]) => {
    const Icon = item.icon;
    const isActive = activeSection === item.id;
    return (
      <button
        key={item.id}
        type="button"
        onClick={() => onSelect(item.id)}
        aria-current={isActive ? 'page' : undefined}
        className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-lg text-sm font-medium transition-all whitespace-nowrap shrink-0 cursor-pointer ${
          isActive
            ? 'bg-gradient-to-r from-[#4b0c18] via-[#2b0810] to-transparent border border-red-700/45 text-white shadow-[0_0_20px_rgba(185,28,28,0.18)]'
            : 'text-[#bfa9b0] hover:text-white hover:bg-white/[0.04] border border-transparent'
        }`}
      >
        <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-red-400' : 'text-[#9d8189]'}`} />
        <span className="truncate">{item.label}</span>
      </button>
    );
  };

  return (
    <aside
      aria-label="Navegação principal"
      className="hidden lg:flex flex-col w-[228px] shrink-0 bg-[#0b0508]/95 border-r border-red-900/20 px-3 py-5 select-none"
    >
      <button
        type="button"
        onClick={() => onSelect('inicio')}
        className="flex items-center gap-2.5 px-2.5 pb-5 mb-2 text-left cursor-pointer group"
      >
        <RoseEmblem className="w-7 h-7 transition-transform group-hover:scale-105" />
        <span className="text-lg font-semibold tracking-tight text-[#f6eff1]">Ebookfy</span>
      </button>

      <nav className="flex flex-col gap-1" aria-label="Biblioteca">
        {PRIMARY_ITEMS.map(renderItem)}
      </nav>

      <div className="my-4 border-t border-red-950/60" />

      <nav className="flex flex-col gap-1 flex-1" aria-label="Ferramentas locais">
        {SECONDARY_ITEMS.map(renderItem)}
      </nav>
    </aside>
  );
};
