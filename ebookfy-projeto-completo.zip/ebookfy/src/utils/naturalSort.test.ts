import test from 'node:test';
import assert from 'node:assert/strict';
import {
  naturalCompare,
  extractChapterInfo,
  organizeImportEntries,
  verifyChapterOrder,
  detectFileSignature,
  sanitizeArchivePath,
} from './naturalSort';

test('naturalCompare sorts numeric filenames correctly (1, 2, 10, 11)', () => {
  const input = ['10.jpg', '2.jpg', '11.jpg', '1.jpg', '3.jpg'];
  const sorted = [...input].sort(naturalCompare);
  assert.deepEqual(sorted, ['1.jpg', '2.jpg', '3.jpg', '10.jpg', '11.jpg']);
});

test('naturalCompare handles padded prefixes and Portuguese page labels', () => {
  const input = ['Página 10.png', 'Página 2.png', 'Página 1.png', 'page_001.webp', 'page_010.webp'];
  const sorted = [...input].sort(naturalCompare);
  assert.deepEqual(sorted, [
    'page_001.webp',
    'page_010.webp',
    'Página 1.png',
    'Página 2.png',
    'Página 10.png',
  ]);
});

test('extractChapterInfo recognizes varied chapter naming conventions', () => {
  assert.equal(extractChapterInfo('Capítulo 001').chapterNumber, 1);
  assert.equal(extractChapterInfo('Cap. 12').chapterNumber, 12);
  assert.equal(extractChapterInfo('Ch 5 - A Batalha').chapterNumber, 5);
  assert.equal(extractChapterInfo('c010').chapterNumber, 10);
  assert.equal(extractChapterInfo('003').chapterNumber, 3);
  assert.equal(extractChapterInfo('Capítulo 10.5').chapterNumber, 10.5);
});

test('organizeImportEntries orders chapters 1..5..10 and pages naturally', () => {
  const entries = [
    { path: 'Solo/Cap 10/10.jpg', name: '10.jpg', size: 100, mimeType: 'image/jpeg' },
    { path: 'Solo/Cap 10/2.jpg', name: '2.jpg', size: 100, mimeType: 'image/jpeg' },
    { path: 'Solo/Cap 2/1.jpg', name: '1.jpg', size: 100, mimeType: 'image/jpeg' },
    { path: 'Solo/Cap 1/2.jpg', name: '2.jpg', size: 100, mimeType: 'image/jpeg' },
    { path: 'Solo/Cap 1/1.jpg', name: '1.jpg', size: 100, mimeType: 'image/jpeg' },
    { path: 'Solo/__MACOSX/._1.jpg', name: '._1.jpg', size: 10, mimeType: 'image/jpeg' },
  ];

  const organized = organizeImportEntries(entries);
  assert.equal(organized.suggestedTitle, 'Solo');
  assert.equal(organized.chapters.length, 3);
  assert.deepEqual(
    organized.chapters.map((c) => c.chapterNumber),
    [1, 2, 10]
  );
  assert.deepEqual(
    organized.chapters[0].pages.map((p) => p.name),
    ['1.jpg', '2.jpg']
  );
  assert.deepEqual(
    organized.chapters[2].pages.map((p) => p.name),
    ['2.jpg', '10.jpg']
  );
  assert.equal(organized.verification.isSequential, false);
  assert.deepEqual(organized.verification.missingChapters, [3, 4, 5, 6, 7, 8, 9]);
});

test('verifyChapterOrder detects complete 1..5 sequence as valid', () => {
  const chapters = [1, 2, 3, 4, 5].map((n) => ({
    chapterNumber: n,
    pages: [{ name: '1.jpg', path: '', pageNumber: 1, mimeType: 'image/jpeg', size: 10 }],
  }));
  const res = verifyChapterOrder(chapters);
  assert.equal(res.isSequential, true);
  assert.deepEqual(res.missingChapters, []);
  assert.deepEqual(res.duplicateChapters, []);
  assert.equal(res.totalChapters, 5);
});

test('sanitizeArchivePath blocks path traversal and null bytes', () => {
  assert.equal(sanitizeArchivePath('../../etc/passwd'), null);
  assert.equal(sanitizeArchivePath('folder/\0evil.png'), null);
  assert.equal(sanitizeArchivePath('/Cap 01\\001.jpg'), 'Cap 01/001.jpg');
});

test('detectFileSignature identifies magic bytes and blocks executables', () => {
  assert.equal(detectFileSignature(new Uint8Array([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a])), 'png');
  assert.equal(detectFileSignature(new Uint8Array([0xff, 0xd8, 0xff, 0xe0])), 'jpg');
  assert.equal(detectFileSignature(new Uint8Array([0x50, 0x4b, 0x03, 0x04])), 'zip');
  assert.equal(detectFileSignature(new Uint8Array([0x25, 0x50, 0x44, 0x46, 0x2d])), 'pdf');
  assert.equal(detectFileSignature(new Uint8Array([0x4d, 0x5a, 0x90, 0x00])), 'executable');
});
