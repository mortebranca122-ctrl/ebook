import React, { useMemo, useState } from 'react';
import {
  CheckSquare,
  Edit3,
  Heart,
  LayoutGrid,
  List,
  Play,
  Plus,
  Square,
  Trash2,
} from 'lucide-react';
import type {
  CategoryType,
  Collection,
  ReadingProgress,
  Work,
} from '../types/ebookfy';
import { formatBytes, formatRelativeDate } from '../utils/formatters';

interface LibraryViewProps {
  works: Work[];
  progressMap: Map<string, ReadingProgress>;
  collections: Collection[];
  searchQuery: string;
  selectedCategory: CategoryType | 'Todas';
  viewMode: 'grid' | 'list';
  onChangeCategory: (cat: CategoryType | 'Todas') => void;
  onChangeViewMode: (mode: 'grid' | 'list') => void;
  onOpenWorkDetails: (work: Work) => void;
  onContinueWork: (work: Work) => void;
  onToggleFavorite: (workId: string) => void;
  onDeleteWorks: (workIds: string[], deleteBlobs: boolean) => void;
  onAddWorksToCollection: (collectionId: string, workIds: string[]) => void;
  onUpdateWorkMeta: (work: Work) => void;
  onGoToImport: () => void;
}

const CATEGORIES: Array<CategoryType | 'Todas'> = [
  'Todas',
  'Mangás',
  'Manhwas',
  'Manhuas',
  'Webtoons',
  'HQs',
  'Livros',
  'PDFs',
  'Documentos',
  'Outros',
];

export const LibraryView: React.FC<LibraryViewProps> = ({
  works,
  progressMap,
  collections,
  searchQuery,
  selectedCategory,
  viewMode,
  onChangeCategory,
  onChangeViewMode,
  onOpenWorkDetails,
  onContinueWork,
  onToggleFavorite,
  onDeleteWorks,
  onAddWorksToCollection,
  onUpdateWorkMeta,
  onGoToImport,
}) => {
  const [statusFilter, setStatusFilter] = useState<'all' | 'reading' | 'unread' | 'completed'>('all');
  const [sortBy, setSortBy] = useState<'recent' | 'title' | 'progress' | 'size'>('recent');
  const [selectionMode, setSelectionMode] = useState(false);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [confirmDeleteIds, setConfirmDeleteIds] = useState<string[] | null>(null);
  const [deleteFilesToo, setDeleteFilesToo] = useState(true);
  const [editingWork, setEditingWork] = useState<Work | null>(null);

  const filteredWorks = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return works
      .filter((w) => {
        if (selectedCategory !== 'Todas' && w.category !== selectedCategory) return false;
        if (q) {
          const hit =
            w.title.toLowerCase().includes(q) ||
            w.author.toLowerCase().includes(q) ||
            w.category.toLowerCase().includes(q);
          if (!hit) return false;
        }
        const prog = progressMap.get(w.id);
        const pct = prog?.percentage ?? 0;
        if (statusFilter === 'reading') return pct > 0 && pct < 100;
        if (statusFilter === 'unread') return pct === 0;
        if (statusFilter === 'completed') return pct >= 100 || prog?.status === 'concluido';
        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'title') return a.title.localeCompare(b.title, 'pt-BR');
        if (sortBy === 'size') return b.totalSizeBytes - a.totalSizeBytes;
        if (sortBy === 'progress') {
          return (progressMap.get(b.id)?.percentage ?? 0) - (progressMap.get(a.id)?.percentage ?? 0);
        }
        return (b.lastReadAt ?? b.updatedAt) - (a.lastReadAt ?? a.updatedAt);
      });
  }, [works, selectedCategory, searchQuery, statusFilter, sortBy, progressMap]);

  const toggleSelect = (id: string) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  return (
    <div className="space-y-5">
      {/* Header & Controls */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-xl sm:text-2xl font-semibold text-white">Biblioteca Digital</h1>
          <p className="text-xs text-[#bfa9b0] mt-0.5 font-mono-nums">
            {filteredWorks.length} obra(s) exibida(s) · {works.length} no dispositivo
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
            type="button"
            onClick={() => {
              setSelectionMode((m) => !m);
              setSelectedIds(new Set());
            }}
            className={`px-3 py-2 rounded-lg text-xs font-medium border cursor-pointer inline-flex items-center gap-1.5 ${
              selectionMode
                ? 'bg-red-900/40 border-red-600 text-white'
                : 'bg-white/[0.03] border-red-900/35 text-[#d4c0c6]'
            }`}
          >
            <CheckSquare className="w-3.5 h-3.5" />
            <span>Selecionar</span>
          </button>

          <div className="flex items-center rounded-lg border border-red-900/35 bg-[#12080c] p-0.5">
            <button
              type="button"
              onClick={() => onChangeViewMode('grid')}
              aria-label="Visualização em grade"
              className={`p-1.5 rounded-md cursor-pointer ${
                viewMode === 'grid' ? 'bg-red-800/50 text-white' : 'text-[#9d8189]'
              }`}
            >
              <LayoutGrid className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={() => onChangeViewMode('list')}
              aria-label="Visualização em lista"
              className={`p-1.5 rounded-md cursor-pointer ${
                viewMode === 'list' ? 'bg-red-800/50 text-white' : 'text-[#9d8189]'
              }`}
            >
              <List className="w-4 h-4" />
            </button>
          </div>

          <button
            type="button"
            onClick={onGoToImport}
            className="eb-accent-btn px-3.5 py-2 rounded-lg text-xs font-semibold inline-flex items-center gap-1.5 cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Importar</span>
          </button>
        </div>
      </div>

      {/* Category Filter Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
        {CATEGORIES.map((cat) => (
          <button
            key={cat}
            type="button"
            onClick={() => onChangeCategory(cat)}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap shrink-0 transition-colors cursor-pointer ${
              selectedCategory === cat
                ? 'bg-red-800/50 border border-red-600/60 text-white'
                : 'bg-white/[0.03] border border-white/10 text-[#bfa9b0] hover:text-white'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Status & Sort Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-1.5 bg-[#12080c] border border-red-900/25 rounded-lg p-1">
          {[
            { id: 'all', label: 'Todas' },
            { id: 'reading', label: 'Em andamento' },
            { id: 'unread', label: 'Não iniciados' },
            { id: 'completed', label: 'Concluídos' },
          ].map((st) => (
            <button
              key={st.id}
              type="button"
              onClick={() => setStatusFilter(st.id as typeof statusFilter)}
              className={`px-2.5 py-1 rounded-md text-xs font-medium cursor-pointer transition-colors ${
                statusFilter === st.id ? 'bg-red-800/55 text-white' : 'text-[#bfa9b0] hover:text-white'
              }`}
            >
              {st.label}
            </button>
          ))}
        </div>

        <select
          aria-label="Ordenar biblioteca"
          value={sortBy}
          onChange={(e) => setSortBy(e.target.value as typeof sortBy)}
          className="bg-[#12080c] border border-red-900/35 text-xs text-[#e5d5da] rounded-lg px-3 py-2 focus:outline-none cursor-pointer"
        >
          <option value="recent">Ordenar: Recentes</option>
          <option value="title">Ordenar: Título (A–Z)</option>
          <option value="progress">Ordenar: Progresso</option>
          <option value="size">Ordenar: Maior tamanho</option>
        </select>
      </div>

      {/* Multi-select batch bar */}
      {selectionMode && selectedIds.size > 0 && (
        <div className="eb-surface p-3 flex flex-wrap items-center justify-between gap-3 border-red-600/50">
          <span className="text-xs font-medium text-white font-mono-nums">
            {selectedIds.size} obra(s) selecionada(s)
          </span>
          <div className="flex items-center gap-2 flex-wrap">
            {collections.length > 0 && (
              <select
                aria-label="Adicionar selecionadas à coleção"
                defaultValue=""
                onChange={(e) => {
                  if (e.target.value) {
                    onAddWorksToCollection(e.target.value, Array.from(selectedIds));
                    setSelectionMode(false);
                    setSelectedIds(new Set());
                  }
                }}
                className="bg-[#1a0b11] border border-red-900/40 text-xs text-white rounded-lg px-2.5 py-1.5"
              >
                <option value="" disabled>
                  Adicionar à coleção...
                </option>
                {collections.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>
            )}
            <button
              type="button"
              onClick={() => setConfirmDeleteIds(Array.from(selectedIds))}
              className="px-3 py-1.5 rounded-lg bg-red-800 hover:bg-red-700 text-xs font-medium text-white inline-flex items-center gap-1.5 cursor-pointer"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Excluir selecionadas</span>
            </button>
          </div>
        </div>
      )}

      {/* Works List / Grid */}
      {filteredWorks.length === 0 ? (
        <div className="eb-surface p-10 text-center space-y-3">
          <p className="text-sm text-[#d4c0c6]">Nenhuma obra corresponde aos filtros atuais.</p>
          <button
            type="button"
            onClick={onGoToImport}
            className="eb-accent-btn px-4 py-2 rounded-lg text-xs font-semibold cursor-pointer"
          >
            Importar arquivo ou pasta
          </button>
        </div>
      ) : viewMode === 'grid' ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 xl:grid-cols-5 gap-3.5">
          {filteredWorks.map((work) => {
            const prog = progressMap.get(work.id);
            const pct = prog?.percentage ?? 0;
            const isChecked = selectedIds.has(work.id);

            return (
              <div
                key={work.id}
                className={`eb-surface overflow-hidden flex flex-col group transition-colors ${
                  isChecked ? 'border-red-500 ring-1 ring-red-500/50' : ''
                }`}
              >
                <div className="relative aspect-[3/4] overflow-hidden bg-[#0a0406]">
                  <button
                    type="button"
                    onClick={() => (selectionMode ? toggleSelect(work.id) : onOpenWorkDetails(work))}
                    className="w-full h-full block cursor-pointer"
                  >
                    <img
                      src={work.coverUrl}
                      alt={work.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                  </button>
                  <div className="absolute inset-x-0 bottom-0 h-20 bg-gradient-to-t from-black/90 to-transparent pointer-events-none" />

                  <div className="absolute top-2 right-2 flex items-center gap-1">
                    {selectionMode ? (
                      <button
                        type="button"
                        onClick={() => toggleSelect(work.id)}
                        aria-label={`Selecionar ${work.title}`}
                        className="p-1.5 rounded-lg bg-black/75 text-white cursor-pointer"
                      >
                        {isChecked ? <CheckSquare className="w-4 h-4 text-red-400" /> : <Square className="w-4 h-4" />}
                      </button>
                    ) : (
                      <button
                        type="button"
                        onClick={() => onToggleFavorite(work.id)}
                        aria-label={work.isFavorite ? `Remover ${work.title} dos favoritos` : `Favoritar ${work.title}`}
                        className="p-1.5 rounded-lg bg-black/70 text-white hover:bg-black cursor-pointer"
                      >
                        <Heart className={`w-3.5 h-3.5 ${work.isFavorite ? 'fill-red-500 text-red-500' : ''}`} />
                      </button>
                    )}
                  </div>

                  {pct > 0 && (
                    <div className="absolute bottom-0 inset-x-0 h-1 bg-white/15">
                      <div className="h-full bg-red-600" style={{ width: `${pct}%` }} />
                    </div>
                  )}
                </div>

                <div className="p-3 flex-1 flex flex-col justify-between gap-2">
                  <div>
                    <button
                      type="button"
                      onClick={() => onOpenWorkDetails(work)}
                      className="text-left text-sm font-semibold text-white line-clamp-1 hover:text-red-300 cursor-pointer"
                    >
                      {work.title}
                    </button>
                    <p className="text-[11px] text-[#9d8189] mt-0.5 truncate">
                      {work.category} · <span className="font-mono-nums">{work.chapters.length} cap.</span> ·{' '}
                      <span className="font-mono-nums">{pct}%</span>
                    </p>
                  </div>

                  <div className="flex items-center gap-1.5 pt-1">
                    <button
                      type="button"
                      onClick={() => onContinueWork(work)}
                      className="flex-1 py-1.5 px-2.5 rounded-lg bg-red-950/50 hover:bg-red-900/60 border border-red-800/40 text-xs font-medium text-white inline-flex items-center justify-center gap-1 cursor-pointer"
                    >
                      <Play className="w-3 h-3 fill-white" />
                      <span>{pct > 0 ? 'Continuar' : 'Ler'}</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setEditingWork(work)}
                      aria-label={`Editar ${work.title}`}
                      className="p-1.5 rounded-lg border border-white/10 text-[#bfa9b0] hover:text-white cursor-pointer"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="space-y-2">
          {filteredWorks.map((work) => {
            const prog = progressMap.get(work.id);
            const pct = prog?.percentage ?? 0;
            return (
              <div
                key={work.id}
                className="eb-surface p-3 flex items-center gap-3.5 justify-between"
              >
                <div className="flex items-center gap-3.5 min-w-0 flex-1">
                  {selectionMode && (
                    <button
                      type="button"
                      onClick={() => toggleSelect(work.id)}
                      aria-label={`Selecionar ${work.title}`}
                      className="text-white cursor-pointer"
                    >
                      {selectedIds.has(work.id) ? (
                        <CheckSquare className="w-4 h-4 text-red-400" />
                      ) : (
                        <Square className="w-4 h-4" />
                      )}
                    </button>
                  )}
                  <img
                    src={work.coverUrl}
                    alt={work.title}
                    className="w-12 h-16 rounded-lg object-cover border border-red-900/30 shrink-0"
                  />
                  <div className="min-w-0">
                    <button
                      type="button"
                      onClick={() => onOpenWorkDetails(work)}
                      className="text-sm font-semibold text-white hover:text-red-300 truncate block cursor-pointer"
                    >
                      {work.title}
                    </button>
                    <p className="text-xs text-[#bfa9b0] truncate">
                      {work.author} · {work.category} · {work.format.toUpperCase()} ·{' '}
                      <span className="font-mono-nums">{formatBytes(work.totalSizeBytes)}</span>
                    </p>
                    <p className="text-[11px] text-[#846a72] mt-0.5 font-mono-nums">
                      {work.chapters.length} capítulo(s) · {pct}% · {formatRelativeDate(work.lastReadAt)}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <button
                    type="button"
                    onClick={() => onContinueWork(work)}
                    className="eb-accent-btn px-3.5 py-2 rounded-lg text-xs font-semibold cursor-pointer"
                  >
                    {pct > 0 ? 'Continuar' : 'Ler'}
                  </button>
                  <button
                    type="button"
                    onClick={() => setConfirmDeleteIds([work.id])}
                    aria-label={`Excluir ${work.title}`}
                    className="p-2 rounded-lg border border-white/10 text-[#bfa9b0] hover:text-red-400 cursor-pointer"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Edit Metadata Modal */}
      {editingWork && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="eb-surface w-full max-w-md p-5 space-y-4">
            <h2 className="text-base font-semibold text-white">Editar informações da obra</h2>
            <div className="space-y-3">
              <div>
                <label className="block text-xs text-[#bfa9b0] mb-1">Título</label>
                <input
                  type="text"
                  value={editingWork.title}
                  onChange={(e) => setEditingWork({ ...editingWork, title: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg bg-black/50 border border-red-900/40 text-sm text-white"
                />
              </div>
              <div>
                <label className="block text-xs text-[#bfa9b0] mb-1">Autor</label>
                <input
                  type="text"
                  value={editingWork.author}
                  onChange={(e) => setEditingWork({ ...editingWork, author: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg bg-black/50 border border-red-900/40 text-sm text-white"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs text-[#bfa9b0] mb-1">Categoria</label>
                  <select
                    value={editingWork.category}
                    onChange={(e) =>
                      setEditingWork({ ...editingWork, category: e.target.value as CategoryType })
                    }
                    className="w-full px-3 py-2 rounded-lg bg-[#12080c] border border-red-900/40 text-xs text-white"
                  >
                    {CATEGORIES.filter((c) => c !== 'Todas').map((c) => (
                      <option key={c} value={c}>
                        {c}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs text-[#bfa9b0] mb-1">Alterar Capa</label>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (!file) return;
                      const reader = new FileReader();
                      reader.onload = () => {
                        if (typeof reader.result === 'string') {
                          setEditingWork({ ...editingWork, coverUrl: reader.result });
                        }
                      };
                      reader.readAsDataURL(file);
                    }}
                    className="w-full text-[11px] text-[#bfa9b0]"
                  />
                </div>
              </div>
              <div>
                <label className="block text-xs text-[#bfa9b0] mb-1">Descrição</label>
                <textarea
                  rows={3}
                  value={editingWork.description}
                  onChange={(e) => setEditingWork({ ...editingWork, description: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg bg-black/50 border border-red-900/40 text-xs text-white"
                />
              </div>
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setEditingWork(null)}
                className="px-4 py-2 rounded-lg border border-white/15 text-xs text-[#d4c0c6] cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={() => {
                  onUpdateWorkMeta({ ...editingWork, updatedAt: Date.now() });
                  setEditingWork(null);
                }}
                className="eb-accent-btn px-4 py-2 rounded-lg text-xs font-semibold cursor-pointer"
              >
                Salvar alterações
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {confirmDeleteIds && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="eb-surface w-full max-w-md p-5 space-y-4 border-red-700/60">
            <h2 className="text-base font-semibold text-white">Confirmar exclusão</h2>
            <p className="text-xs text-[#d4c0c6] leading-relaxed">
              Você está prestes a remover{' '}
              <strong className="text-white">{confirmDeleteIds.length} obra(s)</strong> da biblioteca.
            </p>
            <label className="flex items-start gap-2.5 text-xs text-[#bfa9b0] cursor-pointer">
              <input
                type="checkbox"
                checked={deleteFilesToo}
                onChange={(e) => setDeleteFilesToo(e.target.checked)}
                className="mt-0.5 accent-red-600"
              />
              <span>
                Também apagar arquivos locais armazenados dentro do Ebookfy (libera espaço em disco).
                Seus arquivos originais fora do app nunca são tocados.
              </span>
            </label>
            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setConfirmDeleteIds(null)}
                className="px-4 py-2 rounded-lg border border-white/15 text-xs text-[#d4c0c6] cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={() => {
                  onDeleteWorks(confirmDeleteIds, deleteFilesToo);
                  setConfirmDeleteIds(null);
                  setSelectionMode(false);
                  setSelectedIds(new Set());
                }}
                className="px-4 py-2 rounded-lg bg-red-700 hover:bg-red-600 text-xs font-semibold text-white cursor-pointer"
              >
                Confirmar exclusão
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
