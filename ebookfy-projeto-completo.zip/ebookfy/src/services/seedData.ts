import type { Chapter, Collection, HistoryEntry, ReadingProgress, Work } from '../types/ebookfy';

function createPanelSvgUrl(
  panelTitle: string,
  subtitle: string,
  accentColor: string,
  panelIndex: number,
  isVerticalStrip: boolean
): string {
  const width = isVerticalStrip ? 800 : 900;
  const height = isVerticalStrip ? 1280 : 1260;
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}">
    <defs>
      <linearGradient id="g${panelIndex}" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stop-color="#090508"/>
        <stop offset="55%" stop-color="#170a10"/>
        <stop offset="100%" stop-color="#050304"/>
      </linearGradient>
      <radialGradient id="glow${panelIndex}" cx="50%" cy="42%" r="48%">
        <stop offset="0%" stop-color="${accentColor}" stop-opacity="0.35"/>
        <stop offset="100%" stop-color="${accentColor}" stop-opacity="0"/>
      </radialGradient>
    </defs>
    <rect width="${width}" height="${height}" fill="url(#g${panelIndex})"/>
    <rect width="${width}" height="${height}" fill="url(#glow${panelIndex})"/>
    <rect x="36" y="36" width="${width - 72}" height="${height - 72}" fill="none" stroke="${accentColor}" stroke-opacity="0.4" stroke-width="3"/>
    <rect x="54" y="54" width="${width - 108}" height="${height - 108}" fill="none" stroke="#ffffff" stroke-opacity="0.08" stroke-width="1"/>
    <circle cx="${width / 2}" cy="${height * 0.42}" r="${120 + (panelIndex % 3) * 28}" fill="none" stroke="${accentColor}" stroke-opacity="0.45" stroke-width="2" stroke-dasharray="10 8"/>
    <path d="M ${width * 0.25} ${height * 0.56} L ${width * 0.5} ${height * 0.24} L ${width * 0.75} ${height * 0.56} Z" fill="${accentColor}" fill-opacity="0.16" stroke="${accentColor}" stroke-opacity="0.6" stroke-width="2"/>
    <rect x="86" y="${height - 290}" width="${width - 172}" height="175" rx="14" fill="#070406" fill-opacity="0.92" stroke="${accentColor}" stroke-opacity="0.65" stroke-width="2"/>
    <text x="${width / 2}" y="${height - 216}" text-anchor="middle" fill="#f8f2f4" font-family="Georgia, serif" font-size="34" font-weight="600">${panelTitle}</text>
    <text x="${width / 2}" y="${height - 160}" text-anchor="middle" fill="#c7b2b9" font-family="sans-serif" font-size="22">${subtitle}</text>
    <text x="${width - 72}" y="86" text-anchor="end" fill="#8b7179" font-family="monospace" font-size="20">Pág. ${panelIndex + 1}</text>
  </svg>`;
  return `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
}

function buildSampleChapters(
  workId: string,
  chapterNumbers: number[],
  pagesPerChapter: number,
  accent: string,
  isVertical: boolean,
  workTitle: string
): Chapter[] {
  return chapterNumbers.map((num, idx) => {
    const chapId = `${workId}-ch-${num}`;
    const pages = Array.from({ length: pagesPerChapter }, (_, pIdx) => ({
      id: `${chapId}-p-${pIdx + 1}`,
      name: `${String(pIdx + 1).padStart(3, '0')}.svg`,
      pageNumber: pIdx + 1,
      mimeType: 'image/svg+xml',
      size: 245_000,
      inlineUrl: createPanelSvgUrl(
        `${workTitle} — Capítulo ${num}`,
        `Cena ${pIdx + 1} de ${pagesPerChapter} · Leitura Offline Local`,
        accent,
        pIdx + num,
        isVertical
      ),
    }));
    return {
      id: chapId,
      title: `Capítulo ${num}`,
      chapterNumber: num,
      orderIndex: idx,
      pages,
      totalSize: pages.length * 245_000,
    };
  });
}

export function createStarterSeedData(): {
  works: Work[];
  progress: ReadingProgress[];
  collections: Collection[];
  history: HistoryEntry[];
} {
  const now = Date.now();

  const soloChapters = buildSampleChapters(
    'sample-solo-leveling',
    [110, 111, 112, 113, 114],
    6,
    '#dc2626',
    true,
    'Solo Leveling'
  );

  const crimsonChapters = buildSampleChapters(
    'sample-voto-carmesim',
    [1, 2, 3, 4],
    5,
    '#be123c',
    false,
    'Voto Carmesim'
  );

  const eclipseChapters = buildSampleChapters(
    'sample-eclipse-rosas',
    [1, 2, 3],
    5,
    '#e11d48',
    false,
    'Eclipse das Rosas'
  );

  const hqChapters = buildSampleChapters(
    'sample-cavaleiro-abismo',
    [1, 2, 3],
    5,
    '#b91c1c',
    false,
    'Cavaleiro do Abismo'
  );

  const bookChapters: Chapter[] = [
    {
      id: 'sample-grimorio-ch-1',
      title: 'Capítulo 1 — O Pacto da Rosa Negra',
      chapterNumber: 1,
      orderIndex: 0,
      pages: [],
      totalSize: 4200,
      bookContent: {
        text: [
          'A chuva escorria pelas janelas ogivais da biblioteca antiga enquanto o relógio da torre marcava meia-noite. Sobre a mesa de ébano, um único volume encadernado em couro preto repousava intacto há mais de um século.',
          'Helena deslizou os dedos pela rosa carmesim gravada na capa. O selo não se abria por força bruta — apenas para quem carregasse consigo o silêncio daquela casa.',
          'Quando virou a primeira página, a tinta parecia absorver a luz da lareira. Cada palavra surgia nítida, como um sussurro gravado na memória de outro tempo.',
          '— Você demorou para retornar — disse uma voz grave vinda da penumbra do mezanino, onde as sombras pareciam obedecer a um ritmo próprio.',
          'Ela não recuou. Fechou o dedo sobre a margem do pergaminho e respondeu com calma absoluta: — Eu vim apenas recuperar o que pertence à minha linhagem.',
        ].join('\n\n'),
      },
    },
    {
      id: 'sample-grimorio-ch-2',
      title: 'Capítulo 2 — Correntes de Veludo',
      chapterNumber: 2,
      orderIndex: 1,
      pages: [],
      totalSize: 3800,
      bookContent: {
        text: [
          'Nos corredores subterrâneos sob a mansão, o ar guardava o perfume de cedro, ferro frio e pétalas secas.',
          'Cada capítulo do grimório revelava mapas antigos, juramentos esquecidos e a verdade sobre o eclipse que dividiu as duas famílias. Em contraste com o breu ao redor, as anotações marginais brilhavam como um aviso silencioso.',
          'A leitura tornou-se refúgio. Mesmo no escuro absoluto da ala leste, as palavras permaneciam claras, confortáveis aos olhos, guiando-a até o salão principal.',
          'Ali, diante do espelho rachado, o pacto foi finalmente selado.',
        ].join('\n\n'),
      },
    },
    {
      id: 'sample-grimorio-ch-3',
      title: 'Capítulo 3 — Alvorada Carmesim',
      chapterNumber: 3,
      orderIndex: 2,
      pages: [],
      totalSize: 3500,
      bookContent: {
        text: [
          'Quando os sinos soaram pela última vez naquela noite, a lua vermelha já declinava atrás das montanhas.',
          'O livro fechou-se suavemente. Tudo o que fora perdido retornara ao seu lugar de direito, guardado para sempre entre páginas silenciosas.',
        ].join('\n\n'),
      },
    },
  ];

  const works: Work[] = [
    {
      id: 'sample-solo-leveling',
      title: 'Solo Leveling',
      author: 'Chugong',
      category: 'Manhwas',
      format: 'cbz',
      readerMode: 'manhwa',
      description: 'O mais forte se levanta em um mundo cheio de monstros e portais dimensionais.',
      coverUrl: '/src/assets/images/cover_shadow_monarch_1794861269069.jpg',
      isFavorite: true,
      isSample: true,
      tags: ['Ação', 'Fantasia Sombria', 'Webtoon'],
      chapters: soloChapters,
      totalPages: soloChapters.reduce((s, c) => s + c.pages.length, 0),
      totalSizeBytes: 14_820_000,
      createdAt: now - 86_400_000 * 5,
      updatedAt: now - 3_600_000,
      lastReadAt: now - 300_000,
    },
    {
      id: 'sample-voto-carmesim',
      title: 'Voto Carmesim',
      author: 'L. Moreau',
      category: 'Manhuas',
      format: 'cbz',
      readerMode: 'hq',
      description: 'Um juramento proibido sob a lua de sangue une duas casas rivais em um palácio gótico.',
      coverUrl: '/src/assets/images/cover_crimson_vow_1794861268635.jpg',
      isFavorite: true,
      isSample: true,
      tags: ['Dark Romance', 'Gótico', 'Drama'],
      chapters: crimsonChapters,
      totalPages: crimsonChapters.reduce((s, c) => s + c.pages.length, 0),
      totalSizeBytes: 9_450_000,
      createdAt: now - 86_400_000 * 4,
      updatedAt: now - 7_200_000,
      lastReadAt: now - 4_200_000,
    },
    {
      id: 'sample-eclipse-rosas',
      title: 'Eclipse das Rosas',
      author: 'K. Vance',
      category: 'Mangás',
      format: 'cbz',
      readerMode: 'manga',
      description: 'Sob um eclipse escarlate, um espadachim amaldiçoado busca redenção entre ruínas antigas.',
      coverUrl: '/src/assets/images/cover_blood_rose_1794861269769.jpg',
      isFavorite: false,
      isSample: true,
      tags: ['Seinen', 'Fantasia', 'Mangá'],
      chapters: eclipseChapters,
      totalPages: eclipseChapters.reduce((s, c) => s + c.pages.length, 0),
      totalSizeBytes: 7_120_000,
      createdAt: now - 86_400_000 * 3,
      updatedAt: now - 14_400_000,
      lastReadAt: now - 18_000_000,
    },
    {
      id: 'sample-grimorio-veludo',
      title: 'O Grimório de Veludo Negro',
      author: 'Elena Vance',
      category: 'Livros',
      format: 'epub',
      readerMode: 'book',
      description: 'Romance gótico sobre segredos familiares, cartas antigas e um pacto selado à meia-noite.',
      coverUrl: '/src/assets/images/cover_midnight_tome_1794861270860.jpg',
      isFavorite: true,
      isSample: true,
      tags: ['Dark Romance', 'Livro', 'Literatura'],
      chapters: bookChapters,
      totalPages: bookChapters.length,
      totalSizeBytes: 1_240_000,
      createdAt: now - 86_400_000 * 2,
      updatedAt: now - 10_800_000,
      lastReadAt: now - 9_000_000,
    },
    {
      id: 'sample-cavaleiro-abismo',
      title: 'Cavaleiro do Abismo',
      author: 'M. Blackwood',
      category: 'HQs',
      format: 'cbz',
      readerMode: 'hq',
      description: 'Crônicas ilustradas das fronteiras sombrias onde lâminas rúnicas guardam o último bastião.',
      coverUrl: '/src/assets/images/hero_dark_romance_1794861267461.jpg',
      isFavorite: false,
      isSample: true,
      tags: ['HQ', 'Fantasia'],
      chapters: hqChapters,
      totalPages: hqChapters.reduce((s, c) => s + c.pages.length, 0),
      totalSizeBytes: 6_380_000,
      createdAt: now - 86_400_000,
      updatedAt: now - 21_600_000,
    },
  ];

  const progress: ReadingProgress[] = [
    {
      workId: 'sample-solo-leveling',
      chapterId: 'sample-solo-leveling-ch-112',
      chapterIndex: 2,
      pageIndex: 3,
      scrollRatio: 0.72,
      percentage: 72,
      status: 'em_andamento',
      completedChapterIds: ['sample-solo-leveling-ch-110', 'sample-solo-leveling-ch-111'],
      bookmarks: [
        {
          id: 'bm-1',
          workId: 'sample-solo-leveling',
          chapterId: 'sample-solo-leveling-ch-112',
          chapterTitle: 'Capítulo 112',
          pageIndex: 3,
          scrollRatio: 0.72,
          note: 'Confronto no santuário',
          createdAt: now - 350_000,
        },
      ],
      updatedAt: now - 300_000,
    },
    {
      workId: 'sample-voto-carmesim',
      chapterId: 'sample-voto-carmesim-ch-2',
      chapterIndex: 1,
      pageIndex: 2,
      scrollRatio: 0.4,
      percentage: 45,
      status: 'em_andamento',
      completedChapterIds: ['sample-voto-carmesim-ch-1'],
      bookmarks: [],
      updatedAt: now - 4_200_000,
    },
    {
      workId: 'sample-grimorio-veludo',
      chapterId: 'sample-grimorio-ch-1',
      chapterIndex: 0,
      pageIndex: 0,
      scrollRatio: 0.35,
      percentage: 33,
      status: 'em_andamento',
      completedChapterIds: [],
      bookmarks: [],
      updatedAt: now - 9_000_000,
    },
  ];

  const collections: Collection[] = [
    {
      id: 'col-dark-romance',
      name: 'Seleção Dark Romance',
      description: 'Obras góticas e romances sombrios favoritos para leitura noturna.',
      workIds: ['sample-voto-carmesim', 'sample-grimorio-veludo'],
      createdAt: now - 86_400_000 * 3,
    },
    {
      id: 'col-leitura-rapida',
      name: 'Webtoons & Manhwas',
      description: 'Leitura contínua vertical otimizada para tela cheia.',
      workIds: ['sample-solo-leveling'],
      createdAt: now - 86_400_000 * 2,
    },
  ];

  const history: HistoryEntry[] = [
    {
      id: 'hist-1',
      workId: 'sample-solo-leveling',
      workTitle: 'Solo Leveling',
      coverUrl: '/src/assets/images/cover_shadow_monarch_1794861269069.jpg',
      category: 'Manhwas',
      chapterId: 'sample-solo-leveling-ch-112',
      chapterTitle: 'Capítulo 112',
      pageIndex: 3,
      percentage: 72,
      timestamp: now - 300_000,
    },
    {
      id: 'hist-2',
      workId: 'sample-voto-carmesim',
      workTitle: 'Voto Carmesim',
      coverUrl: '/src/assets/images/cover_crimson_vow_1794861268635.jpg',
      category: 'Manhuas',
      chapterId: 'sample-voto-carmesim-ch-2',
      chapterTitle: 'Capítulo 2',
      pageIndex: 2,
      percentage: 45,
      timestamp: now - 4_200_000,
    },
    {
      id: 'hist-3',
      workId: 'sample-grimorio-veludo',
      workTitle: 'O Grimório de Veludo Negro',
      coverUrl: '/src/assets/images/cover_midnight_tome_1794861270860.jpg',
      category: 'Livros',
      chapterId: 'sample-grimorio-ch-1',
      chapterTitle: 'Capítulo 1 — O Pacto da Rosa Negra',
      pageIndex: 0,
      percentage: 33,
      timestamp: now - 9_000_000,
    },
  ];

  return { works, progress, collections, history };
}
