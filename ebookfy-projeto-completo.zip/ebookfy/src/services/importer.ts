import * as zip from '@zip.js/zip.js';
import type {
  CategoryType,
  Chapter,
  ReaderMode,
  Work,
  WorkFormat,
} from '../types/ebookfy';
import {
  detectFileSignature,
  isImageFilename,
  naturalCompare,
  organizeImportEntries,
  sanitizeArchivePath,
  verifyChapterOrder,
  type ChapterOrderVerification,
  type RawImportEntry,
} from '../utils/naturalSort';
import { storeBinaryBlob } from './db';
import { sha256Text } from '../utils/crypto';

// Configure zip.js to avoid external worker CDN dependencies (100% offline)
zip.configure({ useWebWorkers: true });

export interface ImportPreviewDraft {
  id: string;
  title: string;
  author: string;
  category: CategoryType;
  format: WorkFormat;
  readerMode: ReaderMode;
  description: string;
  coverUrl: string;
  chapters: Chapter[];
  verification: ChapterOrderVerification;
  totalPages: number;
  totalSizeBytes: number;
  originalFileName: string;
  sourceHash: string;
  archiveBlobKey?: string;
  pendingBlobs?: Array<{ key: string; blob: Blob }>;
}

const MAX_ARCHIVE_ENTRIES = 50_000;

function inferMimeFromName(name: string): string {
  const ext = name.split('.').pop()?.toLowerCase() ?? '';
  switch (ext) {
    case 'png':
      return 'image/png';
    case 'jpg':
    case 'jpeg':
      return 'image/jpeg';
    case 'webp':
      return 'image/webp';
    case 'gif':
      return 'image/gif';
    case 'bmp':
      return 'image/bmp';
    case 'tif':
    case 'tiff':
      return 'image/tiff';
    case 'avif':
      return 'image/avif';
    case 'pdf':
      return 'application/pdf';
    default:
      return 'application/octet-stream';
  }
}

export function inferCategoryFromFormat(
  format: WorkFormat,
  title: string
): { category: CategoryType; readerMode: ReaderMode } {
  const lower = title.toLowerCase();
  if (format === 'epub' || format === 'txt' || format === 'docx' || format === 'rtf' || format === 'html') {
    return {
      category: format === 'txt' || format === 'docx' || format === 'rtf' ? 'Documentos' : 'Livros',
      readerMode: 'book',
    };
  }
  if (format === 'pdf') {
    return { category: 'PDFs', readerMode: 'pdf' };
  }
  if (lower.includes('webtoon') || lower.includes('manhwa') || lower.includes('solo')) {
    return { category: 'Manhwas', readerMode: 'manhwa' };
  }
  if (lower.includes('manhua')) {
    return { category: 'Manhuas', readerMode: 'hq' };
  }
  if (lower.includes('hq') || lower.includes('comic')) {
    return { category: 'HQs', readerMode: 'hq' };
  }
  return { category: 'Mangás', readerMode: 'manga' };
}

async function generateThumbnailDataUrl(blob: Blob, maxWidth = 360): Promise<string> {
  try {
    const bitmap = await createImageBitmap(blob);
    const scale = Math.min(1, maxWidth / bitmap.width);
    const w = Math.max(1, Math.round(bitmap.width * scale));
    const h = Math.max(1, Math.round(bitmap.height * scale));
    const canvas = document.createElement('canvas');
    canvas.width = w;
    canvas.height = h;
    const ctx = canvas.getContext('2d');
    if (!ctx) {
      bitmap.close();
      return '';
    }
    ctx.drawImage(bitmap, 0, 0, w, h);
    bitmap.close();
    return canvas.toDataURL('image/webp', 0.84);
  } catch {
    return '';
  }
}

function createFallbackCoverDataUrl(title: string, badge: string): string {
  const safeTitle = title.replace(/[<>&"']/g, '').slice(0, 32);
  const safeBadge = badge.replace(/[<>&"']/g, '');
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="360" height="480" viewBox="0 0 360 480">
    <defs>
      <linearGradient id="bg" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0%" stop-color="#1d0910"/>
        <stop offset="100%" stop-color="#070406"/>
      </linearGradient>
    </defs>
    <rect width="360" height="480" fill="url(#bg)"/>
    <rect x="20" y="20" width="320" height="440" rx="12" fill="none" stroke="#b91c1c" stroke-opacity="0.45" stroke-width="2"/>
    <circle cx="180" cy="180" r="56" fill="#991b1b" fill-opacity="0.22" stroke="#e11d48" stroke-opacity="0.5" stroke-width="2"/>
    <text x="180" y="190" text-anchor="middle" fill="#fda4af" font-family="Georgia, serif" font-size="24" font-weight="700">${safeBadge}</text>
    <text x="180" y="310" text-anchor="middle" fill="#f6eff1" font-family="Georgia, serif" font-size="22" font-weight="600">${safeTitle}</text>
    <text x="180" y="346" text-anchor="middle" fill="#9f858d" font-family="sans-serif" font-size="13">Arquivo Local Ebookfy</text>
  </svg>`;
  return `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
}

async function readMagicHeader(blob: Blob, bytes = 64): Promise<Uint8Array> {
  const slice = blob.slice(0, bytes);
  return new Uint8Array(await slice.arrayBuffer());
}

function decodeHtmlToText(html: string): { title: string; text: string } {
  const parser = new DOMParser();
  const doc = parser.parseFromString(html, 'text/html');
  const title = doc.querySelector('title, h1, h2')?.textContent?.trim() || '';
  doc.querySelectorAll('script, style').forEach((el) => el.remove());
  const blocks = Array.from(doc.querySelectorAll('p, h1, h2, h3, h4, li, blockquote, div'))
    .map((el) => el.textContent?.trim() ?? '')
    .filter((t) => t.length > 0);
  const text =
    blocks.length > 0
      ? Array.from(new Set(blocks)).join('\n\n')
      : (doc.body?.textContent ?? '').replace(/\s+\n/g, '\n').trim();
  return { title, text };
}

function stripRtf(rtf: string): string {
  return rtf
    .replace(/\\par[d]?/g, '\n\n')
    .replace(/\{\*?\\[^{}]+}|[{}]|\\[A-Za-z]+\d*\s?/g, '')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

async function parseEpubArchive(
  file: File,
  onProgress: (pct: number, stage: string) => void
): Promise<ImportPreviewDraft> {
  const reader = new zip.ZipReader(new zip.BlobReader(file));
  try {
    onProgress(20, 'Lendo estrutura EPUB...');
    const entries = await reader.getEntries();
    if (entries.length > MAX_ARCHIVE_ENTRIES) {
      throw new Error('Arquivo excede o limite de segurança de entradas.');
    }

    const entryMap = new Map<string, zip.Entry>();
    for (const e of entries) {
      const clean = sanitizeArchivePath(e.filename);
      if (clean && !e.directory) entryMap.set(clean, e);
    }

    let opfPath = '';
    const containerEntry = entryMap.get('META-INF/container.xml');
    if (containerEntry && 'getData' in containerEntry && containerEntry.getData) {
      const xmlText = await containerEntry.getData(new zip.TextWriter());
      const match = xmlText.match(/full-path=["']([^"']+)["']/i);
      if (match) opfPath = sanitizeArchivePath(match[1]) ?? '';
    }

    if (!opfPath) {
      opfPath = Array.from(entryMap.keys()).find((k) => k.endsWith('.opf')) ?? '';
    }

    let title = file.name.replace(/\.epub$/i, '');
    let author = 'Autor desconhecido';
    let description = 'Livro digital EPUB importado localmente.';
    const chapters: Chapter[] = [];
    let coverUrl = '';

    if (opfPath && entryMap.has(opfPath)) {
      const opfEntry = entryMap.get(opfPath)!;
      if ('getData' in opfEntry && opfEntry.getData) {
        const opfXml = await opfEntry.getData(new zip.TextWriter());
        const doc = new DOMParser().parseFromString(opfXml, 'application/xml');
        const opfBase = opfPath.includes('/') ? opfPath.slice(0, opfPath.lastIndexOf('/') + 1) : '';

        title = doc.querySelector('metadata title, dc\\:title')?.textContent?.trim() || title;
        author = doc.querySelector('metadata creator, dc\\:creator')?.textContent?.trim() || author;
        description =
          doc.querySelector('metadata description, dc\\:description')?.textContent?.trim() || description;

        const manifestMap = new Map<string, { href: string; mediaType: string; properties: string }>();
        doc.querySelectorAll('manifest item').forEach((item) => {
          const id = item.getAttribute('id') ?? '';
          const href = item.getAttribute('href') ?? '';
          const mediaType = item.getAttribute('media-type') ?? '';
          const properties = item.getAttribute('properties') ?? '';
          if (id && href) manifestMap.set(id, { href: decodeURIComponent(href), mediaType, properties });
        });

        // Try cover extraction
        const coverMeta = doc.querySelector('metadata meta[name="cover"]')?.getAttribute('content');
        let coverHref = coverMeta ? manifestMap.get(coverMeta)?.href : undefined;
        if (!coverHref) {
          for (const m of manifestMap.values()) {
            if (m.properties.includes('cover-image') || /cover/i.test(m.href)) {
              if (m.mediaType.startsWith('image/')) {
                coverHref = m.href;
                break;
              }
            }
          }
        }
        if (coverHref) {
          const resolvedCover = sanitizeArchivePath(opfBase + coverHref);
          const coverEntry = resolvedCover ? entryMap.get(resolvedCover) : undefined;
          if (coverEntry && 'getData' in coverEntry && coverEntry.getData) {
            const cBlob = await coverEntry.getData(new zip.BlobWriter());
            coverUrl = await generateThumbnailDataUrl(cBlob);
          }
        }

        const spineIds = Array.from(doc.querySelectorAll('spine itemref')).map(
          (r) => r.getAttribute('idref') ?? ''
        );

        let idx = 0;
        for (const idref of spineIds) {
          const item = manifestMap.get(idref);
          if (!item) continue;
          const resolved = sanitizeArchivePath(opfBase + item.href);
          const chapEntry = resolved ? entryMap.get(resolved) : undefined;
          if (!chapEntry || !('getData' in chapEntry) || !chapEntry.getData) continue;

          onProgress(35 + Math.round((idx / Math.max(1, spineIds.length)) * 50), `Processando capítulo ${idx + 1}...`);
          const rawHtml = await chapEntry.getData(new zip.TextWriter());
          const parsed = decodeHtmlToText(rawHtml);
          if (parsed.text.trim().length > 0) {
            chapters.push({
              id: `epub-ch-${idx + 1}`,
              title: parsed.title || `Capítulo ${idx + 1}`,
              chapterNumber: idx + 1,
              orderIndex: idx,
              pages: [],
              bookContent: { text: parsed.text },
              totalSize: rawHtml.length,
            });
            idx++;
          }
        }
      }
    }

    // Fallback if spine was empty
    if (chapters.length === 0) {
      const htmlKeys = Array.from(entryMap.keys())
        .filter((k) => /\.(x?html?|txt)$/i.test(k))
        .sort(naturalCompare);
      let idx = 0;
      for (const k of htmlKeys) {
        const entry = entryMap.get(k)!;
        if ('getData' in entry && entry.getData) {
          const raw = await entry.getData(new zip.TextWriter());
          const parsed = decodeHtmlToText(raw);
          if (parsed.text.trim().length > 0) {
            chapters.push({
              id: `epub-ch-${idx + 1}`,
              title: parsed.title || `Seção ${idx + 1}`,
              chapterNumber: idx + 1,
              orderIndex: idx,
              pages: [],
              bookContent: { text: parsed.text },
              totalSize: raw.length,
            });
            idx++;
          }
        }
      }
    }

    if (chapters.length === 0) {
      throw new Error('Nenhum conteúdo textual legível encontrado neste EPUB.');
    }

    const workId = `work-${crypto.randomUUID()}`;
    onProgress(90, 'Armazenando arquivo local...');
    const archiveBlobKey = await storeBinaryBlob(`archive-${workId}`, file);

    return {
      id: workId,
      title,
      author,
      category: 'Livros',
      format: 'epub',
      readerMode: 'book',
      description,
      coverUrl: coverUrl || createFallbackCoverDataUrl(title, 'EPUB'),
      chapters,
      verification: verifyChapterOrder(chapters),
      totalPages: chapters.length,
      totalSizeBytes: file.size,
      originalFileName: file.name,
      sourceHash: await sha256Text(`${file.name}:${file.size}:${file.lastModified}`),
      archiveBlobKey,
    };
  } finally {
    await reader.close();
  }
}

async function parseDocxArchive(file: File): Promise<ImportPreviewDraft> {
  const reader = new zip.ZipReader(new zip.BlobReader(file));
  try {
    const entries = await reader.getEntries();
    const docEntry = entries.find((e) => sanitizeArchivePath(e.filename) === 'word/document.xml');
    if (!docEntry || !('getData' in docEntry) || !docEntry.getData) {
      throw new Error('Documento DOCX inválido ou sem conteúdo principal.');
    }
    const xmlStr = await docEntry.getData(new zip.TextWriter());
    const xml = new DOMParser().parseFromString(xmlStr, 'application/xml');
    const paragraphs = Array.from(xml.getElementsByTagName('w:p'))
      .map((p) =>
        Array.from(p.getElementsByTagName('w:t'))
          .map((t) => t.textContent ?? '')
          .join('')
          .trim()
      )
      .filter((t) => t.length > 0);

    const title = file.name.replace(/\.docx$/i, '');
    const fullText = paragraphs.join('\n\n') || 'Documento vazio.';
    const workId = `work-${crypto.randomUUID()}`;

    const chapters: Chapter[] = [
      {
        id: `${workId}-ch-1`,
        title: 'Texto Completo',
        chapterNumber: 1,
        orderIndex: 0,
        pages: [],
        bookContent: { text: fullText },
        totalSize: fullText.length,
      },
    ];

    return {
      id: workId,
      title,
      author: 'Documento Local',
      category: 'Documentos',
      format: 'docx',
      readerMode: 'book',
      description: `Documento DOCX com ${paragraphs.length} parágrafos.`,
      coverUrl: createFallbackCoverDataUrl(title, 'DOCX'),
      chapters,
      verification: verifyChapterOrder(chapters),
      totalPages: 1,
      totalSizeBytes: file.size,
      originalFileName: file.name,
      sourceHash: await sha256Text(`${file.name}:${file.size}:${file.lastModified}`),
    };
  } finally {
    await reader.close();
  }
}

/**
 * Streaming ZIP / CBZ importer: handles files of ANY size (MB or multiple GBs)
 * using BlobReader slices without loading the entire archive into RAM!
 */
async function parseImageArchive(
  file: File,
  onProgress: (pct: number, stage: string) => void
): Promise<ImportPreviewDraft> {
  onProgress(10, 'Inspecionando índice do arquivo compactado...');
  const reader = new zip.ZipReader(new zip.BlobReader(file));

  try {
    const entries = await reader.getEntries();
    if (entries.length > MAX_ARCHIVE_ENTRIES) {
      throw new Error(`Arquivo excede o limite de segurança de ${MAX_ARCHIVE_ENTRIES} entradas.`);
    }

    const workId = `work-${crypto.randomUUID()}`;
    const archiveStorageKey = `archive-${workId}`;
    const rawEntries: RawImportEntry[] = [];
    let firstImageEntry: zip.Entry | null = null;

    for (const entry of entries) {
      if (entry.directory) continue;
      const cleanPath = sanitizeArchivePath(entry.filename);
      if (!cleanPath) continue;
      const baseName = cleanPath.split('/').pop() ?? '';
      if (baseName.startsWith('.') || cleanPath.includes('__MACOSX/')) continue;

      // Reject executables inside archives
      if (/\.(exe|bat|cmd|sh|msi|dll|vbs|ps1|scr)$/i.test(baseName)) {
        throw new Error(`Arquivo suspeito bloqueado por segurança: ${baseName}`);
      }

      if (isImageFilename(baseName)) {
        rawEntries.push({
          path: cleanPath,
          name: baseName,
          size: entry.uncompressedSize ?? 0,
          mimeType: inferMimeFromName(baseName),
          archiveBlobKey: archiveStorageKey,
          entryPath: entry.filename,
        });
      }
    }

    if (rawEntries.length === 0) {
      throw new Error('Nenhuma imagem legível encontrada dentro do arquivo ZIP/CBZ.');
    }

    onProgress(40, `Ordenando ${rawEntries.length} páginas e capítulos...`);
    const fallbackTitle = file.name.replace(/\.(zip|cbz)$/i, '');
    const organized = organizeImportEntries(rawEntries, fallbackTitle);

    // Find first page of chapter 1 for cover thumbnail
    const firstPage = organized.chapters[0]?.pages[0];
    if (firstPage?.entryPath) {
      firstImageEntry = entries.find((e) => e.filename === firstPage.entryPath) ?? null;
    }

    let coverUrl = '';
    if (firstImageEntry && 'getData' in firstImageEntry && firstImageEntry.getData) {
      onProgress(60, 'Gerando miniatura da capa...');
      const coverBlob = await firstImageEntry.getData(new zip.BlobWriter());
      coverUrl = await generateThumbnailDataUrl(coverBlob);
    }

    onProgress(78, 'Salvando arquivo no armazenamento local (streaming)...');
    const savedArchiveKey = await storeBinaryBlob(archiveStorageKey, file);

    const chapters: Chapter[] = organized.chapters.map((ch, idx) => ({
      id: `${workId}-ch-${idx + 1}`,
      title: ch.title,
      chapterNumber: ch.chapterNumber,
      orderIndex: ch.orderIndex,
      totalSize: ch.totalSize,
      pages: ch.pages.map((p, pIdx) => ({
        id: `${workId}-ch-${idx + 1}-p-${pIdx + 1}`,
        name: p.name,
        pageNumber: p.pageNumber,
        mimeType: p.mimeType,
        size: p.size,
        archiveBlobKey: savedArchiveKey,
        entryPath: p.entryPath,
      })),
    }));

    const ext = file.name.split('.').pop()?.toLowerCase() === 'cbz' ? 'cbz' : 'zip';
    const guessed = inferCategoryFromFormat(ext, organized.suggestedTitle);

    onProgress(100, 'Pronto para revisão!');
    return {
      id: workId,
      title: organized.suggestedTitle,
      author: 'Arquivo Local',
      category: guessed.category,
      format: ext,
      readerMode: guessed.readerMode,
      description: `${chapters.length} capítulo(s) · ${organized.verification.totalPages} páginas importadas localmente.`,
      coverUrl: coverUrl || createFallbackCoverDataUrl(organized.suggestedTitle, ext.toUpperCase()),
      chapters,
      verification: organized.verification,
      totalPages: organized.verification.totalPages,
      totalSizeBytes: file.size,
      originalFileName: file.name,
      sourceHash: await sha256Text(`${file.name}:${file.size}:${file.lastModified}`),
      archiveBlobKey: savedArchiveKey,
    };
  } finally {
    await reader.close();
  }
}

export async function processSingleFileForImport(
  file: File,
  onProgress: (pct: number, stage: string) => void
): Promise<ImportPreviewDraft> {
  onProgress(5, 'Validando assinatura real do arquivo...');
  const header = await readMagicHeader(file);
  const sig = detectFileSignature(header, file.name);

  if (sig === 'executable') {
    throw new Error(`Execução bloqueada por segurança: "${file.name}" é um arquivo executável.`);
  }
  if (sig === 'rar') {
    throw new Error(
      `O arquivo "${file.name}" usa compressão proprietária RAR/CBR. Por favor, converta para CBZ ou ZIP para leitura direta sem limites no navegador.`
    );
  }
  if (sig === '7z') {
    throw new Error(
      `O arquivo "${file.name}" está em formato 7Z sólido. Converta para ZIP ou CBZ para leitura em streaming instantânea.`
    );
  }

  const ext = file.name.split('.').pop()?.toLowerCase() ?? '';

  if (sig === 'zip') {
    if (ext === 'epub') return parseEpubArchive(file, onProgress);
    if (ext === 'docx') return parseDocxArchive(file);
    return parseImageArchive(file, onProgress);
  }

  if (sig === 'pdf' || ext === 'pdf') {
    onProgress(50, 'Registrando documento PDF...');
    const workId = `work-${crypto.randomUUID()}`;
    const blobKey = await storeBinaryBlob(`pdf-${workId}`, file);
    const title = file.name.replace(/\.pdf$/i, '');

    let pageCount = 1;
    try {
      const pdfjs = await import('pdfjs-dist');
      pdfjs.GlobalWorkerOptions.workerSrc = new URL(
        'pdfjs-dist/build/pdf.worker.min.mjs',
        import.meta.url
      ).toString();
      const buf = await file.slice(0, Math.min(file.size, 32 * 1024 * 1024)).arrayBuffer();
      const loadingTask = pdfjs.getDocument({ data: buf });
      const doc = await loadingTask.promise;
      pageCount = doc.numPages;
      await loadingTask.destroy();
    } catch {
      pageCount = 1;
    }

    const chapters: Chapter[] = [
      {
        id: `${workId}-pdf`,
        title: 'Documento PDF',
        chapterNumber: 1,
        orderIndex: 0,
        pages: [],
        totalSize: file.size,
      },
    ];

    onProgress(100, 'PDF pronto!');
    return {
      id: workId,
      title,
      author: 'Documento PDF',
      category: 'PDFs',
      format: 'pdf',
      readerMode: 'pdf',
      description: `Documento PDF local com ${pageCount} página(s).`,
      coverUrl: createFallbackCoverDataUrl(title, 'PDF'),
      chapters,
      verification: verifyChapterOrder(chapters),
      totalPages: pageCount,
      totalSizeBytes: file.size,
      originalFileName: file.name,
      sourceHash: await sha256Text(`${file.name}:${file.size}:${file.lastModified}`),
      archiveBlobKey: blobKey,
    };
  }

  if (sig === 'text' || ['txt', 'md', 'rtf', 'html', 'htm'].includes(ext)) {
    onProgress(55, 'Processando texto...');
    const rawText = await file.text();
    let cleanText = rawText;
    if (ext === 'rtf') cleanText = stripRtf(rawText);
    if (ext === 'html' || ext === 'htm') cleanText = decodeHtmlToText(rawText).text;

    const title = file.name.replace(/\.(txt|md|rtf|html?)$/i, '');
    const workId = `work-${crypto.randomUUID()}`;

    // Split long TXT into readable chapters if chapter markers exist, otherwise 1 chapter
    const sections = cleanText.split(/\n(?=(?:Cap[ií]tulo|Chapter)\s+\d+)/i).filter((s) => s.trim());
    const chapters: Chapter[] =
      sections.length > 1
        ? sections.map((sec, idx) => {
            const firstLine = sec.split('\n')[0]?.trim() || `Capítulo ${idx + 1}`;
            return {
              id: `${workId}-ch-${idx + 1}`,
              title: firstLine.slice(0, 80),
              chapterNumber: idx + 1,
              orderIndex: idx,
              pages: [],
              bookContent: { text: sec.trim() },
              totalSize: sec.length,
            };
          })
        : [
            {
              id: `${workId}-ch-1`,
              title: 'Texto Completo',
              chapterNumber: 1,
              orderIndex: 0,
              pages: [],
              bookContent: { text: cleanText.trim() || 'Arquivo vazio.' },
              totalSize: cleanText.length,
            },
          ];

    onProgress(100, 'Documento pronto!');
    return {
      id: workId,
      title,
      author: 'Texto Local',
      category: 'Livros',
      format: ext === 'rtf' ? 'rtf' : ext === 'html' || ext === 'htm' ? 'html' : 'txt',
      readerMode: 'book',
      description: `Texto local importado (${chapters.length} capítulo/seção).`,
      coverUrl: createFallbackCoverDataUrl(title, ext.toUpperCase()),
      chapters,
      verification: verifyChapterOrder(chapters),
      totalPages: chapters.length,
      totalSizeBytes: file.size,
      originalFileName: file.name,
      sourceHash: await sha256Text(`${file.name}:${file.size}:${file.lastModified}`),
    };
  }

  // Single loose image
  if (['png', 'jpg', 'webp', 'gif', 'bmp', 'tiff', 'avif'].includes(sig) || isImageFilename(file.name)) {
    return processBatchImagesForImport([file], onProgress);
  }

  throw new Error(`Formato não suportado diretamente para "${file.name}".`);
}

/**
 * Imports a folder of images or multiple selected image files into an ordered Work.
 */
export async function processBatchImagesForImport(
  files: File[],
  onProgress: (pct: number, stage: string) => void
): Promise<ImportPreviewDraft> {
  const workId = `work-${crypto.randomUUID()}`;
  const rawEntries: RawImportEntry[] = [];
  let totalSize = 0;

  for (let i = 0; i < files.length; i++) {
    const f = files[i];
    const relPath = (f as File & { webkitRelativePath?: string }).webkitRelativePath || f.name;
    if (!isImageFilename(f.name)) continue;

    const header = await readMagicHeader(f, 32);
    const sig = detectFileSignature(header, f.name);
    if (sig === 'executable') continue;

    const blobKey = `img-${workId}-${i}`;
    await storeBinaryBlob(blobKey, f);
    totalSize += f.size;

    rawEntries.push({
      path: relPath,
      name: f.name,
      size: f.size,
      mimeType: f.type || inferMimeFromName(f.name),
      blobKey,
    });

    if (i % 8 === 0) {
      onProgress(15 + Math.round((i / files.length) * 65), `Armazenando imagem ${i + 1} de ${files.length}...`);
    }
  }

  if (rawEntries.length === 0) {
    throw new Error('Nenhuma imagem válida encontrada na seleção.');
  }

  const fallbackTitle = files.length === 1 ? files[0].name.replace(/\.[^.]+$/, '') : 'Pasta Importada';
  const organized = organizeImportEntries(rawEntries, fallbackTitle);

  let coverUrl = '';
  const firstBlobKey = organized.chapters[0]?.pages[0]?.blobKey;
  if (firstBlobKey) {
    const firstFile = files.find((_, idx) => `img-${workId}-${idx}` === firstBlobKey);
    if (firstFile) coverUrl = await generateThumbnailDataUrl(firstFile);
  }

  const chapters: Chapter[] = organized.chapters.map((ch, idx) => ({
    id: `${workId}-ch-${idx + 1}`,
    title: ch.title,
    chapterNumber: ch.chapterNumber,
    orderIndex: ch.orderIndex,
    totalSize: ch.totalSize,
    pages: ch.pages.map((p, pIdx) => ({
      id: `${workId}-ch-${idx + 1}-p-${pIdx + 1}`,
      name: p.name,
      pageNumber: p.pageNumber,
      mimeType: p.mimeType,
      size: p.size,
      blobKey: p.blobKey,
    })),
  }));

  const guessed = inferCategoryFromFormat('images', organized.suggestedTitle);
  onProgress(100, 'Pasta organizada!');

  return {
    id: workId,
    title: organized.suggestedTitle,
    author: 'Acervo Local',
    category: guessed.category,
    format: 'images',
    readerMode: guessed.readerMode,
    description: `${chapters.length} capítulo(s) · ${organized.verification.totalPages} páginas importadas.`,
    coverUrl: coverUrl || createFallbackCoverDataUrl(organized.suggestedTitle, 'IMG'),
    chapters,
    verification: organized.verification,
    totalPages: organized.verification.totalPages,
    totalSizeBytes: totalSize,
    originalFileName: organized.suggestedTitle,
    sourceHash: await sha256Text(`${organized.suggestedTitle}:${files.length}:${totalSize}`),
  };
}

export function finalizeImportDraft(draft: ImportPreviewDraft): Work {
  const now = Date.now();
  return {
    id: draft.id,
    title: draft.title.trim() || 'Obra Sem Título',
    author: draft.author.trim() || 'Desconhecido',
    category: draft.category,
    format: draft.format,
    readerMode: draft.readerMode,
    description: draft.description.trim(),
    coverUrl: draft.coverUrl,
    isFavorite: false,
    isSample: false,
    tags: [draft.category, draft.format.toUpperCase()],
    chapters: draft.chapters.map((ch, idx) => ({ ...ch, orderIndex: idx })),
    totalPages: draft.totalPages,
    totalSizeBytes: draft.totalSizeBytes,
    archiveBlobKey: draft.archiveBlobKey,
    originalFileName: draft.originalFileName,
    sourceHash: draft.sourceHash,
    createdAt: now,
    updatedAt: now,
  };
}
