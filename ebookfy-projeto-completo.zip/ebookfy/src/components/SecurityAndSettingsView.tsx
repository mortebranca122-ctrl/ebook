import React, { useState } from 'react';
import {
  CheckCircle2,
  Download,
  KeyRound,
  Lock,
  MonitorSmartphone,
  Moon,
  Shield,
  Sun,
  Unlock,
} from 'lucide-react';
import type { ReaderSettings, SecuritySettings } from '../types/ebookfy';
import { generateRecoveryCode, generateSaltHex, hashPassword, sha256Text, verifyPassword } from '../utils/crypto';
import { usePWAInstall } from '../hooks/usePWAInstall';

export const SecurityView: React.FC<{
  security: SecuritySettings;
  onUpdateSecurity: (next: SecuritySettings) => void;
  onLockNow: () => void;
}> = ({ security, onUpdateSecurity, onLockNow }) => {
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [currentPass, setCurrentPass] = useState('');
  const [recoveryShown, setRecoveryShown] = useState<string | null>(null);
  const [message, setMessage] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);

  const handleEnableOrChange = async (e: React.FormEvent) => {
    e.preventDefault();
    setMessage(null);

    if (security.lockEnabled && security.passwordHash && security.passwordSalt) {
      const ok = await verifyPassword(currentPass, security.passwordSalt, security.passwordHash);
      if (!ok) {
        setMessage({ type: 'err', text: 'Senha atual incorreta.' });
        return;
      }
    }

    if (password.length < 4) {
      setMessage({ type: 'err', text: 'A senha deve ter pelo menos 4 caracteres.' });
      return;
    }
    if (password !== confirm) {
      setMessage({ type: 'err', text: 'A confirmação de senha não confere.' });
      return;
    }

    const salt = generateSaltHex();
    const hash = await hashPassword(password, salt);
    const recovery = generateRecoveryCode();
    const recoveryHash = await sha256Text(recovery);

    onUpdateSecurity({
      ...security,
      lockEnabled: true,
      passwordSalt: salt,
      passwordHash: hash,
      recoveryCodeHash: recoveryHash,
    });

    setPassword('');
    setConfirm('');
    setCurrentPass('');
    setRecoveryShown(recovery);
    setMessage({
      type: 'ok',
      text: 'Senha protegida com hash PBKDF2-SHA256 salva localmente.',
    });
  };

  const handleDisable = async () => {
    if (security.passwordHash && security.passwordSalt) {
      const ok = await verifyPassword(currentPass, security.passwordSalt, security.passwordHash);
      if (!ok) {
        setMessage({ type: 'err', text: 'Informe a senha atual para desativar o bloqueio.' });
        return;
      }
    }
    onUpdateSecurity({
      ...security,
      lockEnabled: false,
      passwordHash: null,
      passwordSalt: null,
      recoveryCodeHash: null,
    });
    setCurrentPass('');
    setMessage({ type: 'ok', text: 'Bloqueio por senha desativado.' });
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-xl sm:text-2xl font-semibold text-white">Segurança & Privacidade</h1>
          <p className="text-xs text-[#bfa9b0] mt-0.5">
            Bloqueio local opcional com criptografia PBKDF2-SHA256. Nenhuma senha é armazenada em texto puro.
          </p>
        </div>

        {security.lockEnabled && (
          <button
            type="button"
            onClick={onLockNow}
            className="px-4 py-2 rounded-xl bg-red-950/50 border border-red-700/50 text-xs font-semibold text-white inline-flex items-center gap-2 cursor-pointer"
          >
            <Lock className="w-3.5 h-3.5 text-red-400" />
            <span>Bloquear agora</span>
          </button>
        )}
      </div>

      {message && (
        <div
          className={`eb-surface p-3.5 text-xs ${
            message.type === 'ok' ? 'border-emerald-700/60 text-emerald-300' : 'border-red-600 text-red-300'
          }`}
        >
          {message.text}
        </div>
      )}

      {recoveryShown && (
        <div className="eb-surface p-4 border-amber-600/50 space-y-2">
          <p className="text-xs font-semibold text-amber-300 flex items-center gap-1.5">
            <KeyRound className="w-4 h-4" />
            <span>Código de recuperação local (anote em local seguro):</span>
          </p>
          <p className="font-mono-nums text-base font-bold text-white tracking-wider">{recoveryShown}</p>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        <form onSubmit={handleEnableOrChange} className="eb-surface p-5 space-y-4">
          <h2 className="text-sm font-semibold text-white flex items-center gap-2">
            <Shield className="w-4 h-4 text-red-400" />
            <span>{security.lockEnabled ? 'Alterar ou desativar senha' : 'Ativar bloqueio por senha'}</span>
          </h2>

          {security.lockEnabled && (
            <div>
              <label htmlFor="sec-current-pass" className="block text-xs text-[#bfa9b0] mb-1">
                Senha atual
              </label>
              <input
                id="sec-current-pass"
                type="password"
                value={currentPass}
                onChange={(e) => setCurrentPass(e.target.value)}
                className="w-full px-3 py-2 rounded-lg bg-black/50 border border-red-900/40 text-sm text-white"
              />
            </div>
          )}

          <div>
            <label htmlFor="sec-new-pass" className="block text-xs text-[#bfa9b0] mb-1">
              Nova senha
            </label>
            <input
              id="sec-new-pass"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Mínimo 4 caracteres"
              className="w-full px-3 py-2 rounded-lg bg-black/50 border border-red-900/40 text-sm text-white"
            />
          </div>

          <div>
            <label htmlFor="sec-confirm-pass" className="block text-xs text-[#bfa9b0] mb-1">
              Confirmar nova senha
            </label>
            <input
              id="sec-confirm-pass"
              type="password"
              value={confirm}
              onChange={(e) => setConfirm(e.target.value)}
              className="w-full px-3 py-2 rounded-lg bg-black/50 border border-red-900/40 text-sm text-white"
            />
          </div>

          <div className="flex flex-wrap gap-2 pt-1">
            <button type="submit" className="eb-accent-btn px-4 py-2 rounded-xl text-xs font-semibold cursor-pointer">
              {security.lockEnabled ? 'Atualizar senha' : 'Ativar proteção'}
            </button>
            {security.lockEnabled && (
              <button
                type="button"
                onClick={handleDisable}
                className="px-4 py-2 rounded-xl border border-white/15 text-xs text-[#d4c0c6] hover:text-white inline-flex items-center gap-1.5 cursor-pointer"
              >
                <Unlock className="w-3.5 h-3.5" />
                <span>Desativar bloqueio</span>
              </button>
            )}
          </div>
        </form>

        <section className="eb-surface p-5 space-y-4">
          <h2 className="text-sm font-semibold text-white">Comportamento da sessão</h2>
          <p className="text-xs text-[#bfa9b0] leading-relaxed">
            Por padrão, o Ebookfy não pede senha ao alternar de janela ou minimizar rapidamente, exigindo senha
            apenas ao iniciar uma nova sessão ou após inatividade configurada.
          </p>

          <div>
            <label className="block text-xs text-[#bfa9b0] mb-1.5">Bloqueio automático por inatividade</label>
            <select
              value={security.inactivityMinutes}
              onChange={(e) =>
                onUpdateSecurity({ ...security, inactivityMinutes: Number(e.target.value) })
              }
              className="w-full px-3 py-2 rounded-lg bg-[#12080c] border border-red-900/40 text-xs text-white"
            >
              <option value={0}>Apenas ao abrir novamente o aplicativo</option>
              <option value={5}>Após 5 minutos sem atividade</option>
              <option value={15}>Após 15 minutos sem atividade</option>
              <option value={30}>Após 30 minutos sem atividade</option>
            </select>
          </div>
        </section>
      </div>
    </div>
  );
};

export const SettingsView: React.FC<{
  readerSettings: ReaderSettings;
  onUpdateReaderSettings: (next: ReaderSettings) => void;
  onResetSamples: () => void;
  onClearSamplesOnly: () => void;
}> = ({ readerSettings, onUpdateReaderSettings, onResetSamples, onClearSamplesOnly }) => {
  const { isInstallable, isInstalled, isIOS, isOnline, install } = usePWAInstall();
  const [showIOSGuide, setShowIOSGuide] = useState(false);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl sm:text-2xl font-semibold text-white">Configurações</h1>
        <p className="text-xs text-[#bfa9b0] mt-0.5">
          Preferências padrão dos leitores, instalação offline (Windows & Android) e gerenciamento de demonstração.
        </p>
      </div>

      {/* PWA / Multiplatform Install Card */}
      <section className="eb-surface p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="space-y-1">
          <h2 className="text-sm font-semibold text-white flex items-center gap-2">
            <MonitorSmartphone className="w-4 h-4 text-red-400" />
            <span>Aplicativo Offline para PC & Celular</span>
          </h2>
          <p className="text-xs text-[#bfa9b0]">
            {isInstalled
              ? 'Ebookfy já está instalado em modo aplicativo autônomo.'
              : 'Instale o Ebookfy diretamente no Windows ou Android para leitura 100% offline em tela cheia.'}
            {' · '}Estado atual: {isOnline ? 'Conectado' : 'Modo Offline ativo'}
          </p>
        </div>

        <div className="shrink-0">
          {!isInstalled && isInstallable && (
            <button
              type="button"
              onClick={install}
              className="eb-accent-btn px-4 py-2.5 rounded-xl text-xs font-semibold inline-flex items-center gap-2 cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>Instalar Ebookfy</span>
            </button>
          )}
          {!isInstalled && isIOS && (
            <button
              type="button"
              onClick={() => setShowIOSGuide(true)}
              className="px-4 py-2 rounded-xl border border-red-800/50 text-xs font-medium text-white cursor-pointer"
            >
              Instalar no iOS / Safari
            </button>
          )}
          {isInstalled && (
            <span className="inline-flex items-center gap-1.5 text-xs text-emerald-400 font-medium">
              <CheckCircle2 className="w-4 h-4" /> Instalado
            </span>
          )}
        </div>
      </section>

      {showIOSGuide && (
        <div className="eb-surface p-4 border-red-700/50 space-y-2 text-xs text-[#d4c0c6]">
          <p className="font-semibold text-white">Instalação no iPhone / iPad</p>
          <p>1. Toque no botão Compartilhar no Safari. 2. Selecione &quot;Adicionar à Tela de Início&quot;.</p>
          <button
            type="button"
            onClick={() => setShowIOSGuide(false)}
            className="px-3 py-1 rounded bg-white/10 text-white cursor-pointer"
          >
            Fechar
          </button>
        </div>
      )}

      {/* Book & Manga Reader Defaults */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        <section className="eb-surface p-5 space-y-4">
          <h2 className="text-sm font-semibold text-white">Leitor de Livros (Claro & Escuro)</h2>
          <p className="text-xs text-[#bfa9b0]">
            No modo escuro para livros, o fundo é preto profundo com letras brancas para leitura noturna confortável.
          </p>

          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => onUpdateReaderSettings({ ...readerSettings, bookTheme: 'dark' })}
              className={`py-2.5 px-3 rounded-xl border text-xs font-medium inline-flex items-center justify-center gap-2 cursor-pointer ${
                readerSettings.bookTheme === 'dark'
                  ? 'bg-black border-red-500 text-white'
                  : 'bg-white/[0.03] border-white/10 text-[#bfa9b0]'
              }`}
            >
              <Moon className="w-4 h-4 text-red-400" />
              <span>Escuro (Preto + Branco)</span>
            </button>
            <button
              type="button"
              onClick={() => onUpdateReaderSettings({ ...readerSettings, bookTheme: 'light' })}
              className={`py-2.5 px-3 rounded-xl border text-xs font-medium inline-flex items-center justify-center gap-2 cursor-pointer ${
                readerSettings.bookTheme === 'light'
                  ? 'bg-[#FAF7F2] border-red-500 text-[#171416]'
                  : 'bg-white/[0.03] border-white/10 text-[#bfa9b0]'
              }`}
            >
              <Sun className="w-4 h-4 text-amber-500" />
              <span>Modo Claro</span>
            </button>
          </div>
        </section>

        <section className="eb-surface p-5 space-y-4">
          <h2 className="text-sm font-semibold text-white">Acervo de Demonstração</h2>
          <p className="text-xs text-[#bfa9b0]">
            Gerencie as obras de demonstração iniciais sem afetar os arquivos que você importou.
          </p>
          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              onClick={onClearSamplesOnly}
              className="px-3.5 py-2 rounded-xl border border-red-900/45 text-xs font-medium text-red-300 hover:bg-red-950/40 cursor-pointer"
            >
              Remover obras de exemplo
            </button>
            <button
              type="button"
              onClick={onResetSamples}
              className="px-3.5 py-2 rounded-xl border border-white/15 text-xs font-medium text-[#d4c0c6] hover:text-white cursor-pointer"
            >
              Restaurar exemplos iniciais
            </button>
          </div>
        </section>
      </div>
    </div>
  );
};
