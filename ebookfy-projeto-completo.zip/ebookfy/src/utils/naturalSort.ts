export interface RawImportEntry {
  path: string;
  name: string;
  size: number;
  mimeType: string;
  blobKey?: string;
  archiveBlobKey?: string;
  entryPath?: string;
}

export interface OrganizedPage {
  name: string;
  path: string;
  pageNumber: number;
  mimeType: string;
  size: number;
  blobKey?: string;
  archiveBlobKey?: string;
  entryPath?: string;
}

export interface OrganizedChapter {
  title: string;
  chapterNumber: number | null;
  orderIndex: number;
  pages: OrganizedPage[];
  totalSize: number;
}

export interface ChapterOrderVerification {
  isSequential: boolean;
  detectedNumbers: number[];
  missingChapters: number[];
  duplicateChapters: number[];
  totalChapters: number;
  totalPages: number;
}

export type SignatureKind =
  | 'png'
  | 'jpg'
  | 'webp'
  | 'gif'
  | 'bmp'
  | 'tiff'
  | 'avif'
  | 'pdf'
  | 'zip'
  | 'rar'
  | '7z'
  | 'tar'
  | 'gzip'
  | 'text'
  | 'executable'
  | 'unknown';

/**
 * Natural alphanumeric comparator: ensures 1.jpg, 2.jpg, 10.jpg, page_002, Página 10
 * sort numerically rather than lexicographically.
 */
export function naturalCompare(a: string, b: string): number {
  const tokenRegex = /(\d+(?:[.,]\d+)?)|([^\d]+)/g;
  const tokensA = a.toLowerCase().match(tokenRegex) ?? [];
  const tokensB = b.toLowerCase().match(tokenRegex) ?? [];
  const len = Math.max(tokensA.length, tokensB.length);

  for (let i = 0; i < len; i++) {
    const ta = tokensA[i];
    const tb = tokensB[i];
    if (ta === undefined) return -1;
    if (tb === undefined) return 1;

    const numA = parseFloat(ta.replace(',', '.'));
    const numB = parseFloat(tb.replace(',', '.'));
    const isNumA = /^\d+(?:[.,]\d+)?$/.test(ta) && !Number.isNaN(numA);
    const isNumB = /^\d+(?:[.,]\d+)?$/.test(tb) && !Number.isNaN(numB);

    if (isNumA && isNumB) {
      if (numA !== numB) return numA - numB;
      // If numerically equal (e.g. "01" vs "001"), prefer shorter or lexicographical tie-break
      if (ta.length !== tb.length) return ta.length - tb.length;
    } else if (isNumA !== isNumB) {
      return isNumA ? -1 : 1;
    } else {
      const cmp = ta.localeCompare(tb, 'pt-BR', { sensitivity: 'base' });
      if (cmp !== 0) return cmp;
    }
  }
  return 0;
}

export interface ExtractedChapterMeta {
  chapterNumber: number | null;
  volumeNumber: number | null;
  label: string;
}

/**
 * Parses chapter numbers from folder or file names such as:
 * "Capítulo 001", "Cap. 12", "Ch 03", "Chapter 4.5", "c010", "Episódio 2", "005"
 */
export function extractChapterInfo(segment: string): ExtractedChapterMeta {
  const clean = segment
    .replace(/\.[a-z0-9]{2,5}$/i, '')
    .replace(/[_]+/g, ' ')
    .trim();

  let volumeNumber: number | null = null;
  const volMatch = clean.match(/(?:vol(?:ume)?|v)\.?\s*(\d+(?:[.,]\d+)?)/i);
  if (volMatch) {
    volumeNumber = parseFloat(volMatch[1].replace(',', '.'));
  }

  // Explicit chapter markers take top priority
  const chapRegex =
    /(?:cap[ií]tulo|cap\.?|chapter|ch\.?|epis[oó]dio|ep\.?|tomo)\s*[-:#]?\s*(\d+(?:[.,]\d+)?)/i;
  const chapMatch = clean.match(chapRegex);
  if (chapMatch) {
    const num = parseFloat(chapMatch[1].replace(',', '.'));
    return {
      chapterNumber: num,
      volumeNumber,
      label: `Capítulo ${formatChapterNum(num)}`,
    };
  }

  // Compact prefix like c001 or ch012
  const compactMatch = clean.match(/(?:^|\s)[c](\d{1,4})(?:\s|$|-)/i);
  if (compactMatch) {
    const num = parseInt(compactMatch[1], 10);
    return {
      chapterNumber: num,
      volumeNumber,
      label: `Capítulo ${formatChapterNum(num)}`,
    };
  }

  // Standalone numeric folder or leading digits e.g. "001", "12 - A Queda"
  const leadingNum = clean.match(/^(\d+(?:[.,]\d+)?)(?:\s*[-–.]\s*.*)?$/);
  if (leadingNum) {
    const num = parseFloat(leadingNum[1].replace(',', '.'));
    return {
      chapterNumber: num,
      volumeNumber,
      label: `Capítulo ${formatChapterNum(num)}`,
    };
  }

  return {
    chapterNumber: null,
    volumeNumber,
    label: clean || 'Capítulo 1',
  };
}

function formatChapterNum(n: number): string {
  return Number.isInteger(n) ? String(n) : String(n).replace('.', ',');
}

/**
 * Sanitizes archive entry paths against path traversal (`..`), null bytes, and leading slashes.
 */
export function sanitizeArchivePath(rawPath: string): string | null {
  if (!rawPath || rawPath.includes('\0')) return null;
  const normalized = rawPath.replace(/\\/g, '/').replace(/^\/+/, '');
  const parts = normalized.split('/').filter((p) => p.length > 0 && p !== '.');
  if (parts.length === 0) return null;
  if (parts.some((p) => p === '..')) return null;
  return parts.join('/');
}

/**
 * Detects real file format using magic bytes rather than trusting extension alone.
 */
export function detectFileSignature(bytes: Uint8Array, filename = ''): SignatureKind {
  if (bytes.length >= 2) {
    // Windows PE executable (MZ) or Unix ELF or Shebang script -> BLOCK
    if (bytes[0] === 0x4d && bytes[1] === 0x5a) return 'executable';
    if (bytes.length >= 4 && bytes[0] === 0x7f && bytes[1] === 0x45 && bytes[2] === 0x4c && bytes[3] === 0x46) {
      return 'executable';
    }
    if (bytes[0] === 0x23 && bytes[1] === 0x21) return 'executable';
  }

  // PNG: 89 50 4E 47 0D 0A 1A 0A
  if (
    bytes.length >= 8 &&
    bytes[0] === 0x89 &&
    bytes[1] === 0x50 &&
    bytes[2] === 0x4e &&
    bytes[3] === 0x47
  ) {
    return 'png';
  }
  // JPG: FF D8 FF
  if (bytes.length >= 3 && bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff) {
    return 'jpg';
  }
  // GIF: GIF87a / GIF89a
  if (
    bytes.length >= 6 &&
    bytes[0] === 0x47 &&
    bytes[1] === 0x49 &&
    bytes[2] === 0x46 &&
    bytes[3] === 0x38
  ) {
    return 'gif';
  }
  // WEBP: RIFF....WEBP
  if (
    bytes.length >= 12 &&
    bytes[0] === 0x52 &&
    bytes[1] === 0x49 &&
    bytes[2] === 0x46 &&
    bytes[3] === 0x46 &&
    bytes[8] === 0x57 &&
    bytes[9] === 0x45 &&
    bytes[10] === 0x42 &&
    bytes[11] === 0x50
  ) {
    return 'webp';
  }
  // BMP: BM
  if (bytes.length >= 2 && bytes[0] === 0x42 && bytes[1] === 0x4d) {
    return 'bmp';
  }
  // TIFF: II*\0 or MM\0*
  if (
    bytes.length >= 4 &&
    ((bytes[0] === 0x49 && bytes[1] === 0x49 && bytes[2] === 0x2a && bytes[3] === 0x00) ||
      (bytes[0] === 0x4d && bytes[1] === 0x4d && bytes[2] === 0x00 && bytes[3] === 0x2a))
  ) {
    return 'tiff';
  }
  // AVIF: ftypavif / ftypavis
  if (bytes.length >= 12 && bytes[4] === 0x66 && bytes[5] === 0x74 && bytes[6] === 0x79 && bytes[7] === 0x70) {
    const brand = String.fromCharCode(bytes[8], bytes[9], bytes[10], bytes[11]);
    if (brand === 'avif' || brand === 'avis' || brand === 'mif1') return 'avif';
  }
  // PDF: %PDF-
  if (
    bytes.length >= 5 &&
    bytes[0] === 0x25 &&
    bytes[1] === 0x50 &&
    bytes[2] === 0x44 &&
    bytes[3] === 0x46 &&
    bytes[4] === 0x2d
  ) {
    return 'pdf';
  }
  // ZIP / CBZ / EPUB / DOCX / ODT: PK\x03\x04 or PK\x05\x06
  if (
    bytes.length >= 4 &&
    bytes[0] === 0x50 &&
    bytes[1] === 0x4b &&
    ((bytes[2] === 0x03 && bytes[3] === 0x04) || (bytes[2] === 0x05 && bytes[3] === 0x06))
  ) {
    return 'zip';
  }
  // RAR: Rar!
  if (bytes.length >= 4 && bytes[0] === 0x52 && bytes[1] === 0x61 && bytes[2] === 0x72 && bytes[3] === 0x21) {
    return 'rar';
  }
  // 7Z: 37 7A BC AF 27 1C
  if (
    bytes.length >= 6 &&
    bytes[0] === 0x37 &&
    bytes[1] === 0x7a &&
    bytes[2] === 0xbc &&
    bytes[3] === 0xaf
  ) {
    return '7z';
  }
  // GZIP: 1F 8B
  if (bytes.length >= 2 && bytes[0] === 0x1f && bytes[1] === 0x8b) {
    return 'gzip';
  }

  const ext = filename.split('.').pop()?.toLowerCase() ?? '';
  if (['txt', 'md', 'rtf', 'html', 'htm', 'xhtml'].includes(ext)) {
    return 'text';
  }
  return 'unknown';
}

export function isImageFilename(name: string): boolean {
  return /\.(png|jpe?g|webp|gif|bmp|tiff?|avif)$/i.test(name);
}

/**
 * Groups raw image entries into ordered Chapters (`Capítulo 1, 2, 3...`) and naturally-sorted pages.
 * Strips shared root wrapper folder if present (e.g. "Solo Leveling/Cap 01/1.jpg").
 */
export function organizeImportEntries(
  entries: RawImportEntry[],
  fallbackWorkTitle = 'Obra Importada'
): {
  suggestedTitle: string;
  chapters: OrganizedChapter[];
  verification: ChapterOrderVerification;
} {
  const validEntries = entries
    .map((e) => ({ ...e, cleanPath: sanitizeArchivePath(e.path) }))
    .filter((e): e is RawImportEntry & { cleanPath: string } => {
      if (!e.cleanPath) return false;
      const base = e.cleanPath.split('/').pop() ?? '';
      if (base.startsWith('.') || base.startsWith('__MACOSX') || e.cleanPath.includes('__MACOSX/')) {
        return false;
      }
      return isImageFilename(base);
    });

  if (validEntries.length === 0) {
    return {
      suggestedTitle: fallbackWorkTitle,
      chapters: [],
      verification: {
        isSequential: true,
        detectedNumbers: [],
        missingChapters: [],
        duplicateChapters: [],
        totalChapters: 0,
        totalPages: 0,
      },
    };
  }

  // Determine if all paths share a single root folder (like "Obra/Cap 01/01.jpg")
  const splitPaths = validEntries.map((e) => e.cleanPath.split('/'));
  const firstSegments = new Set(splitPaths.map((s) => (s.length > 1 ? s[0] : '')));
  let suggestedTitle = fallbackWorkTitle;
  const stripRoot = firstSegments.size === 1 && !firstSegments.has('');

  if (stripRoot) {
    const rootName = splitPaths[0][0];
    // Only strip root if it isn't itself a chapter folder when there are subfolders
    const hasSubfolders = splitPaths.some((s) => s.length >= 3);
    if (hasSubfolders) {
      suggestedTitle = rootName;
    }
  }

  const chapterMap = new Map<
    string,
    {
      rawKey: string;
      meta: ExtractedChapterMeta;
      pages: RawImportEntry[];
    }
  >();

  for (const entry of validEntries) {
    const parts = entry.cleanPath.split('/');
    const hasSubfolders = splitPaths.some((s) => s.length >= 3);
    const effectiveParts = stripRoot && hasSubfolders ? parts.slice(1) : parts;

    let groupKey = 'Capítulo 1';
    let meta: ExtractedChapterMeta = { chapterNumber: 1, volumeNumber: null, label: 'Capítulo 1' };

    if (effectiveParts.length >= 2) {
      // Use parent folder as chapter identifier
      const folderName = effectiveParts.slice(0, -1).join(' / ');
      groupKey = folderName;
      meta = extractChapterInfo(effectiveParts[effectiveParts.length - 2]);
      if (meta.chapterNumber === null && effectiveParts.length >= 2) {
        meta = { ...meta, label: folderName };
      }
    } else {
      // Flat images: check if filename itself encodes chapter like "cap02_pag01.jpg" or "02-001.jpg"
      const fileName = effectiveParts[0];
      const prefixChap = fileName.match(
        /^(?:cap[ií]tulo|cap|ch|c)[._\-\s]*(\d+)[._\-\s]+(.+)$/i
      );
      if (prefixChap) {
        const cNum = parseInt(prefixChap[1], 10);
        groupKey = `Capítulo ${cNum}`;
        meta = { chapterNumber: cNum, volumeNumber: null, label: `Capítulo ${cNum}` };
      }
    }

    const existing = chapterMap.get(groupKey);
    if (existing) {
      existing.pages.push(entry);
    } else {
      chapterMap.set(groupKey, { rawKey: groupKey, meta, pages: [entry] });
    }
  }

  const sortedGroups = Array.from(chapterMap.values()).sort((a, b) => {
    if (a.meta.volumeNumber !== null && b.meta.volumeNumber !== null) {
      if (a.meta.volumeNumber !== b.meta.volumeNumber) {
        return a.meta.volumeNumber - b.meta.volumeNumber;
      }
    }
    if (a.meta.chapterNumber !== null && b.meta.chapterNumber !== null) {
      if (a.meta.chapterNumber !== b.meta.chapterNumber) {
        return a.meta.chapterNumber - b.meta.chapterNumber;
      }
    } else if (a.meta.chapterNumber !== null) {
      return -1;
    } else if (b.meta.chapterNumber !== null) {
      return 1;
    }
    return naturalCompare(a.rawKey, b.rawKey);
  });

  const chapters: OrganizedChapter[] = sortedGroups.map((group, idx) => {
    const sortedPages = [...group.pages].sort((p1, p2) => naturalCompare(p1.name, p2.name));
    const pages: OrganizedPage[] = sortedPages.map((p, pageIdx) => ({
      name: p.name,
      path: p.path,
      pageNumber: pageIdx + 1,
      mimeType: p.mimeType,
      size: p.size,
      blobKey: p.blobKey,
      archiveBlobKey: p.archiveBlobKey,
      entryPath: p.entryPath,
    }));

    const totalSize = pages.reduce((acc, p) => acc + p.size, 0);
    return {
      title: group.meta.label,
      chapterNumber: group.meta.chapterNumber,
      orderIndex: idx,
      pages,
      totalSize,
    };
  });

  const verification = verifyChapterOrder(chapters);
  return { suggestedTitle, chapters, verification };
}

/**
 * Verifies chapter numbering sequence (e.g. 1, 2, 3, 4, 5), flagging missing or duplicate chapters.
 */
export function verifyChapterOrder(
  chapters: ReadonlyArray<{ chapterNumber: number | null; pages: ReadonlyArray<unknown> }>
): ChapterOrderVerification {
  const nums = chapters
    .map((c) => c.chapterNumber)
    .filter((n): n is number => n !== null && Number.isFinite(n));

  const counts = new Map<number, number>();
  for (const n of nums) {
    counts.set(n, (counts.get(n) ?? 0) + 1);
  }
  const duplicateChapters = Array.from(counts.entries())
    .filter(([, count]) => count > 1)
    .map(([num]) => num)
    .sort((a, b) => a - b);

  const intNums = Array.from(new Set(nums.filter((n) => Number.isInteger(n)))).sort((a, b) => a - b);
  const missingChapters: number[] = [];
  if (intNums.length > 1) {
    const min = intNums[0];
    const max = intNums[intNums.length - 1];
    // Cap gap scan to reasonable range to avoid huge loops on typos like chapter 99999
    if (max - min <= 2000) {
      const set = new Set(intNums);
      for (let i = min; i <= max; i++) {
        if (!set.has(i)) missingChapters.push(i);
      }
    }
  }

  const totalPages = chapters.reduce((sum, ch) => sum + ch.pages.length, 0);
  const isSequential = missingChapters.length === 0 && duplicateChapters.length === 0;

  return {
    isSequential,
    detectedNumbers: intNums,
    missingChapters,
    duplicateChapters,
    totalChapters: chapters.length,
    totalPages,
  };
}
