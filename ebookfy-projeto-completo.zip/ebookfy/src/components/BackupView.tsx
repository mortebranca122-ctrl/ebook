import React, { useRef, useState } from 'react';
import {
  ArchiveRestore,
  CheckCircle2,
  Download,
  FileUp,
  Loader2,
  ShieldAlert,
} from 'lucide-react';
import type {
  Collection,
  HistoryEntry,
  ReaderSettings,
  ReadingProgress,
  ThemeSettings,
  Work,
} from '../types/ebookfy';
import {
  createBackupZip,
  inspectBackupZip,
  restoreBackupBlobs,
  type InspectedBackup,
} from '../services/backup';
import { formatBytes } from '../utils/formatters';

interface BackupViewProps {
  works: Work[];
  progress: ReadingProgress[];
  collections: Collection[];
  history: HistoryEntry[];
  themeSettings: ThemeSettings;
  readerSettings: ReaderSettings;
  onRestoreComplete: (data: {
    works: Work[];
    progress: ReadingProgress[];
    collections: Collection[];
    history: HistoryEntry[];
    themeSettings?: ThemeSettings;
    readerSettings?: ReaderSettings;
    mode: 'merge' | 'overwrite';
  }) => void;
}

export const BackupView: React.FC<BackupViewProps> = ({
  works,
  progress,
  collections,
  history,
  themeSettings,
  readerSettings,
  onRestoreComplete,
}) => {
  const [backupMode, setBackupMode] = useState<'full' | 'metadata' | 'selected'>('full');
  const [selectedWorkIds, setSelectedWorkIds] = useState<Set<string>>(new Set());
  const [includeFiles, setIncludeFiles] = useState(true);
  const [includeHistory, setIncludeHistory] = useState(true);
  const [exporting, setExporting] = useState(false);
  const [statusMsg, setStatusMsg] = useState<string | null>(null);

  const [pendingFile, setPendingFile] = useState<File | null>(null);
  const [inspected, setInspected] = useState<InspectedBackup | null>(null);
  const [conflictMode, setConflictMode] = useState<'merge' | 'overwrite'>('merge');
  const [restoring, setRestoring] = useState(false);

  const restoreInputRef = useRef<HTMLInputElement | null>(null);

  const handleExport = async () => {
    setExporting(true);
    setStatusMsg(null);
    try {
      const targetWorks =
        backupMode === 'selected' ? works.filter((w) => selectedWorkIds.has(w.id)) : works;
      const targetIds = new Set(targetWorks.map((w) => w.id));
      const targetProgress = progress.filter((p) => targetIds.has(p.workId));

      const blob = await createBackupZip({
        works: backupMode === 'metadata' ? targetWorks : targetWorks,
        progress: targetProgress,
        collections,
        history,
        themeSettings,
        readerSettings,
        mode: backupMode,
        includeFiles: backupMode === 'metadata' ? false : includeFiles,
        includeHistory,
      });

      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `ebookfy-backup-${new Date().toISOString().slice(0, 10)}.zip`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 4000);
      setStatusMsg(`Backup ZIP gerado com sucesso (${formatBytes(blob.size)}).`);
    } catch (err) {
      setStatusMsg(err instanceof Error ? err.message : 'Erro ao gerar backup.');
    } finally {
      setExporting(false);
    }
  };

  const handleSelectBackupFile = async (file: File) => {
    setStatusMsg(null);
    try {
      const res = await inspectBackupZip(file);
      setPendingFile(file);
      setInspected(res);
    } catch (err) {
      setStatusMsg(err instanceof Error ? err.message : 'Backup inválido.');
    }
  };

  const handleConfirmRestore = async () => {
    if (!inspected || !pendingFile) return;
    setRestoring(true);
    try {
      const remapped = await restoreBackupBlobs(pendingFile);
      const remappedWorks = inspected.payload.works.map((w) => ({
        ...w,
        archiveBlobKey: w.archiveBlobKey ? remapped.get(w.archiveBlobKey) ?? w.archiveBlobKey : undefined,
        chapters: w.chapters.map((ch) => ({
          ...ch,
          pages: ch.pages.map((p) => ({
            ...p,
            blobKey: p.blobKey ? remapped.get(p.blobKey) ?? p.blobKey : undefined,
            archiveBlobKey: p.archiveBlobKey
              ? remapped.get(p.archiveBlobKey) ?? p.archiveBlobKey
              : undefined,
          })),
        })),
      }));

      onRestoreComplete({
        works: remappedWorks,
        progress: inspected.payload.progress,
        collections: inspected.payload.collections,
        history: inspected.payload.history,
        themeSettings: inspected.payload.themeSettings,
        readerSettings: inspected.payload.readerSettings,
        mode: conflictMode,
      });

      setInspected(null);
      setPendingFile(null);
      setStatusMsg('Backup restaurado localmente com sucesso!');
    } catch (err) {
      setStatusMsg(err instanceof Error ? err.message : 'Falha ao restaurar backup.');
    } finally {
      setRestoring(false);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl sm:text-2xl font-semibold text-white">Backup & Restauração Local</h1>
        <p className="text-xs sm:text-sm text-[#bfa9b0] mt-0.5">
          Exporte um pacote ZIP offline para transferir sua biblioteca manualmente entre Windows e Android, sem
          nuvem ou internet.
        </p>
      </div>

      {statusMsg && (
        <div className="eb-surface p-3.5 text-xs text-white border-red-600/50 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{statusMsg}</span>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Export */}
        <section className="eb-surface p-5 space-y-4">
          <h2 className="text-base font-semibold text-white flex items-center gap-2">
            <Download className="w-4 h-4 text-red-400" />
            <span>Exportar Backup (.zip)</span>
          </h2>

          <div className="grid grid-cols-3 gap-2">
            {[
              { id: 'full', label: 'Completo' },
              { id: 'metadata', label: 'Só Dados' },
              { id: 'selected', label: 'Selecionadas' },
            ].map((m) => (
              <button
                key={m.id}
                type="button"
                onClick={() => setBackupMode(m.id as typeof backupMode)}
                className={`py-2 rounded-lg text-xs font-medium border cursor-pointer ${
                  backupMode === m.id
                    ? 'bg-red-800/45 border-red-500 text-white'
                    : 'bg-white/[0.03] border-white/10 text-[#bfa9b0]'
                }`}
              >
                {m.label}
              </button>
            ))}
          </div>

          {backupMode === 'selected' && (
            <div className="max-h-40 overflow-y-auto space-y-1.5 bg-black/30 rounded-xl p-3">
              {works.map((w) => (
                <label key={w.id} className="flex items-center gap-2 text-xs text-[#e5d5da] cursor-pointer">
                  <input
                    type="checkbox"
                    checked={selectedWorkIds.has(w.id)}
                    onChange={(e) => {
                      setSelectedWorkIds((prev) => {
                        const next = new Set(prev);
                        if (e.target.checked) next.add(w.id);
                        else next.delete(w.id);
                        return next;
                      });
                    }}
                    className="accent-red-600"
                  />
                  <span className="truncate">{w.title}</span>
                </label>
              ))}
            </div>
          )}

          <div className="space-y-2 pt-1">
            {backupMode !== 'metadata' && (
              <label className="flex items-center gap-2 text-xs text-[#d4c0c6] cursor-pointer">
                <input
                  type="checkbox"
                  checked={includeFiles}
                  onChange={(e) => setIncludeFiles(e.target.checked)}
                  className="accent-red-600"
                />
                <span>Incluir arquivos importados (ZIPs, PDFs, EPUBs e imagens)</span>
              </label>
            )}
            <label className="flex items-center gap-2 text-xs text-[#d4c0c6] cursor-pointer">
              <input
                type="checkbox"
                checked={includeHistory}
                onChange={(e) => setIncludeHistory(e.target.checked)}
                className="accent-red-600"
              />
              <span>Incluir histórico de leitura</span>
            </label>
          </div>

          <button
            type="button"
            disabled={exporting || (backupMode === 'selected' && selectedWorkIds.size === 0)}
            onClick={handleExport}
            className="w-full eb-accent-btn py-2.5 px-4 rounded-xl text-xs font-semibold inline-flex items-center justify-center gap-2 disabled:opacity-45 cursor-pointer"
          >
            {exporting ? <Loader2 className="w-4 h-4 animate-spin" /> : <ArchiveRestore className="w-4 h-4" />}
            <span>{exporting ? 'Gerando pacote ZIP...' : 'Baixar Pacote de Backup (.zip)'}</span>
          </button>
        </section>

        {/* Restore */}
        <section className="eb-surface p-5 space-y-4">
          <h2 className="text-base font-semibold text-white flex items-center gap-2">
            <FileUp className="w-4 h-4 text-red-400" />
            <span>Restaurar Backup Local</span>
          </h2>

          <p className="text-xs text-[#bfa9b0] leading-relaxed">
            Selecione um arquivo <code className="text-red-300">.zip</code> gerado pelo Ebookfy. A integridade
            será verificada antes de aplicar qualquer alteração.
          </p>

          <input
            ref={restoreInputRef}
            type="file"
            accept=".zip"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) handleSelectBackupFile(f);
              e.target.value = '';
            }}
            className="hidden"
          />

          <button
            type="button"
            onClick={() => restoreInputRef.current?.click()}
            className="w-full py-2.5 px-4 rounded-xl border border-red-900/45 bg-white/[0.03] hover:bg-red-950/35 text-xs font-medium text-white cursor-pointer"
          >
            Escolher arquivo de backup (.zip)
          </button>

          {inspected && (
            <div className="eb-surface-subtle p-4 space-y-3">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-white">Resumo do Backup</span>
                {inspected.integrityValid ? (
                  <span className="text-emerald-400 inline-flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" /> Integridade OK
                  </span>
                ) : (
                  <span className="text-amber-300 inline-flex items-center gap-1">
                    <ShieldAlert className="w-3.5 h-3.5" /> Hash divergente
                  </span>
                )}
              </div>

              <div className="text-xs text-[#cbb8be] space-y-1 font-mono-nums">
                <p>Data: {new Date(inspected.manifest.createdAt).toLocaleString('pt-BR')}</p>
                <p>Obras no pacote: {inspected.payload.works.length}</p>
                <p>Registros de progresso: {inspected.payload.progress.length}</p>
                <p>Arquivos binários embutidos: {inspected.fileEntriesCount}</p>
              </div>

              <div className="grid grid-cols-2 gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => setConflictMode('merge')}
                  className={`py-1.5 rounded-lg text-xs border cursor-pointer ${
                    conflictMode === 'merge'
                      ? 'bg-red-800/45 border-red-500 text-white'
                      : 'border-white/10 text-[#bfa9b0]'
                  }`}
                >
                  Mesclar (sem duplicar)
                </button>
                <button
                  type="button"
                  onClick={() => setConflictMode('overwrite')}
                  className={`py-1.5 rounded-lg text-xs border cursor-pointer ${
                    conflictMode === 'overwrite'
                      ? 'bg-red-800/45 border-red-500 text-white'
                      : 'border-white/10 text-[#bfa9b0]'
                  }`}
                >
                  Substituir biblioteca
                </button>
              </div>

              <button
                type="button"
                disabled={restoring}
                onClick={handleConfirmRestore}
                className="w-full eb-accent-btn py-2 rounded-lg text-xs font-semibold cursor-pointer"
              >
                {restoring ? 'Restaurando...' : 'Confirmar Restauração'}
              </button>
            </div>
          )}
        </section>
      </div>
    </div>
  );
};
