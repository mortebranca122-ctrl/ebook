import React from 'react';
import {
  ArrowDown,
  ArrowLeft,
  ArrowUp,
  Bookmark,
  CheckCircle2,
  Heart,
  Play,
  RotateCcw,
} from 'lucide-react';
import type { ReaderMode, ReadingProgress, Work } from '../types/ebookfy';
import { formatBytes, formatRelativeDate } from '../utils/formatters';
import { verifyChapterOrder } from '../utils/naturalSort';

interface WorkDetailViewProps {
  work: Work;
  progress?: ReadingProgress;
  onBack: () => void;
  onOpenReader: (work: Work, chapterIndex?: number) => void;
  onToggleFavorite: (workId: string) => void;
  onResetProgress: (workId: string) => void;
  onUpdateWork: (work: Work) => void;
}

export const WorkDetailView: React.FC<WorkDetailViewProps> = ({
  work,
  progress,
  onBack,
  onOpenReader,
  onToggleFavorite,
  onResetProgress,
  onUpdateWork,
}) => {
  const pct = progress?.percentage ?? 0;
  const completedSet = new Set(progress?.completedChapterIds ?? []);
  const verification = verifyChapterOrder(work.chapters);

  const moveChapter = (idx: number, delta: -1 | 1) => {
    const target = idx + delta;
    if (target < 0 || target >= work.chapters.length) return;
    const copy = [...work.chapters];
    const [moved] = copy.splice(idx, 1);
    copy.splice(target, 0, moved);
    const reindexed = copy.map((c, i) => ({ ...c, orderIndex: i }));
    onUpdateWork({ ...work, chapters: reindexed, updatedAt: Date.now() });
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-3">
        <button
          type="button"
          onClick={onBack}
          className="inline-flex items-center gap-2 px-3 py-2 rounded-lg bg-white/[0.04] border border-white/10 text-xs font-medium text-[#e5d5da] hover:text-white cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Voltar</span>
        </button>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => onToggleFavorite(work.id)}
            className={`px-3.5 py-2 rounded-lg border text-xs font-medium inline-flex items-center gap-1.5 cursor-pointer ${
              work.isFavorite
                ? 'bg-red-900/40 border-red-600/60 text-white'
                : 'bg-white/[0.03] border-white/10 text-[#d4c0c6]'
            }`}
          >
            <Heart className={`w-3.5 h-3.5 ${work.isFavorite ? 'fill-red-500 text-red-500' : ''}`} />
            <span>{work.isFavorite ? 'Favoritado' : 'Favoritar'}</span>
          </button>

          {pct > 0 && (
            <button
              type="button"
              onClick={() => onResetProgress(work.id)}
              className="px-3.5 py-2 rounded-lg border border-white/10 bg-white/[0.03] text-xs font-medium text-[#bfa9b0] hover:text-white inline-flex items-center gap-1.5 cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reiniciar</span>
            </button>
          )}
        </div>
      </div>

      {/* Hero Info Card */}
      <div className="eb-surface p-5 sm:p-6 flex flex-col sm:flex-row gap-6">
        <img
          src={work.coverUrl}
          alt={work.title}
          className="w-36 sm:w-44 aspect-[3/4] rounded-xl object-cover border border-red-900/40 shrink-0 mx-auto sm:mx-0"
        />

        <div className="flex-1 min-w-0 space-y-3">
          <div>
            <p className="text-xs text-red-400 font-medium">
              {work.category} · {work.format.toUpperCase()} · {formatBytes(work.totalSizeBytes)}
            </p>
            <h1 className="text-2xl sm:text-3xl font-display-serif font-semibold text-white mt-1">
              {work.title}
            </h1>
            <p className="text-xs text-[#bfa9b0] mt-1">
              Autor: {work.author} · Última leitura: {formatRelativeDate(work.lastReadAt)}
            </p>
          </div>

          <p className="text-sm text-[#d4c0c6] leading-relaxed">{work.description}</p>

          {/* Progress */}
          <div className="pt-1 space-y-1.5">
            <div className="flex justify-between text-xs text-[#bfa9b0] font-mono-nums">
              <span>Progresso total</span>
              <span>{pct}%</span>
            </div>
            <div className="h-2 rounded-full bg-white/10 overflow-hidden">
              <div
                className="h-full rounded-full bg-gradient-to-r from-red-700 to-rose-500"
                style={{ width: `${Math.max(2, pct)}%` }}
              />
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3 pt-2">
            <button
              type="button"
              onClick={() => onOpenReader(work)}
              className="eb-accent-btn px-6 py-2.5 rounded-xl text-sm font-semibold inline-flex items-center gap-2 cursor-pointer"
            >
              <Play className="w-4 h-4 fill-white" />
              <span>{pct > 0 ? 'Continuar de onde parei' : 'Começar leitura'}</span>
            </button>

            {work.readerMode !== 'book' && work.readerMode !== 'pdf' && (
              <select
                aria-label="Tipo de leitor especializado"
                value={work.readerMode}
                onChange={(e) =>
                  onUpdateWork({ ...work, readerMode: e.target.value as ReaderMode, updatedAt: Date.now() })
                }
                className="bg-[#12080c] border border-red-900/40 text-xs text-[#e5d5da] rounded-xl px-3 py-2.5 cursor-pointer"
              >
                <option value="manga">Leitor de Mangá (Páginas RTL/LTR)</option>
                <option value="manhwa">Leitor de Manhwa / Webtoon (Vertical)</option>
                <option value="hq">Leitor de HQ / Quadrinhos</option>
              </select>
            )}
          </div>
        </div>
      </div>

      {/* Bookmarks */}
      {progress && progress.bookmarks.length > 0 && (
        <section className="eb-surface p-4 space-y-2.5">
          <h2 className="text-sm font-semibold text-white flex items-center gap-2">
            <Bookmark className="w-4 h-4 text-red-400" />
            <span>Marcadores salvos ({progress.bookmarks.length})</span>
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {progress.bookmarks.map((bm) => {
              const chIdx = Math.max(0, work.chapters.findIndex((c) => c.id === bm.chapterId));
              return (
                <button
                  key={bm.id}
                  type="button"
                  onClick={() => onOpenReader(work, chIdx)}
                  className="text-left p-3 rounded-xl bg-white/[0.03] border border-white/10 hover:border-red-700/50 text-xs cursor-pointer"
                >
                  <p className="font-semibold text-white">{bm.chapterTitle}</p>
                  <p className="text-[#9d8189] font-mono-nums mt-0.5">
                    Página {bm.pageIndex + 1} · {bm.note ?? formatRelativeDate(bm.createdAt)}
                  </p>
                </button>
              );
            })}
          </div>
        </section>
      )}

      {/* Chapters List */}
      <section className="eb-surface p-4 sm:p-5 space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div>
            <h2 className="text-base font-semibold text-white font-mono-nums">
              Capítulos ({work.chapters.length})
            </h2>
            <p className="text-xs text-[#bfa9b0]">
              {verification.isSequential
                ? 'Sequência numérica verificada e ordenada automaticamente.'
                : `Ordem natural aplicada · Lacunas detectadas nos números: ${verification.missingChapters.join(', ')}`}
            </p>
          </div>
        </div>

        <div className="divide-y divide-white/[0.06]">
          {work.chapters.map((ch, idx) => {
            const isCurrent = progress?.chapterId === ch.id;
            const isDone = completedSet.has(ch.id);
            return (
              <div
                key={ch.id}
                className={`py-2.5 px-2 flex items-center justify-between gap-3 rounded-lg transition-colors ${
                  isCurrent ? 'bg-red-950/35' : 'hover:bg-white/[0.02]'
                }`}
              >
                <button
                  type="button"
                  onClick={() => onOpenReader(work, idx)}
                  className="flex-1 min-w-0 text-left flex items-center gap-3 cursor-pointer"
                >
                  <span className="w-7 text-xs font-mono-nums text-[#9d8189]">{idx + 1}.</span>
                  <div className="min-w-0">
                    <p className="text-sm font-medium text-white truncate">{ch.title}</p>
                    <p className="text-[11px] text-[#9d8189] font-mono-nums">
                      {ch.pages.length > 0 ? `${ch.pages.length} página(s)` : 'Texto / Documento'} ·{' '}
                      {formatBytes(ch.totalSize)}
                    </p>
                  </div>
                </button>

                <div className="flex items-center gap-1.5 shrink-0">
                  {isDone && <CheckCircle2 className="w-4 h-4 text-emerald-400" aria-label="Concluído" />}
                  {work.chapters.length > 1 && (
                    <>
                      <button
                        type="button"
                        disabled={idx === 0}
                        onClick={() => moveChapter(idx, -1)}
                        aria-label={`Mover ${ch.title} para cima`}
                        className="p-1.5 rounded border border-white/10 text-[#bfa9b0] hover:text-white disabled:opacity-30 cursor-pointer"
                      >
                        <ArrowUp className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        disabled={idx === work.chapters.length - 1}
                        onClick={() => moveChapter(idx, 1)}
                        aria-label={`Mover ${ch.title} para baixo`}
                        className="p-1.5 rounded border border-white/10 text-[#bfa9b0] hover:text-white disabled:opacity-30 cursor-pointer"
                      >
                        <ArrowDown className="w-3.5 h-3.5" />
                      </button>
                    </>
                  )}
                  <button
                    type="button"
                    onClick={() => onOpenReader(work, idx)}
                    className="px-3 py-1.5 rounded-lg bg-red-950/60 hover:bg-red-800/70 border border-red-800/40 text-xs font-medium text-white cursor-pointer"
                  >
                    Ler
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </section>
    </div>
  );
};
