# Ebookfy — Biblioteca Digital e Leitor Universal Offline

Aplicação web e PWA responsiva para **Desktop (Windows/Mac/Linux)** e **Mobile (Android/iOS)** com identidade visual **Dark Romance** e armazenamento 100% local no dispositivo (IndexedDB + OPFS), sem dependência de servidores ou nuvem.

## Recursos incluídos

- **Importação universal sem limite de tamanho para `.zip` / `.cbz`** via leitura em fluxo (`@zip.js/zip.js`).
- **Suporte a múltiplos formatos**: ZIP, CBZ, EPUB, PDF (`pdfjs-dist`), DOCX, TXT, RTF, HTML e pastas com imagens (PNG, JPG, WEBP, GIF, BMP, TIFF, AVIF).
- **Verificação e ordenação natural automática**: detecta capítulos (`Capítulo 1, 2, 3, 4, 5...`) e ordena páginas numericamente (`1, 2, 10`), com revisão e reordenação manual antes de salvar.
- **Leitores especializados**:
  - **Livros (EPUB, TXT, DOCX, RTF)**: modo **Escuro (fundo preto com letras brancas)**, **Claro** e **Sépia**, ajustes de tipografia, sumário, busca textual e marcadores.
  - **Manhwa / Webtoon**: rolagem vertical contínua, seletor de capítulos e restauração exata da posição.
  - **Mangá / HQ**: leitura direita-para-esquerda ou esquerda-para-direita, página única ou dupla, zoom e atalhos de teclado.
  - **PDF**: renderização local com modo Claro/Escuro, zoom, rotação, busca textual e marcadores.
- **Personalização, Armazenamento, Backup `.zip` e Segurança**: 6 temas (incluindo Dark Romance e Personalizado), papel de parede local, análise de espaço, exportação/restauração em `.zip` e bloqueio opcional por senha (`PBKDF2-SHA256`).

## Como executar localmente

```bash
npm install
npm run dev
```

Acesse `http://localhost:3000`.

## Verificação e build

```bash
npm run lint
npm run build
npx tsx --test src/utils/naturalSort.test.ts src/utils/crypto.test.ts
```
