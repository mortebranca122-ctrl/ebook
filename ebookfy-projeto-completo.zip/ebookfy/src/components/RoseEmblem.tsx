import React from 'react';

interface RoseEmblemProps {
  className?: string;
}

export const RoseEmblem: React.FC<RoseEmblemProps> = ({ className = 'w-7 h-7' }) => {
  return (
    <svg
      viewBox="0 0 64 64"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      aria-hidden="true"
    >
      <path
        d="M32 8C38.5 8 43.5 13 43.5 19.2C49.4 20.4 52.5 26 50 32C52.5 38.2 48.2 44.4 41.6 45.4C38.8 50 32 52 32 52C32 52 25.2 50 22.4 45.4C15.8 44.4 11.5 38.2 14 32C11.5 26 14.6 20.4 20.5 19.2C20.5 13 25.5 8 32 8Z"
        fill="url(#roseGrad)"
      />
      <path
        d="M32 15C36.5 15 39.6 18.5 39.2 22.8C43.2 24.4 44.8 28.8 42.6 32.8C43.6 37.5 40.1 41.2 35.4 41.6C32 44.4 28.6 41.6 28.6 41.6C23.9 41.2 20.4 37.5 21.4 32.8C19.2 28.8 20.8 24.4 24.8 22.8C24.4 18.5 27.5 15 32 15Z"
        fill="#881337"
        stroke="#fda4af"
        strokeOpacity="0.35"
        strokeWidth="1.2"
      />
      <circle cx="32" cy="29" r="4.5" fill="#e11d48" />
      <defs>
        <linearGradient id="roseGrad" x1="14" y1="8" x2="50" y2="52" gradientUnits="userSpaceOnUse">
          <stop stopColor="#f43f5e" />
          <stop offset="0.5" stopColor="#be123c" />
          <stop offset="1" stopColor="#7f1d1d" />
        </linearGradient>
      </defs>
    </svg>
  );
};
