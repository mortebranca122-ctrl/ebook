import React, { useMemo, useState } from 'react';
import { AlertTriangle, Eraser, HardDrive, RefreshCw, Trash2 } from 'lucide-react';
import type { Work } from '../types/ebookfy';
import { formatBytes } from '../utils/formatters';
import { clearPageUrlCache } from '../services/pageLoader';

interface StorageViewProps {
  works: Work[];
  storageUsedBytes: number;
  storageQuotaBytes: number;
  onDeleteWorks: (workIds: string[], deleteBlobs: boolean) => void;
  onRefreshEstimate: () => void;
}

export const StorageView: React.FC<StorageViewProps> = ({
  works,
  storageUsedBytes,
  storageQuotaBytes,
  onDeleteWorks,
  onRefreshEstimate,
}) => {
  const [cacheMessage, setCacheMessage] = useState<string | null>(null);
  const [confirmTarget, setConfirmTarget] = useState<Work | null>(null);
  const [deleteFilesToo, setDeleteFilesToo] = useState(true);

  const breakdown = useMemo(() => {
    let docsBytes = 0;
    let comicsBytes = 0;
    let coversBytes = 0;

    for (const w of works) {
      coversBytes += w.coverUrl.length;
      if (w.readerMode === 'book' || w.readerMode === 'pdf') {
        docsBytes += w.totalSizeBytes;
      } else {
        comicsBytes += w.totalSizeBytes;
      }
    }
    return { docsBytes, comicsBytes, coversBytes };
  }, [works]);

  const duplicates = useMemo(() => {
    const byKey = new Map<string, Work[]>();
    for (const w of works) {
      const key = w.sourceHash || w.title.trim().toLowerCase();
      const arr = byKey.get(key) ?? [];
      arr.push(w);
      byKey.set(key, arr);
    }
    return Array.from(byKey.values()).filter((group) => group.length > 1);
  }, [works]);

  const freeBytes = Math.max(0, storageQuotaBytes - storageUsedBytes);
  const sortedWorks = useMemo(
    () => [...works].sort((a, b) => b.totalSizeBytes - a.totalSizeBytes),
    [works]
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-xl sm:text-2xl font-semibold text-white">Armazenamento Local</h1>
          <p className="text-xs text-[#bfa9b0] mt-0.5">
            Todos os arquivos ficam exclusivamente neste dispositivo (OPFS & IndexedDB).
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => {
              clearPageUrlCache();
              onRefreshEstimate();
              setCacheMessage('Cache de decodificação de páginas limpo com sucesso.');
              setTimeout(() => setCacheMessage(null), 2600);
            }}
            className="px-3.5 py-2 rounded-lg bg-white/[0.04] border border-red-900/40 text-xs font-medium text-white inline-flex items-center gap-1.5 cursor-pointer"
          >
            <Eraser className="w-3.5 h-3.5 text-red-400" />
            <span>Limpar cache</span>
          </button>
          <button
            type="button"
            onClick={onRefreshEstimate}
            aria-label="Recalcular espaço"
            className="p-2 rounded-lg bg-white/[0.04] border border-white/10 text-[#d4c0c6] hover:text-white cursor-pointer"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {cacheMessage && (
        <div className="eb-surface p-3 text-xs text-emerald-300 border-emerald-700/50">{cacheMessage}</div>
      )}

      {/* Summary Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="eb-surface p-4">
          <p className="text-xs text-[#9d8189]">Espaço usado (Ebookfy)</p>
          <p className="text-lg font-semibold font-mono-nums text-white mt-1">
            {formatBytes(storageUsedBytes)}
          </p>
        </div>
        <div className="eb-surface p-4">
          <p className="text-xs text-[#9d8189]">Mangás, Webtoons & HQs</p>
          <p className="text-lg font-semibold font-mono-nums text-white mt-1">
            {formatBytes(breakdown.comicsBytes)}
          </p>
        </div>
        <div className="eb-surface p-4">
          <p className="text-xs text-[#9d8189]">Livros & PDFs</p>
          <p className="text-lg font-semibold font-mono-nums text-white mt-1">
            {formatBytes(breakdown.docsBytes)}
          </p>
        </div>
        <div className="eb-surface p-4">
          <p className="text-xs text-[#9d8189]">Disponível no navegador</p>
          <p className="text-lg font-semibold font-mono-nums text-white mt-1">
            {formatBytes(freeBytes)}
          </p>
        </div>
      </div>

      {/* Duplicate Detection */}
      {duplicates.length > 0 && (
        <section className="eb-surface p-4 border-amber-700/50 space-y-2">
          <h2 className="text-sm font-semibold text-amber-300 flex items-center gap-2">
            <AlertTriangle className="w-4 h-4" />
            <span>Possíveis duplicatas detectadas ({duplicates.length})</span>
          </h2>
          {duplicates.map((group, idx) => (
            <div key={idx} className="text-xs text-[#d4c0c6] flex flex-wrap items-center justify-between gap-2 py-1">
              <span>
                {group.map((g) => g.title).join(' / ')} ({group.length} cópias)
              </span>
              <button
                type="button"
                onClick={() => setConfirmTarget(group[group.length - 1])}
                className="text-red-400 hover:underline cursor-pointer"
              >
                Remover cópia extra
              </button>
            </div>
          ))}
        </section>
      )}

      {/* Per-Work Size Table */}
      <section className="eb-surface p-4 sm:p-5 space-y-3">
        <h2 className="text-base font-semibold text-white flex items-center gap-2">
          <HardDrive className="w-4 h-4 text-red-400" />
          <span>Uso por obra ({sortedWorks.length})</span>
        </h2>

        <div className="divide-y divide-white/[0.06]">
          {sortedWorks.map((work) => (
            <div key={work.id} className="py-3 flex items-center justify-between gap-3">
              <div className="flex items-center gap-3 min-w-0">
                <img
                  src={work.coverUrl}
                  alt={work.title}
                  className="w-10 h-14 rounded object-cover border border-red-900/30 shrink-0"
                />
                <div className="min-w-0">
                  <p className="text-sm font-medium text-white truncate">{work.title}</p>
                  <p className="text-xs text-[#9d8189] font-mono-nums">
                    {work.category} · {work.chapters.length} cap. · {formatBytes(work.totalSizeBytes)}
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setConfirmTarget(work)}
                aria-label={`Remover ${work.title}`}
                className="px-3 py-1.5 rounded-lg border border-red-900/40 text-xs text-red-300 hover:bg-red-950/50 inline-flex items-center gap-1.5 cursor-pointer shrink-0"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Remover</span>
              </button>
            </div>
          ))}
        </div>
      </section>

      {confirmTarget && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="eb-surface w-full max-w-md p-5 space-y-4 border-red-700/60">
            <h2 className="text-base font-semibold text-white">Remover &quot;{confirmTarget.title}&quot;?</h2>
            <label className="flex items-start gap-2 text-xs text-[#d4c0c6] cursor-pointer">
              <input
                type="checkbox"
                checked={deleteFilesToo}
                onChange={(e) => setDeleteFilesToo(e.target.checked)}
                className="mt-0.5 accent-red-600"
              />
              <span>
                Excluir também os arquivos internos armazenados no Ebookfy (
                {formatBytes(confirmTarget.totalSizeBytes)}). Se desmarcar, remove apenas o registro da biblioteca.
              </span>
            </label>
            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setConfirmTarget(null)}
                className="px-4 py-2 rounded-lg border border-white/15 text-xs text-[#d4c0c6] cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={() => {
                  onDeleteWorks([confirmTarget.id], deleteFilesToo);
                  setConfirmTarget(null);
                }}
                className="px-4 py-2 rounded-lg bg-red-700 hover:bg-red-600 text-xs font-semibold text-white cursor-pointer"
              >
                Confirmar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
