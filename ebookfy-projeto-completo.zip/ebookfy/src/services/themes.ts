import type { ThemePresetId, ThemeSettings } from '../types/ebookfy';

export interface ThemePresetDefinition {
  id: ThemePresetId;
  name: string;
  description: string;
  primaryColor: string;
  secondaryColor: string;
  canvasBg: string;
  surfaceBg: string;
  surfaceElevated: string;
  surfaceAlpha: number;
  blurIntensity: number;
}

export const THEME_PRESETS: ThemePresetDefinition[] = [
  {
    id: 'dark-romance',
    name: 'Dark Romance',
    description: 'Preto profundo, vermelho sangue e contrastes elegantes.',
    primaryColor: '#c81e2b',
    secondaryColor: '#881322',
    canvasBg: '#070406',
    surfaceBg: '#12080c',
    surfaceElevated: '#1a0b11',
    surfaceAlpha: 0.9,
    blurIntensity: 14,
  },
  {
    id: 'blood-red',
    name: 'Blood Red',
    description: 'Carmesim intenso sobre veludo noturno.',
    primaryColor: '#dc2626',
    secondaryColor: '#7f1d1d',
    canvasBg: '#090304',
    surfaceBg: '#170709',
    surfaceElevated: '#230a0e',
    surfaceAlpha: 0.92,
    blurIntensity: 12,
  },
  {
    id: 'pure-black',
    name: 'Pure Black',
    description: 'Preto absoluto OLED com acentos em rubi.',
    primaryColor: '#be123c',
    secondaryColor: '#6b0f26',
    canvasBg: '#000000',
    surfaceBg: '#09090b',
    surfaceElevated: '#121014',
    surfaceAlpha: 0.96,
    blurIntensity: 8,
  },
  {
    id: 'crimson-glass',
    name: 'Crimson Glass',
    description: 'Camadas translúcidas com desfoque intenso.',
    primaryColor: '#e11d48',
    secondaryColor: '#9f1239',
    canvasBg: '#080407',
    surfaceBg: '#170910',
    surfaceElevated: '#220e17',
    surfaceAlpha: 0.68,
    blurIntensity: 22,
  },
  {
    id: 'minimal-dark',
    name: 'Minimal Dark',
    description: 'Contraste sóbrio com detalhes sutis em vinho.',
    primaryColor: '#9f1239',
    secondaryColor: '#500724',
    canvasBg: '#0a0a0c',
    surfaceBg: '#131215',
    surfaceElevated: '#1c191e',
    surfaceAlpha: 0.95,
    blurIntensity: 10,
  },
];

export function applyThemeToDocument(theme: ThemeSettings): void {
  const root = document.documentElement;
  const preset = THEME_PRESETS.find((p) => p.id === theme.preset);
  const surfaceBg = preset ? preset.surfaceBg : '#12080c';
  const surfaceElevated = preset ? preset.surfaceElevated : '#1a0b11';

  root.style.setProperty('--eb-bg-canvas', theme.canvasBg);
  root.style.setProperty('--eb-bg-surface', surfaceBg);
  root.style.setProperty('--eb-bg-surface-elevated', surfaceElevated);
  root.style.setProperty('--eb-accent', theme.primaryColor);
  root.style.setProperty('--eb-accent-hover', theme.primaryColor);
  root.style.setProperty('--eb-surface-alpha', String(theme.surfaceAlpha));
  root.style.setProperty('--eb-blur', `${theme.blurIntensity}px`);
  root.style.setProperty('--eb-radius', `${theme.borderRadius}px`);
}
