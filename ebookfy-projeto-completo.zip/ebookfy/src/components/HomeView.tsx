import React, { useMemo, useState } from 'react';
import {
  BookOpen,
  Bookmark,
  ChevronRight,
  FileText,
  FolderOpen,
  LayoutGrid,
  Play,
  Sparkles,
} from 'lucide-react';
import type {
  CategoryType,
  NavSection,
  ReadingProgress,
  ThemeSettings,
  Work,
} from '../types/ebookfy';
import { formatBytes } from '../utils/formatters';
import { THEME_PRESETS } from '../services/themes';

interface HomeViewProps {
  works: Work[];
  progressMap: Map<string, ReadingProgress>;
  theme: ThemeSettings;
  storageUsedBytes: number;
  storageQuotaBytes: number;
  onContinueWork: (work: Work) => void;
  onOpenWorkDetails: (work: Work) => void;
  onNavigate: (section: NavSection, categoryFilter?: CategoryType) => void;
}

const DESKTOP_CATEGORIES: Array<{ label: CategoryType; image: string; pos?: string }> = [
  { label: 'Mangás', image: '/src/assets/images/cover_crimson_vow_1794861268635.jpg', pos: 'object-top' },
  { label: 'Manhwas', image: '/src/assets/images/cover_shadow_monarch_1794861269069.jpg', pos: 'object-top' },
  { label: 'Manhuas', image: '/src/assets/images/hero_dark_romance_1794861267461.jpg', pos: 'object-right' },
  { label: 'Webtoons', image: '/src/assets/images/cover_blood_rose_1794861269769.jpg', pos: 'object-center' },
  { label: 'HQs', image: '/src/assets/images/cover_midnight_tome_1794861270860.jpg', pos: 'object-center' },
];

const MOBILE_CATEGORIES: Array<{
  label: CategoryType;
  image?: string;
  pos?: string;
  icon?: React.ComponentType<{ className?: string }>;
}> = [
  { label: 'Mangás', image: '/src/assets/images/cover_crimson_vow_1794861268635.jpg', pos: 'object-top' },
  { label: 'Manhwas', image: '/src/assets/images/cover_shadow_monarch_1794861269069.jpg', pos: 'object-top' },
  { label: 'Manhuas', image: '/src/assets/images/hero_dark_romance_1794861267461.jpg', pos: 'object-right' },
  { label: 'Webtoons', image: '/src/assets/images/cover_blood_rose_1794861269769.jpg', pos: 'object-top' },
  { label: 'HQs', image: '/src/assets/images/cover_midnight_tome_1794861270860.jpg', pos: 'object-center' },
  { label: 'Livros', icon: BookOpen },
  { label: 'PDFs', icon: FileText },
  { label: 'Outros', icon: LayoutGrid },
];

export const HomeView: React.FC<HomeViewProps> = ({
  works,
  progressMap,
  theme,
  storageUsedBytes,
  storageQuotaBytes,
  onContinueWork,
  onOpenWorkDetails,
  onNavigate,
}) => {
  const featuredWork = useMemo(() => {
    const inProgress = works.find((w) => {
      const p = progressMap.get(w.id);
      return p && p.percentage > 0 && p.percentage < 100;
    });
    return inProgress ?? works[0] ?? null;
  }, [works, progressMap]);

  const [inspectedId, setInspectedId] = useState<string | null>(null);
  const inspectedWork = useMemo(
    () => works.find((w) => w.id === inspectedId) ?? featuredWork,
    [works, inspectedId, featuredWork]
  );

  const featuredProgress = featuredWork ? progressMap.get(featuredWork.id) : undefined;
  const inspectedProgress = inspectedWork ? progressMap.get(inspectedWork.id) : undefined;
  const featuredChapterTitle = featuredWork
    ? featuredWork.chapters[featuredProgress?.chapterIndex ?? 0]?.title ?? 'Capítulo 1'
    : '';
  const featuredPct = featuredProgress?.percentage ?? 0;

  const recentWorks = useMemo(() => works.slice(0, 5), [works]);

  const activePresetName =
    THEME_PRESETS.find((p) => p.id === theme.preset)?.name ?? 'Personalizado';

  const usedPct = useMemo(() => {
    if (storageQuotaBytes <= 0) return 0;
    return Math.min(100, Math.max(1, Math.round((storageUsedBytes / storageQuotaBytes) * 100)));
  }, [storageUsedBytes, storageQuotaBytes]);

  const ringRadius = 32;
  const ringCircumference = 2 * Math.PI * ringRadius;
  const ringDashOffset = ringCircumference - (usedPct / 100) * ringCircumference;

  return (
    <div className="flex flex-col lg:flex-row gap-5 items-start">
      {/* Main Feed Column */}
      <div className="flex-1 min-w-0 w-full space-y-4 sm:space-y-5">
        {/* Desktop Hero Banner */}
        <section
          aria-label="Apresentação Ebookfy"
          className="hidden lg:block relative rounded-2xl overflow-hidden border border-red-900/35 bg-[#0a0406] min-h-[178px]"
        >
          <img
            src="/src/assets/images/hero_dark_romance_1794861267461.jpg"
            alt="Ilustração Dark Romance Ebookfy"
            className="absolute inset-0 w-full h-full object-cover object-right"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-[#070406] via-[#070406]/85 to-transparent" />
          <div className="relative z-10 px-8 py-8 max-w-xl">
            <h1 className="font-display-serif italic text-5xl xl:text-6xl font-semibold tracking-tight text-[#f6e8ec] drop-shadow-[0_2px_18px_rgba(185,28,28,0.35)]">
              Ebookfy
            </h1>
            <p className="mt-1.5 text-sm text-[#d4c0c6] tracking-wide">
              Sua biblioteca. Seus arquivos. Seu dispositivo.
            </p>
          </div>
        </section>

        {/* Continuar Lendo */}
        <section aria-labelledby="heading-continuar">
          <div className="flex items-center justify-between mb-3">
            <h2 id="heading-continuar" className="text-lg font-semibold text-[#f6eff1]">
              Continuar lendo
            </h2>
            <button
              type="button"
              onClick={() => onNavigate('biblioteca')}
              className="inline-flex items-center gap-1 text-xs font-medium text-[#bfa9b0] hover:text-red-400 transition-colors cursor-pointer"
            >
              <span>Ver tudo</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {featuredWork ? (
            <div className="eb-surface p-3.5 sm:p-4 relative overflow-hidden">
              <div className="flex items-center gap-4">
                <button
                  type="button"
                  onClick={() => onContinueWork(featuredWork)}
                  className="w-24 h-28 sm:w-44 sm:h-28 shrink-0 rounded-xl overflow-hidden border border-red-900/30 cursor-pointer group"
                >
                  <img
                    src={featuredWork.coverUrl}
                    alt={featuredWork.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                </button>

                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <h3 className="text-base sm:text-lg font-semibold text-white truncate">
                        {featuredWork.title}
                      </h3>
                      <p className="text-xs sm:text-sm text-[#bfa9b0] mt-0.5 truncate">
                        <span className="sm:hidden">
                          {featuredChapterTitle} · <span className="font-mono-nums">{featuredPct}%</span>
                        </span>
                        <span className="hidden sm:inline">{featuredChapterTitle}</span>
                      </p>
                    </div>

                    {/* Mobile circular play button */}
                    <button
                      type="button"
                      onClick={() => onContinueWork(featuredWork)}
                      aria-label={`Continuar ${featuredWork.title}`}
                      className="sm:hidden min-w-[44px] min-h-[44px] rounded-full eb-accent-btn flex items-center justify-center shrink-0 shadow-[0_0_16px_rgba(200,30,43,0.45)]"
                    >
                      <Play className="w-4 h-4 fill-white ml-0.5" />
                    </button>
                  </div>

                  {/* Progress bar */}
                  <div className="hidden sm:flex items-center gap-3 mt-3">
                    <div className="flex-1 h-1.5 rounded-full bg-white/10 overflow-hidden">
                      <div
                        className="h-full rounded-full bg-gradient-to-r from-red-700 to-rose-500 transition-all"
                        style={{ width: `${Math.max(4, featuredPct)}%` }}
                      />
                    </div>
                    <span className="text-xs font-mono-nums text-[#d8c4ca]">{featuredPct}%</span>
                  </div>

                  {/* Desktop actions */}
                  <div className="hidden sm:flex items-center gap-2.5 mt-3.5">
                    <button
                      type="button"
                      onClick={() => onContinueWork(featuredWork)}
                      className="eb-accent-btn px-5 py-2 rounded-lg text-xs font-semibold inline-flex items-center gap-2 cursor-pointer"
                    >
                      <Play className="w-3.5 h-3.5 fill-white" />
                      <span>Continuar</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => onOpenWorkDetails(featuredWork)}
                      aria-label={`Detalhes e marcadores de ${featuredWork.title}`}
                      className="p-2 rounded-lg border border-red-900/35 bg-white/[0.03] text-[#d4c0c6] hover:text-white hover:border-red-700/60 transition-colors cursor-pointer"
                    >
                      <Bookmark className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="eb-surface p-6 text-center">
              <p className="text-sm text-[#bfa9b0]">Sua biblioteca ainda está vazia.</p>
              <button
                type="button"
                onClick={() => onNavigate('importar')}
                className="mt-3 eb-accent-btn px-4 py-2 rounded-lg text-xs font-semibold cursor-pointer"
              >
                Importar primeira obra
              </button>
            </div>
          )}
        </section>

        {/* Categorias */}
        <section aria-labelledby="heading-categorias">
          <div className="flex items-center justify-between mb-3">
            <h2 id="heading-categorias" className="text-lg font-semibold text-[#f6eff1]">
              Categorias
            </h2>
            <button
              type="button"
              onClick={() => onNavigate('biblioteca')}
              className="inline-flex items-center gap-1 text-xs font-medium text-[#bfa9b0] hover:text-red-400 transition-colors cursor-pointer"
            >
              <span>Ver tudo</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Desktop 5-card illustrated grid */}
          <div className="hidden sm:grid grid-cols-5 gap-3">
            {DESKTOP_CATEGORIES.map((cat) => (
              <button
                key={cat.label}
                type="button"
                onClick={() => onNavigate('biblioteca', cat.label)}
                className="group relative aspect-[4/3.8] rounded-xl overflow-hidden border border-red-900/30 bg-[#12080c] text-left cursor-pointer"
              >
                <img
                  src={cat.image}
                  alt={cat.label}
                  className={`w-full h-full object-cover ${cat.pos ?? 'object-center'} group-hover:scale-105 transition-transform duration-300`}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/25 to-transparent" />
                <span className="absolute bottom-2 inset-x-2 text-center text-xs font-semibold text-white">
                  {cat.label}
                </span>
              </button>
            ))}
          </div>

          {/* Mobile 4x2 category icon grid */}
          <div className="grid grid-cols-4 gap-2 sm:hidden">
            {MOBILE_CATEGORIES.map((cat) => {
              const Icon = cat.icon;
              return (
                <button
                  key={cat.label}
                  type="button"
                  onClick={() => onNavigate('biblioteca', cat.label)}
                  className="eb-surface-subtle p-1.5 flex flex-col items-center justify-center gap-1 min-h-[74px] active:scale-95 transition-transform"
                >
                  {cat.image ? (
                    <img
                      src={cat.image}
                      alt={cat.label}
                      className={`w-10 h-10 rounded-lg object-cover ${cat.pos ?? 'object-center'} border border-red-900/35`}
                    />
                  ) : (
                    <div className="w-10 h-10 rounded-lg bg-red-950/50 border border-red-800/35 flex items-center justify-center text-red-400">
                      {Icon && <Icon className="w-5 h-5" />}
                    </div>
                  )}
                  <span className="text-[11px] font-medium text-[#e5d5da] truncate max-w-full">
                    {cat.label}
                  </span>
                </button>
              );
            })}
          </div>
        </section>

        {/* Mais lidas / Recentes */}
        <section aria-labelledby="heading-recentes">
          <div className="flex items-center justify-between mb-3">
            <h2 id="heading-recentes" className="text-lg font-semibold text-[#f6eff1]">
              <span className="lg:hidden">Recentes</span>
              <span className="hidden lg:inline">Mais lidas</span>
            </h2>
            <button
              type="button"
              onClick={() => onNavigate('biblioteca')}
              className="inline-flex items-center gap-1 text-xs font-medium text-[#bfa9b0] hover:text-red-400 transition-colors cursor-pointer"
            >
              <span>Ver tudo</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="grid grid-cols-4 sm:grid-cols-5 gap-2.5 sm:gap-3">
            {recentWorks.map((work) => (
              <button
                key={work.id}
                type="button"
                onClick={() => {
                  setInspectedId(work.id);
                  onOpenWorkDetails(work);
                }}
                onMouseEnter={() => setInspectedId(work.id)}
                className="group relative aspect-[3/4] rounded-xl overflow-hidden border border-red-900/30 bg-[#12080c] text-left cursor-pointer"
              >
                <img
                  src={work.coverUrl}
                  alt={work.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent" />
                <div className="absolute bottom-2 inset-x-2">
                  <p className="text-[11px] sm:text-xs font-semibold text-white line-clamp-2 leading-tight">
                    {work.title}
                  </p>
                </div>
              </button>
            ))}
          </div>
        </section>
      </div>

      {/* Desktop Right Inspector Column */}
      <aside className="hidden lg:flex flex-col gap-4 w-[290px] xl:w-[310px] shrink-0">
        {/* Detalhes da obra */}
        <div className="eb-surface p-4">
          <h2 className="text-sm font-semibold text-white mb-3">Detalhes da obra</h2>
          {inspectedWork ? (
            <>
              <div className="flex gap-3">
                <img
                  src={inspectedWork.coverUrl}
                  alt={inspectedWork.title}
                  className="w-20 h-28 rounded-lg object-cover border border-red-900/30 shrink-0"
                />
                <div className="min-w-0 text-xs space-y-1">
                  <h3 className="text-sm font-semibold text-white truncate">{inspectedWork.title}</h3>
                  <p className="text-[#bfa9b0] truncate">Autor: {inspectedWork.author}</p>
                  <p className="text-[#bfa9b0] truncate">Categoria: {inspectedWork.category}</p>
                  <p className="text-[#bfa9b0] font-mono-nums">
                    Capítulos: {inspectedWork.chapters.length}
                  </p>
                  <p className="text-[#bfa9b0] font-mono-nums">
                    Progresso: {inspectedProgress?.percentage ?? 0}%
                  </p>
                </div>
              </div>
              <p className="mt-3 text-xs text-[#bfa9b0] leading-relaxed line-clamp-3">
                {inspectedWork.description}
              </p>
              <button
                type="button"
                onClick={() => onOpenWorkDetails(inspectedWork)}
                className="mt-3.5 w-full py-2 px-4 rounded-lg border border-red-900/45 bg-red-950/25 hover:bg-red-900/35 text-xs font-medium text-white transition-colors cursor-pointer"
              >
                Ver detalhes
              </button>
            </>
          ) : (
            <div className="py-4 text-xs text-[#9d8189] flex items-center gap-2">
              <FolderOpen className="w-4 h-4" />
              <span>Selecione ou importe uma obra.</span>
            </div>
          )}
        </div>

        {/* Personalização */}
        <div className="eb-surface p-4">
          <h2 className="text-sm font-semibold text-white mb-3">Personalização</h2>
          <div className="flex items-center gap-3">
            <img
              src="/src/assets/images/cover_crimson_vow_1794861268635.jpg"
              alt="Prévia do tema"
              className="w-16 h-16 rounded-lg object-cover border border-red-900/35 shrink-0"
            />
            <div className="min-w-0 flex-1">
              <p className="text-[11px] text-[#9d8189]">Tema atual</p>
              <p className="text-sm font-semibold text-white truncate">{activePresetName}</p>
              <button
                type="button"
                onClick={() => onNavigate('personalizacao')}
                className="mt-2 w-full py-1.5 px-3 rounded-lg border border-red-900/40 bg-white/[0.03] hover:bg-red-950/35 text-xs font-medium text-[#f5ebee] transition-colors inline-flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Sparkles className="w-3 h-3 text-red-400" />
                <span>Alterar tema</span>
              </button>
            </div>
          </div>
        </div>

        {/* Armazenamento */}
        <div className="eb-surface p-4">
          <h2 className="text-sm font-semibold text-white mb-3">Armazenamento</h2>
          <div className="flex items-center gap-4">
            <div className="relative w-20 h-20 shrink-0 flex items-center justify-center">
              <svg className="w-20 h-20 -rotate-90" viewBox="0 0 80 80">
                <circle
                  cx="40"
                  cy="40"
                  r={ringRadius}
                  fill="none"
                  stroke="rgba(255,255,255,0.08)"
                  strokeWidth="7"
                />
                <circle
                  cx="40"
                  cy="40"
                  r={ringRadius}
                  fill="none"
                  stroke="#c81e2b"
                  strokeWidth="7"
                  strokeLinecap="round"
                  strokeDasharray={ringCircumference}
                  strokeDashoffset={ringDashOffset}
                />
              </svg>
              <span className="absolute text-sm font-semibold font-mono-nums text-white">
                {usedPct}%
              </span>
            </div>

            <div className="min-w-0 flex-1">
              <p className="text-[11px] text-[#9d8189]">Usado localmente</p>
              <p className="text-xs font-semibold font-mono-nums text-white truncate mt-0.5">
                {formatBytes(storageUsedBytes)} / {formatBytes(storageQuotaBytes)}
              </p>
              <button
                type="button"
                onClick={() => onNavigate('armazenamento')}
                className="mt-2.5 w-full py-1.5 px-3 rounded-lg border border-red-900/40 bg-white/[0.03] hover:bg-red-950/35 text-xs font-medium text-[#f5ebee] transition-colors cursor-pointer"
              >
                Gerenciar
              </button>
            </div>
          </div>
        </div>
      </aside>
    </div>
  );
};
