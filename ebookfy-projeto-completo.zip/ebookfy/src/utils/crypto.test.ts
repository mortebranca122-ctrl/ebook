import test from 'node:test';
import assert from 'node:assert/strict';
import {
  generateSaltHex,
  generateRecoveryCode,
  hashPassword,
  verifyPassword,
} from './crypto';

test('PBKDF2 password hashing verifies matching password and rejects wrong password', async () => {
  const salt = generateSaltHex();
  const hash = await hashPassword('DarkRomance#2026', salt);

  assert.equal(hash.length, 64);
  assert.equal(await verifyPassword('DarkRomance#2026', salt, hash), true);
  assert.equal(await verifyPassword('wrong-pass', salt, hash), false);
});

test('generateRecoveryCode creates formatted 12-char code', () => {
  const code = generateRecoveryCode();
  assert.match(code, /^[A-Z2-9]{4}-[A-Z2-9]{4}-[A-Z2-9]{4}$/);
});
