import * as zip from '@zip.js/zip.js';
import type {
  Collection,
  HistoryEntry,
  ReaderSettings,
  ReadingProgress,
  ThemeSettings,
  Work,
} from '../types/ebookfy';
import { sha256Text } from '../utils/crypto';
import { getBinaryBlob, storeBinaryBlob } from './db';

export interface BackupManifest {
  app: 'Ebookfy';
  version: number;
  createdAt: number;
  mode: 'full' | 'metadata' | 'selected';
  workCount: number;
  includeFiles: boolean;
  integrityHash: string;
}

export interface BackupPayload {
  manifest: BackupManifest;
  works: Work[];
  progress: ReadingProgress[];
  collections: Collection[];
  history: HistoryEntry[];
  themeSettings?: ThemeSettings;
  readerSettings?: ReaderSettings;
}

export async function createBackupZip(params: {
  works: Work[];
  progress: ReadingProgress[];
  collections: Collection[];
  history: HistoryEntry[];
  themeSettings: ThemeSettings;
  readerSettings: ReaderSettings;
  mode: 'full' | 'metadata' | 'selected';
  includeFiles: boolean;
  includeHistory: boolean;
}): Promise<Blob> {
  const writer = new zip.ZipWriter(new zip.BlobWriter('application/zip'));

  const coreData = {
    works: params.works,
    progress: params.progress,
    collections: params.collections,
    history: params.includeHistory ? params.history : [],
    themeSettings: params.themeSettings,
    readerSettings: params.readerSettings,
  };

  const dataJson = JSON.stringify(coreData, null, 2);
  const integrityHash = await sha256Text(dataJson);

  const manifest: BackupManifest = {
    app: 'Ebookfy',
    version: 1,
    createdAt: Date.now(),
    mode: params.mode,
    workCount: params.works.length,
    includeFiles: params.includeFiles,
    integrityHash,
  };

  await writer.add('manifest.json', new zip.TextReader(JSON.stringify(manifest, null, 2)));
  await writer.add('library.json', new zip.TextReader(dataJson));

  if (params.includeFiles) {
    const addedKeys = new Set<string>();
    for (const work of params.works) {
      if (work.archiveBlobKey && !addedKeys.has(work.archiveBlobKey)) {
        const blob = await getBinaryBlob(work.archiveBlobKey);
        if (blob) {
          addedKeys.add(work.archiveBlobKey);
          await writer.add(`files/${encodeURIComponent(work.archiveBlobKey)}`, new zip.BlobReader(blob));
        }
      }
      for (const ch of work.chapters) {
        for (const p of ch.pages) {
          if (p.blobKey && !addedKeys.has(p.blobKey)) {
            const blob = await getBinaryBlob(p.blobKey);
            if (blob) {
              addedKeys.add(p.blobKey);
              await writer.add(`files/${encodeURIComponent(p.blobKey)}`, new zip.BlobReader(blob));
            }
          }
        }
      }
    }
  }

  return await writer.close();
}

export interface InspectedBackup {
  manifest: BackupManifest;
  payload: Omit<BackupPayload, 'manifest'>;
  fileEntriesCount: number;
  integrityValid: boolean;
}

export async function inspectBackupZip(file: File): Promise<InspectedBackup> {
  const reader = new zip.ZipReader(new zip.BlobReader(file));
  try {
    const entries = await reader.getEntries();
    const manifestEntry = entries.find((e) => e.filename === 'manifest.json');
    const libraryEntry = entries.find((e) => e.filename === 'library.json');

    if (!manifestEntry || !libraryEntry || !('getData' in manifestEntry) || !('getData' in libraryEntry)) {
      throw new Error('Este arquivo não é um backup válido do Ebookfy.');
    }

    const manifestText = await manifestEntry.getData!(new zip.TextWriter());
    const libraryText = await libraryEntry.getData!(new zip.TextWriter());

    const manifest = JSON.parse(manifestText) as BackupManifest;
    if (manifest.app !== 'Ebookfy') {
      throw new Error('Manifesto incompatível com o Ebookfy.');
    }

    const actualHash = await sha256Text(libraryText);
    const payload = JSON.parse(libraryText) as Omit<BackupPayload, 'manifest'>;
    const fileEntriesCount = entries.filter((e) => e.filename.startsWith('files/') && !e.directory).length;

    return {
      manifest,
      payload,
      fileEntriesCount,
      integrityValid: actualHash === manifest.integrityHash,
    };
  } finally {
    await reader.close();
  }
}

export async function restoreBackupBlobs(file: File): Promise<Map<string, string>> {
  const reader = new zip.ZipReader(new zip.BlobReader(file));
  const remappedKeys = new Map<string, string>();
  try {
    const entries = await reader.getEntries();
    for (const entry of entries) {
      if (entry.filename.startsWith('files/') && !entry.directory && 'getData' in entry && entry.getData) {
        const encodedKey = entry.filename.slice('files/'.length);
        const originalKey = decodeURIComponent(encodedKey);
        const blob = await entry.getData(new zip.BlobWriter());
        const savedKey = await storeBinaryBlob(originalKey.replace(/^opfs:/, ''), blob);
        remappedKeys.set(originalKey, savedKey);
      }
    }
    return remappedKeys;
  } finally {
    await reader.close();
  }
}
