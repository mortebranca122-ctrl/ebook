import React, { useState } from 'react';
import { Clock, FolderPlus, Heart, Play, Trash2 } from 'lucide-react';
import type { Collection, HistoryEntry, ReadingProgress, Work } from '../types/ebookfy';
import { formatRelativeDate } from '../utils/formatters';

export const FavoritesView: React.FC<{
  works: Work[];
  progressMap: Map<string, ReadingProgress>;
  onOpenWork: (work: Work) => void;
  onContinueWork: (work: Work) => void;
  onToggleFavorite: (workId: string) => void;
}> = ({ works, progressMap, onOpenWork, onContinueWork, onToggleFavorite }) => {
  const favs = works.filter((w) => w.isFavorite);

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl sm:text-2xl font-semibold text-white">Favoritos</h1>
        <p className="text-xs text-[#bfa9b0] mt-0.5 font-mono-nums">{favs.length} obra(s) favorita(s)</p>
      </div>

      {favs.length === 0 ? (
        <div className="eb-surface p-10 text-center text-sm text-[#bfa9b0]">
          Você ainda não marcou nenhuma obra como favorita.
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 xl:grid-cols-5 gap-3.5">
          {favs.map((work) => {
            const pct = progressMap.get(work.id)?.percentage ?? 0;
            return (
              <div key={work.id} className="eb-surface overflow-hidden flex flex-col">
                <div className="relative aspect-[3/4]">
                  <button
                    type="button"
                    onClick={() => onOpenWork(work)}
                    className="w-full h-full block cursor-pointer"
                  >
                    <img src={work.coverUrl} alt={work.title} className="w-full h-full object-cover" />
                  </button>
                  <button
                    type="button"
                    onClick={() => onToggleFavorite(work.id)}
                    aria-label={`Remover ${work.title} dos favoritos`}
                    className="absolute top-2 right-2 p-1.5 rounded-lg bg-black/75 text-red-500 cursor-pointer"
                  >
                    <Heart className="w-4 h-4 fill-red-500" />
                  </button>
                </div>
                <div className="p-3 space-y-2">
                  <p className="text-sm font-semibold text-white truncate">{work.title}</p>
                  <p className="text-[11px] text-[#9d8189] font-mono-nums">
                    {work.category} · {pct}%
                  </p>
                  <button
                    type="button"
                    onClick={() => onContinueWork(work)}
                    className="w-full py-1.5 rounded-lg bg-red-950/60 hover:bg-red-900/60 border border-red-800/40 text-xs font-medium text-white inline-flex items-center justify-center gap-1 cursor-pointer"
                  >
                    <Play className="w-3 h-3 fill-white" />
                    <span>Continuar</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

export const HistoryView: React.FC<{
  history: HistoryEntry[];
  works: Work[];
  onContinueWork: (work: Work) => void;
  onClearHistory: () => void;
}> = ({ history, works, onContinueWork, onClearHistory }) => {
  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between gap-3">
        <div>
          <h1 className="text-xl sm:text-2xl font-semibold text-white">Histórico de Leitura</h1>
          <p className="text-xs text-[#bfa9b0] mt-0.5 font-mono-nums">{history.length} registro(s) locais</p>
        </div>
        {history.length > 0 && (
          <button
            type="button"
            onClick={onClearHistory}
            className="px-3.5 py-2 rounded-lg border border-red-900/40 text-xs text-[#d4c0c6] hover:text-white inline-flex items-center gap-1.5 cursor-pointer"
          >
            <Trash2 className="w-3.5 h-3.5 text-red-400" />
            <span>Limpar histórico</span>
          </button>
        )}
      </div>

      {history.length === 0 ? (
        <div className="eb-surface p-10 text-center text-sm text-[#bfa9b0]">
          Seu histórico de leitura aparecerá aqui automaticamente.
        </div>
      ) : (
        <div className="space-y-2.5">
          {history.map((item) => {
            const work = works.find((w) => w.id === item.workId);
            return (
              <div key={item.id} className="eb-surface p-3.5 flex items-center justify-between gap-3">
                <div className="flex items-center gap-3.5 min-w-0">
                  <img
                    src={item.coverUrl}
                    alt={item.workTitle}
                    className="w-12 h-16 rounded-lg object-cover border border-red-900/30 shrink-0"
                  />
                  <div className="min-w-0">
                    <p className="text-sm font-semibold text-white truncate">{item.workTitle}</p>
                    <p className="text-xs text-[#bfa9b0] truncate">
                      {item.chapterTitle} · <span className="font-mono-nums">{item.percentage}%</span>
                    </p>
                    <p className="text-[11px] text-[#846a72] mt-0.5 flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      <span>{formatRelativeDate(item.timestamp)}</span>
                    </p>
                  </div>
                </div>
                {work && (
                  <button
                    type="button"
                    onClick={() => onContinueWork(work)}
                    className="eb-accent-btn px-4 py-2 rounded-lg text-xs font-semibold shrink-0 cursor-pointer"
                  >
                    Continuar
                  </button>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

export const CollectionsView: React.FC<{
  collections: Collection[];
  works: Work[];
  onCreateCollection: (name: string, description: string) => void;
  onDeleteCollection: (id: string) => void;
  onOpenWork: (work: Work) => void;
}> = ({ collections, works, onCreateCollection, onDeleteCollection, onOpenWork }) => {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    onCreateCollection(name.trim(), description.trim());
    setName('');
    setDescription('');
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl sm:text-2xl font-semibold text-white">Coleções Personalizadas</h1>
        <p className="text-xs text-[#bfa9b0] mt-0.5">
          Agrupe mangás, manhwas e livros em estantes temáticas privadas.
        </p>
      </div>

      <form onSubmit={submit} className="eb-surface p-4 flex flex-col sm:flex-row gap-3">
        <input
          type="text"
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Nome da coleção (ex: Dark Romance Favoritos)"
          className="flex-1 px-3 py-2 rounded-lg bg-black/50 border border-red-900/40 text-xs text-white"
        />
        <input
          type="text"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          placeholder="Descrição opcional..."
          className="flex-1 px-3 py-2 rounded-lg bg-black/50 border border-red-900/40 text-xs text-white"
        />
        <button
          type="submit"
          className="eb-accent-btn px-4 py-2 rounded-lg text-xs font-semibold inline-flex items-center justify-center gap-1.5 cursor-pointer"
        >
          <FolderPlus className="w-4 h-4" />
          <span>Criar coleção</span>
        </button>
      </form>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {collections.map((col) => {
          const colWorks = works.filter((w) => col.workIds.includes(w.id));
          return (
            <div key={col.id} className="eb-surface p-4 space-y-3">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <h2 className="text-base font-semibold text-white">{col.name}</h2>
                  <p className="text-xs text-[#bfa9b0]">{col.description || 'Sem descrição'}</p>
                </div>
                <button
                  type="button"
                  onClick={() => onDeleteCollection(col.id)}
                  aria-label={`Excluir coleção ${col.name}`}
                  className="p-1.5 rounded-lg text-[#9d8189] hover:text-red-400 cursor-pointer"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
              {colWorks.length === 0 ? (
                <p className="text-xs text-[#846a72]">
                  Use &quot;Selecionar&quot; na Biblioteca para adicionar obras a esta coleção.
                </p>
              ) : (
                <div className="flex gap-2 overflow-x-auto pb-1">
                  {colWorks.map((w) => (
                    <button
                      key={w.id}
                      type="button"
                      onClick={() => onOpenWork(w)}
                      className="w-20 shrink-0 text-left cursor-pointer group"
                    >
                      <img
                        src={w.coverUrl}
                        alt={w.title}
                        className="w-20 h-28 rounded-lg object-cover border border-red-900/35 group-hover:scale-105 transition-transform"
                      />
                      <p className="text-[11px] text-[#e5d5da] truncate mt-1">{w.title}</p>
                    </button>
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
