export type CategoryType =
  | 'Mangás'
  | 'Manhwas'
  | 'Manhuas'
  | 'Webtoons'
  | 'HQs'
  | 'Livros'
  | 'PDFs'
  | 'Documentos'
  | 'Outros';

export type WorkFormat =
  | 'images'
  | 'cbz'
  | 'zip'
  | 'epub'
  | 'pdf'
  | 'txt'
  | 'docx'
  | 'rtf'
  | 'html';

export type ReadingStatus = 'nao_iniciado' | 'em_andamento' | 'concluido';

export type ReaderMode = 'manga' | 'manhwa' | 'hq' | 'book' | 'pdf';

export interface PageRef {
  id: string;
  name: string;
  pageNumber: number;
  mimeType: string;
  size: number;
  /** Key in IndexedDB `blobs` store when loose image, or zip entry path inside archiveBlobKey */
  blobKey?: string;
  archiveBlobKey?: string;
  entryPath?: string;
  /** Optional inline SVG/Data URL for built-in sample works */
  inlineUrl?: string;
}

export interface BookChapterContent {
  html?: string;
  text: string;
}

export interface Chapter {
  id: string;
  title: string;
  chapterNumber: number | null;
  orderIndex: number;
  pages: PageRef[];
  /** For EPUB/TXT/DOCX/RTF chapters */
  bookContent?: BookChapterContent;
  totalSize: number;
}

export interface Work {
  id: string;
  title: string;
  author: string;
  category: CategoryType;
  format: WorkFormat;
  readerMode: ReaderMode;
  description: string;
  coverUrl: string;
  isFavorite: boolean;
  isSample?: boolean;
  tags: string[];
  chapters: Chapter[];
  totalPages: number;
  totalSizeBytes: number;
  archiveBlobKey?: string;
  originalFileName?: string;
  sourceHash?: string;
  createdAt: number;
  updatedAt: number;
  lastReadAt?: number;
}

export interface Bookmark {
  id: string;
  workId: string;
  chapterId: string;
  chapterTitle: string;
  pageIndex: number;
  scrollRatio: number;
  note?: string;
  createdAt: number;
}

export interface ReadingProgress {
  workId: string;
  chapterId: string;
  chapterIndex: number;
  pageIndex: number;
  scrollRatio: number;
  percentage: number;
  status: ReadingStatus;
  completedChapterIds: string[];
  bookmarks: Bookmark[];
  updatedAt: number;
}

export interface Collection {
  id: string;
  name: string;
  description: string;
  workIds: string[];
  createdAt: number;
}

export interface HistoryEntry {
  id: string;
  workId: string;
  workTitle: string;
  coverUrl: string;
  category: CategoryType;
  chapterId: string;
  chapterTitle: string;
  pageIndex: number;
  percentage: number;
  timestamp: number;
}

export type ThemePresetId =
  | 'dark-romance'
  | 'blood-red'
  | 'pure-black'
  | 'crimson-glass'
  | 'minimal-dark'
  | 'custom';

export interface ThemeSettings {
  preset: ThemePresetId;
  primaryColor: string;
  secondaryColor: string;
  canvasBg: string;
  surfaceAlpha: number;
  blurIntensity: number;
  borderRadius: number;
  wallpaperDataUrl: string | null;
  enableAnimations: boolean;
  libraryViewMode: 'grid' | 'list';
}

export type BookThemeMode = 'dark' | 'light' | 'sepia';

export interface ReaderSettings {
  /** For Books (EPUB, TXT, DOCX, RTF) & PDF: explicit Claro / Escuro / Sépia */
  bookTheme: BookThemeMode;
  bookFontFamily: 'sans' | 'serif' | 'mono';
  bookFontSize: number;
  bookLineHeight: number;
  bookMarginPx: number;
  bookTextAlign: 'left' | 'justify';
  /** For Manga / HQ / Manhwa */
  imageBgMode: 'pure-black' | 'dark' | 'light';
  mangaDirection: 'rtl' | 'ltr';
  mangaPageLayout: 'single' | 'double';
  imageFitMode: 'width' | 'height' | 'screen' | 'original';
  webtoonGapPx: number;
  webtoonMaxWidthPx: number;
  preloadCount: number;
  autoHideControlsMs: number;
  pdfTheme: 'dark' | 'light';
}

export interface SecuritySettings {
  lockEnabled: boolean;
  passwordHash: string | null;
  passwordSalt: string | null;
  recoveryCodeHash: string | null;
  inactivityMinutes: number; // 0 = only on full reopen
  lockOnMinimize: boolean;
}

export type NavSection =
  | 'inicio'
  | 'biblioteca'
  | 'favoritos'
  | 'historico'
  | 'colecoes'
  | 'importar'
  | 'armazenamento'
  | 'backup'
  | 'personalizacao'
  | 'seguranca'
  | 'configuracoes';

export interface ImportQueueItem {
  id: string;
  fileName: string;
  detectedType: string;
  sizeBytes: number;
  progress: number;
  stage: string;
  status: 'pending' | 'processing' | 'review' | 'done' | 'error';
  error?: string;
}
