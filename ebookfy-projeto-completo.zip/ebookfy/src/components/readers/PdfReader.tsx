import React, { useEffect, useRef, useState } from 'react';
import {
  ArrowLeft,
  Bookmark,
  ChevronLeft,
  ChevronRight,
  Moon,
  RotateCw,
  Search,
  Sun,
  ZoomIn,
  ZoomOut,
} from 'lucide-react';
import type { ReaderSettings, ReadingProgress, Work } from '../../types/ebookfy';
import { getBinaryBlob } from '../../services/db';

interface PdfReaderProps {
  work: Work;
  initialProgress?: ReadingProgress;
  readerSettings: ReaderSettings;
  onUpdateReaderSettings: (next: ReaderSettings) => void;
  onSaveProgress: (update: {
    chapterIndex: number;
    pageIndex: number;
    scrollRatio: number;
    percentage: number;
    completedChapter?: boolean;
  }) => void;
  onAddBookmark: (chapterIndex: number, pageIndex: number, scrollRatio: number) => void;
  onClose: () => void;
}

export const PdfReader: React.FC<PdfReaderProps> = ({
  work,
  initialProgress,
  readerSettings,
  onUpdateReaderSettings,
  onSaveProgress,
  onAddBookmark,
  onClose,
}) => {
  const [numPages, setNumPages] = useState<number>(work.totalPages || 1);
  const [pageNumber, setPageNumber] = useState<number>(() => (initialProgress?.pageIndex ?? 0) + 1);
  const [scale, setScale] = useState<number>(1.25);
  const [rotation, setRotation] = useState<number>(0);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [searchOpen, setSearchOpen] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [searchMatches, setSearchMatches] = useState<number[]>([]);

  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const pdfDocRef = useRef<import('pdfjs-dist').PDFDocumentProxy | null>(null);

  useEffect(() => {
    let cancelled = false;
    let activeTask: import('pdfjs-dist').PDFDocumentLoadingTask | null = null;
    async function loadPdf() {
      if (!work.archiveBlobKey) {
        setError('Arquivo PDF local não encontrado.');
        setLoading(false);
        return;
      }
      try {
        setLoading(true);
        const blob = await getBinaryBlob(work.archiveBlobKey);
        if (!blob) throw new Error('Arquivo PDF indisponível no armazenamento local.');
        const pdfjs = await import('pdfjs-dist');
        pdfjs.GlobalWorkerOptions.workerSrc = new URL(
          'pdfjs-dist/build/pdf.worker.min.mjs',
          import.meta.url
        ).toString();
        const data = await blob.arrayBuffer();
        const loadingTask = pdfjs.getDocument({ data });
        activeTask = loadingTask;
        const doc = await loadingTask.promise;
        if (cancelled) {
          await loadingTask.destroy();
          return;
        }
        pdfDocRef.current = doc;
        setNumPages(doc.numPages);
        setPageNumber((prev) => Math.max(1, Math.min(doc.numPages, prev)));
        setError(null);
      } catch (err) {
        if (!cancelled) setError(err instanceof Error ? err.message : 'Falha ao abrir PDF.');
      } finally {
        if (!cancelled) setLoading(false);
      }
    }
    loadPdf();
    return () => {
      cancelled = true;
      activeTask?.destroy().catch(() => {});
      pdfDocRef.current = null;
    };
  }, [work.archiveBlobKey]);

  useEffect(() => {
    let cancelled = false;
    async function renderCurrentPage() {
      const doc = pdfDocRef.current;
      const canvas = canvasRef.current;
      if (!doc || !canvas) return;
      try {
        const page = await doc.getPage(pageNumber);
        if (cancelled) return;
        const viewport = page.getViewport({ scale, rotation });
        canvas.width = Math.floor(viewport.width);
        canvas.height = Math.floor(viewport.height);
        const ctx = canvas.getContext('2d');
        if (!ctx) return;
        await page.render({ canvasContext: ctx, viewport, canvas }).promise;
      } catch {
        // ignore cancelled render
      }
    }
    renderCurrentPage();
    onSaveProgress({
      chapterIndex: 0,
      pageIndex: Math.max(0, pageNumber - 1),
      scrollRatio: pageNumber / Math.max(1, numPages),
      percentage: Math.max(1, Math.round((pageNumber / Math.max(1, numPages)) * 100)),
      completedChapter: pageNumber >= numPages,
    });
    return () => {
      cancelled = true;
    };
  }, [pageNumber, numPages, scale, rotation, onSaveProgress]);

  const handleSearch = async () => {
    const doc = pdfDocRef.current;
    const q = searchQuery.trim().toLowerCase();
    if (!doc || q.length < 2) {
      setSearchMatches([]);
      return;
    }
    const hits: number[] = [];
    for (let i = 1; i <= doc.numPages; i++) {
      const page = await doc.getPage(i);
      const tc = await page.getTextContent();
      const text = tc.items.map((it) => ('str' in it ? it.str : '')).join(' ').toLowerCase();
      if (text.includes(q)) hits.push(i);
    }
    setSearchMatches(hits);
    if (hits.length > 0) setPageNumber(hits[0]);
  };

  const isDark = readerSettings.pdfTheme === 'dark';

  return (
    <div
      data-testid="pdf-reader"
      className={`fixed inset-0 z-50 flex flex-col ${
        isDark ? 'bg-[#000000] text-white' : 'bg-[#f4f1ed] text-neutral-900'
      }`}
    >
      <header className="h-14 px-3 sm:px-6 bg-[#0b0508]/95 border-b border-red-900/35 text-white flex items-center justify-between gap-2 shrink-0">
        <div className="flex items-center gap-2.5 min-w-0">
          <button
            type="button"
            onClick={onClose}
            aria-label="Fechar leitor PDF"
            className="min-w-[40px] min-h-[40px] rounded-xl border border-white/15 flex items-center justify-center cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div className="min-w-0">
            <h1 className="text-sm font-semibold truncate">{work.title}</h1>
            <p className="text-xs text-[#bfa9b0] font-mono-nums">
              Página {pageNumber} / {numPages}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            type="button"
            onClick={() =>
              onUpdateReaderSettings({
                ...readerSettings,
                pdfTheme: isDark ? 'light' : 'dark',
              })
            }
            aria-label="Alternar modo claro ou escuro do PDF"
            className="h-10 px-3 rounded-xl border border-white/15 text-xs font-medium inline-flex items-center gap-1.5 cursor-pointer"
          >
            {isDark ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-red-400" />}
            <span className="hidden sm:inline">{isDark ? 'Claro' : 'Escuro'}</span>
          </button>

          <button
            type="button"
            onClick={() => setScale((s) => Math.max(0.6, Number((s - 0.2).toFixed(2))))}
            aria-label="Diminuir zoom PDF"
            className="min-w-[40px] min-h-[40px] rounded-xl border border-white/15 flex items-center justify-center cursor-pointer"
          >
            <ZoomOut className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={() => setScale((s) => Math.min(2.6, Number((s + 0.2).toFixed(2))))}
            aria-label="Aumentar zoom PDF"
            className="min-w-[40px] min-h-[40px] rounded-xl border border-white/15 flex items-center justify-center cursor-pointer"
          >
            <ZoomIn className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={() => setRotation((r) => (r + 90) % 360)}
            aria-label="Girar página"
            className="min-w-[40px] min-h-[40px] rounded-xl border border-white/15 flex items-center justify-center cursor-pointer"
          >
            <RotateCw className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={() => setSearchOpen((o) => !o)}
            aria-label="Buscar texto no PDF"
            className="min-w-[40px] min-h-[40px] rounded-xl border border-white/15 flex items-center justify-center cursor-pointer"
          >
            <Search className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={() => onAddBookmark(0, pageNumber - 1, pageNumber / Math.max(1, numPages))}
            aria-label="Marcar página PDF"
            className="min-w-[40px] min-h-[40px] rounded-xl border border-white/15 flex items-center justify-center cursor-pointer"
          >
            <Bookmark className="w-4 h-4" />
          </button>
        </div>
      </header>

      {searchOpen && (
        <div className="bg-[#12080c] border-b border-red-900/35 px-4 py-2.5 flex flex-wrap items-center gap-2 text-white">
          <input
            type="search"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
            placeholder="Buscar texto no PDF..."
            className="flex-1 min-w-[200px] px-3 py-1.5 rounded-lg bg-black/50 border border-red-900/40 text-xs text-white focus:outline-none"
          />
          <button
            type="button"
            onClick={handleSearch}
            className="eb-accent-btn px-3.5 py-1.5 rounded-lg text-xs font-medium cursor-pointer"
          >
            Buscar
          </button>
          {searchMatches.length > 0 && (
            <div className="flex items-center gap-1.5 text-xs text-[#cbb8be] flex-wrap">
              <span>Páginas:</span>
              {searchMatches.slice(0, 8).map((p) => (
                <button
                  key={p}
                  type="button"
                  onClick={() => setPageNumber(p)}
                  className={`px-2 py-0.5 rounded border font-mono-nums cursor-pointer ${
                    p === pageNumber ? 'bg-red-700 border-red-500 text-white' : 'border-white/15'
                  }`}
                >
                  {p}
                </button>
              ))}
            </div>
          )}
        </div>
      )}

      <main className="flex-1 overflow-auto flex items-start justify-center p-4 sm:p-8">
        {loading ? (
          <div className="m-auto text-sm text-[#bfa9b0]">Carregando documento PDF...</div>
        ) : error ? (
          <div className="m-auto max-w-md p-6 rounded-2xl bg-[#12080c] border border-red-800/50 text-center text-sm text-red-200">
            {error}
          </div>
        ) : (
          <canvas
            ref={canvasRef}
            className={`shadow-2xl rounded-sm transition-[filter] duration-200 ${
              isDark ? 'invert-[0.93] hue-rotate-180 contrast-110' : ''
            }`}
          />
        )}
      </main>

      <footer className="h-14 px-4 bg-[#0b0508]/95 border-t border-red-900/35 text-white flex items-center justify-center gap-4 shrink-0">
        <button
          type="button"
          disabled={pageNumber <= 1}
          onClick={() => setPageNumber((p) => Math.max(1, p - 1))}
          className="px-3 py-1.5 rounded-lg border border-white/15 text-xs inline-flex items-center gap-1 disabled:opacity-40 cursor-pointer"
        >
          <ChevronLeft className="w-4 h-4" />
          <span>Anterior</span>
        </button>
        <span className="text-xs font-mono-nums">
          {pageNumber} / {numPages}
        </span>
        <button
          type="button"
          disabled={pageNumber >= numPages}
          onClick={() => setPageNumber((p) => Math.min(numPages, p + 1))}
          className="px-3 py-1.5 rounded-lg border border-white/15 text-xs inline-flex items-center gap-1 disabled:opacity-40 cursor-pointer"
        >
          <span>Próxima</span>
          <ChevronRight className="w-4 h-4" />
        </button>
      </footer>
    </div>
  );
};
