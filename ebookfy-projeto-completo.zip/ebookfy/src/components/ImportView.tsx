import React, { useRef, useState } from 'react';
import {
  AlertTriangle,
  ArrowDown,
  ArrowUp,
  CheckCircle2,
  FileArchive,
  FolderUp,
  Loader2,
  UploadCloud,
} from 'lucide-react';
import type {
  CategoryType,
  ImportQueueItem,
  ReaderMode,
  Work,
} from '../types/ebookfy';
import {
  finalizeImportDraft,
  processBatchImagesForImport,
  processSingleFileForImport,
  type ImportPreviewDraft,
} from '../services/importer';
import { formatBytes } from '../utils/formatters';
import { isImageFilename, verifyChapterOrder } from '../utils/naturalSort';

interface ImportViewProps {
  existingWorks: Work[];
  onImportComplete: (works: Work[]) => void;
  onOpenWork: (work: Work) => void;
}

const CATEGORIES: CategoryType[] = [
  'Mangás',
  'Manhwas',
  'Manhuas',
  'Webtoons',
  'HQs',
  'Livros',
  'PDFs',
  'Documentos',
  'Outros',
];

export const ImportView: React.FC<ImportViewProps> = ({
  existingWorks,
  onImportComplete,
  onOpenWork,
}) => {
  const [queue, setQueue] = useState<ImportQueueItem[]>([]);
  const [drafts, setDrafts] = useState<ImportPreviewDraft[]>([]);
  const [isDragging, setIsDragging] = useState(false);

  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const folderInputRef = useRef<HTMLInputElement | null>(null);

  const updateQueue = (id: string, patch: Partial<ImportQueueItem>) => {
    setQueue((prev) => prev.map((q) => (q.id === id ? { ...q, ...patch } : q)));
  };

  const handleFilesSelected = async (fileList: FileList | File[]) => {
    const files = Array.from(fileList);
    if (files.length === 0) return;

    // Separate archives/documents vs loose/folder images
    const nonImages = files.filter((f) => !isImageFilename(f.name));
    const looseImages = files.filter((f) => isImageFilename(f.name));

    if (looseImages.length > 0) {
      const qId = `job-${crypto.randomUUID()}`;
      const totalSize = looseImages.reduce((s, f) => s + f.size, 0);
      setQueue((prev) => [
        {
          id: qId,
          fileName:
            looseImages.length === 1
              ? looseImages[0].name
              : `Pasta/Lote (${looseImages.length} imagens)`,
          detectedType: 'Imagens / Capítulos',
          sizeBytes: totalSize,
          progress: 5,
          stage: 'Verificando ordem natural...',
          status: 'processing',
        },
        ...prev,
      ]);

      try {
        const draft = await processBatchImagesForImport(looseImages, (pct, stage) =>
          updateQueue(qId, { progress: pct, stage })
        );
        updateQueue(qId, { progress: 100, stage: 'Aguardando confirmação', status: 'review' });
        setDrafts((prev) => [...prev, draft]);
      } catch (err) {
        updateQueue(qId, {
          status: 'error',
          stage: 'Falha',
          error: err instanceof Error ? err.message : 'Erro ao processar imagens.',
        });
      }
    }

    for (const file of nonImages) {
      const qId = `job-${crypto.randomUUID()}`;
      setQueue((prev) => [
        {
          id: qId,
          fileName: file.name,
          detectedType: file.name.split('.').pop()?.toUpperCase() || 'Arquivo',
          sizeBytes: file.size,
          progress: 5,
          stage: 'Analisando assinatura...',
          status: 'processing',
        },
        ...prev,
      ]);

      try {
        const draft = await processSingleFileForImport(file, (pct, stage) =>
          updateQueue(qId, { progress: pct, stage })
        );
        updateQueue(qId, { progress: 100, stage: 'Pronto para revisar', status: 'review' });
        setDrafts((prev) => [...prev, draft]);
      } catch (err) {
        updateQueue(qId, {
          status: 'error',
          stage: 'Falha',
          error: err instanceof Error ? err.message : 'Erro ao processar arquivo.',
        });
      }
    }
  };

  const updateDraft = (draftId: string, patch: Partial<ImportPreviewDraft>) => {
    setDrafts((prev) => prev.map((d) => (d.id === draftId ? { ...d, ...patch } : d)));
  };

  const moveDraftChapter = (draftId: string, idx: number, delta: -1 | 1) => {
    setDrafts((prev) =>
      prev.map((d) => {
        if (d.id !== draftId) return d;
        const target = idx + delta;
        if (target < 0 || target >= d.chapters.length) return d;
        const nextCh = [...d.chapters];
        const [item] = nextCh.splice(idx, 1);
        nextCh.splice(target, 0, item);
        return {
          ...d,
          chapters: nextCh.map((c, i) => ({ ...c, orderIndex: i })),
          verification: verifyChapterOrder(nextCh),
        };
      })
    );
  };

  const confirmAllDrafts = () => {
    if (drafts.length === 0) return;
    const finalized = drafts.map(finalizeImportDraft);
    onImportComplete(finalized);
    setDrafts([]);
    setQueue((prev) =>
      prev.map((q) => (q.status === 'review' ? { ...q, status: 'done', stage: 'Importado na biblioteca' } : q))
    );
    if (finalized.length === 1) {
      onOpenWork(finalized[0]);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl sm:text-2xl font-semibold text-white">Importação Universal</h1>
        <p className="text-xs sm:text-sm text-[#bfa9b0] mt-1">
          Sem limite de tamanho para arquivos ZIP/CBZ (MB ou GB via streaming local). Capítulos e páginas são
          verificados e ordenados automaticamente em sequência numérica.
        </p>
      </div>

      {/* Dropzone */}
      <div
        onDragOver={(e) => {
          e.preventDefault();
          setIsDragging(true);
        }}
        onDragLeave={() => setIsDragging(false)}
        onDrop={(e) => {
          e.preventDefault();
          setIsDragging(false);
          if (e.dataTransfer.files?.length) {
            handleFilesSelected(e.dataTransfer.files);
          }
        }}
        className={`eb-surface p-8 sm:p-10 text-center transition-all border-dashed border-2 ${
          isDragging ? 'border-red-500 bg-red-950/25' : 'border-red-900/45'
        }`}
      >
        <div className="w-14 h-14 mx-auto rounded-2xl bg-red-950/50 border border-red-800/45 flex items-center justify-center text-red-400 mb-4">
          <UploadCloud className="w-7 h-7" />
        </div>
        <h2 className="text-base font-semibold text-white">
          Arraste arquivos ZIP, CBZ, EPUB, PDF, DOCX, TXT ou pastas com imagens
        </h2>
        <p className="text-xs text-[#9d8189] mt-1.5 max-w-xl mx-auto">
          Todo processamento ocorre 100% no seu dispositivo. Arquivos grandes usam leitura por fluxo sem travar a
          memória nem reduzir a qualidade original das páginas.
        </p>

        <div className="mt-5 flex flex-wrap items-center justify-center gap-3">
          <input
            ref={fileInputRef}
            type="file"
            multiple
            aria-label="Selecionar arquivos para importar"
            accept=".zip,.cbz,.epub,.pdf,.txt,.md,.rtf,.docx,.html,.htm,image/*"
            onChange={(e) => {
              if (e.target.files?.length) handleFilesSelected(e.target.files);
              e.target.value = '';
            }}
            className="hidden"
          />
          <input
            ref={folderInputRef}
            type="file"
            multiple
            aria-label="Selecionar pasta de capítulos"
            // @ts-expect-error webkitdirectory is supported in Chromium/Desktop/Android browsers
            webkitdirectory=""
            onChange={(e) => {
              if (e.target.files?.length) handleFilesSelected(e.target.files);
              e.target.value = '';
            }}
            className="hidden"
          />

          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="eb-accent-btn px-5 py-2.5 rounded-xl text-xs font-semibold inline-flex items-center gap-2 cursor-pointer"
          >
            <FileArchive className="w-4 h-4" />
            <span>Selecionar Arquivos (ZIP, CBZ, EPUB, PDF...)</span>
          </button>

          <button
            type="button"
            onClick={() => folderInputRef.current?.click()}
            className="px-5 py-2.5 rounded-xl bg-white/[0.04] hover:bg-white/[0.08] border border-red-900/40 text-xs font-medium text-white inline-flex items-center gap-2 cursor-pointer"
          >
            <FolderUp className="w-4 h-4 text-red-400" />
            <span>Selecionar Pasta Completa</span>
          </button>
        </div>
      </div>

      {/* Review & Order Verification Panel */}
      {drafts.length > 0 && (
        <section className="eb-surface p-5 space-y-5 border-red-600/50">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <h2 className="text-base font-semibold text-white">
                Verificação de Ordem & Metadados ({drafts.length})
              </h2>
              <p className="text-xs text-[#bfa9b0]">
                Confira a sequência dos capítulos (1, 2, 3, 4, 5...) e ajuste categoria ou leitor antes de salvar.
              </p>
            </div>
            <button
              type="button"
              onClick={confirmAllDrafts}
              className="eb-accent-btn px-5 py-2.5 rounded-xl text-xs font-semibold cursor-pointer"
            >
              Confirmar e Adicionar à Biblioteca
            </button>
          </div>

          <div className="space-y-4">
            {drafts.map((draft) => {
              const duplicate = existingWorks.some(
                (w) =>
                  (draft.sourceHash && w.sourceHash === draft.sourceHash) ||
                  w.title.toLowerCase() === draft.title.toLowerCase()
              );

              return (
                <div key={draft.id} className="pt-4 border-t border-red-900/25 first:pt-0 first:border-t-0 space-y-4">
                  <div className="flex flex-col sm:flex-row gap-4">
                    <img
                      src={draft.coverUrl}
                      alt={draft.title}
                      className="w-24 h-32 rounded-lg object-cover border border-red-900/35 shrink-0"
                    />
                    <div className="flex-1 grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-[11px] text-[#9d8189] mb-1">Título da Obra</label>
                        <input
                          type="text"
                          value={draft.title}
                          onChange={(e) => updateDraft(draft.id, { title: e.target.value })}
                          className="w-full px-3 py-1.5 rounded-lg bg-black/50 border border-red-900/40 text-xs text-white"
                        />
                      </div>
                      <div>
                        <label className="block text-[11px] text-[#9d8189] mb-1">Autor</label>
                        <input
                          type="text"
                          value={draft.author}
                          onChange={(e) => updateDraft(draft.id, { author: e.target.value })}
                          className="w-full px-3 py-1.5 rounded-lg bg-black/50 border border-red-900/40 text-xs text-white"
                        />
                      </div>
                      <div>
                        <label className="block text-[11px] text-[#9d8189] mb-1">Categoria</label>
                        <select
                          value={draft.category}
                          onChange={(e) => {
                            const cat = e.target.value as CategoryType;
                            const nextMode: ReaderMode =
                              cat === 'Livros' || cat === 'Documentos'
                                ? 'book'
                                : cat === 'PDFs'
                                ? 'pdf'
                                : cat === 'Manhwas' || cat === 'Webtoons'
                                ? 'manhwa'
                                : cat === 'HQs'
                                ? 'hq'
                                : 'manga';
                            updateDraft(draft.id, { category: cat, readerMode: nextMode });
                          }}
                          className="w-full px-3 py-1.5 rounded-lg bg-[#12080c] border border-red-900/40 text-xs text-white"
                        >
                          {CATEGORIES.map((c) => (
                            <option key={c} value={c}>
                              {c}
                            </option>
                          ))}
                        </select>
                      </div>
                      <div className="flex items-end justify-between text-xs text-[#bfa9b0] font-mono-nums">
                        <span>
                          {draft.chapters.length} cap. · {draft.totalPages} pág. ·{' '}
                          {formatBytes(draft.totalSizeBytes)}
                        </span>
                      </div>
                    </div>
                  </div>

                  {duplicate && (
                    <div className="flex items-center gap-2 text-xs text-amber-300 bg-amber-950/35 border border-amber-700/40 rounded-lg px-3 py-2">
                      <AlertTriangle className="w-4 h-4 shrink-0" />
                      <span>Aviso: já existe uma obra semelhante ou idêntica na biblioteca local.</span>
                    </div>
                  )}

                  <div className="flex flex-wrap items-center gap-2 text-xs">
                    {draft.verification.isSequential ? (
                      <span className="inline-flex items-center gap-1.5 text-emerald-400">
                        <CheckCircle2 className="w-4 h-4" />
                        <span>
                          Ordem verificada: capítulos e páginas em sequência natural correta.
                        </span>
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1.5 text-amber-300">
                        <AlertTriangle className="w-4 h-4" />
                        <span>
                          Capítulos ordenados, mas faltam números na sequência:{' '}
                          {draft.verification.missingChapters.slice(0, 10).join(', ')}
                        </span>
                      </span>
                    )}
                  </div>

                  {/* Chapter order list */}
                  <div className="max-h-48 overflow-y-auto divide-y divide-white/[0.06] rounded-lg bg-black/30 px-3">
                    {draft.chapters.map((ch, idx) => (
                      <div key={ch.id} className="py-2 flex items-center justify-between gap-2 text-xs">
                        <div className="flex items-center gap-2 min-w-0">
                          <span className="font-mono-nums text-[#9d8189] w-6">{idx + 1}.</span>
                          <span className="text-white truncate">{ch.title}</span>
                          <span className="text-[#846a72] font-mono-nums shrink-0">
                            ({ch.pages.length > 0 ? `${ch.pages.length} pág.` : 'Texto'})
                          </span>
                        </div>
                        {draft.chapters.length > 1 && (
                          <div className="flex items-center gap-1 shrink-0">
                            <button
                              type="button"
                              disabled={idx === 0}
                              onClick={() => moveDraftChapter(draft.id, idx, -1)}
                              aria-label={`Subir ${ch.title}`}
                              className="p-1 rounded border border-white/10 text-[#bfa9b0] disabled:opacity-30 cursor-pointer"
                            >
                              <ArrowUp className="w-3 h-3" />
                            </button>
                            <button
                              type="button"
                              disabled={idx === draft.chapters.length - 1}
                              onClick={() => moveDraftChapter(draft.id, idx, 1)}
                              aria-label={`Descer ${ch.title}`}
                              className="p-1 rounded border border-white/10 text-[#bfa9b0] disabled:opacity-30 cursor-pointer"
                            >
                              <ArrowDown className="w-3 h-3" />
                            </button>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </section>
      )}

      {/* Batch Queue */}
      {queue.length > 0 && (
        <section className="eb-surface p-4 space-y-3">
          <h2 className="text-sm font-semibold text-white">Fila de processamento ({queue.length})</h2>
          <div className="space-y-2.5">
            {queue.map((item) => (
              <div key={item.id} className="eb-surface-subtle p-3 space-y-2">
                <div className="flex items-center justify-between gap-3 text-xs">
                  <div className="min-w-0">
                    <p className="font-medium text-white truncate">{item.fileName}</p>
                    <p className="text-[#9d8189] font-mono-nums">
                      {item.detectedType} · {formatBytes(item.sizeBytes)} · {item.stage}
                    </p>
                  </div>
                  <div className="shrink-0">
                    {item.status === 'processing' && <Loader2 className="w-4 h-4 text-red-400 animate-spin" />}
                    {item.status === 'done' && <CheckCircle2 className="w-4 h-4 text-emerald-400" />}
                    {item.status === 'error' && <AlertTriangle className="w-4 h-4 text-red-400" />}
                  </div>
                </div>
                <div className="h-1.5 rounded-full bg-white/10 overflow-hidden">
                  <div
                    className={`h-full transition-all ${item.status === 'error' ? 'bg-red-500' : 'bg-red-600'}`}
                    style={{ width: `${item.progress}%` }}
                  />
                </div>
                {item.error && <p className="text-xs text-red-300">{item.error}</p>}
              </div>
            ))}
          </div>
        </section>
      )}
    </div>
  );
};
