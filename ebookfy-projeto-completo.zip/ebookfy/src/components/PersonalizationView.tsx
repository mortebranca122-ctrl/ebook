import React from 'react';
import { Palette, RotateCcw, Upload } from 'lucide-react';
import type { ThemePresetId, ThemeSettings } from '../types/ebookfy';
import { THEME_PRESETS } from '../services/themes';
import { DEFAULT_THEME_SETTINGS } from '../services/db';

interface PersonalizationViewProps {
  theme: ThemeSettings;
  onUpdateTheme: (next: ThemeSettings) => void;
}

export const PersonalizationView: React.FC<PersonalizationViewProps> = ({
  theme,
  onUpdateTheme,
}) => {
  const selectPreset = (presetId: ThemePresetId) => {
    const found = THEME_PRESETS.find((p) => p.id === presetId);
    if (!found) return;
    onUpdateTheme({
      ...theme,
      preset: found.id,
      primaryColor: found.primaryColor,
      secondaryColor: found.secondaryColor,
      canvasBg: found.canvasBg,
      surfaceAlpha: found.surfaceAlpha,
      blurIntensity: found.blurIntensity,
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-xl sm:text-2xl font-semibold text-white">Personalização Visual</h1>
          <p className="text-xs text-[#bfa9b0] mt-0.5">
            Ajuste cores, transparência, desfoque e papel de parede com pré-visualização em tempo real.
          </p>
        </div>

        <button
          type="button"
          onClick={() => onUpdateTheme(DEFAULT_THEME_SETTINGS)}
          className="px-3.5 py-2 rounded-lg border border-white/15 text-xs text-[#d4c0c6] hover:text-white inline-flex items-center gap-1.5 cursor-pointer"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Restaurar padrão</span>
        </button>
      </div>

      {/* Presets */}
      <section className="space-y-3">
        <h2 className="text-sm font-semibold text-white flex items-center gap-2">
          <Palette className="w-4 h-4 text-red-400" />
          <span>Temas pré-definidos</span>
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {THEME_PRESETS.map((preset) => {
            const active = theme.preset === preset.id;
            return (
              <button
                key={preset.id}
                type="button"
                onClick={() => selectPreset(preset.id)}
                className={`p-4 rounded-xl border text-left transition-all cursor-pointer ${
                  active
                    ? 'border-red-500 bg-red-950/30 shadow-[0_0_20px_rgba(200,30,43,0.2)]'
                    : 'border-white/10 bg-[#12080c]/80 hover:border-red-900/50'
                }`}
              >
                <div className="flex items-center justify-between gap-2">
                  <span className="text-sm font-semibold text-white">{preset.name}</span>
                  <div className="flex items-center gap-1">
                    <span
                      className="w-4 h-4 rounded-full border border-white/20"
                      style={{ backgroundColor: preset.canvasBg }}
                    />
                    <span
                      className="w-4 h-4 rounded-full border border-white/20"
                      style={{ backgroundColor: preset.primaryColor }}
                    />
                  </div>
                </div>
                <p className="text-xs text-[#bfa9b0] mt-1.5">{preset.description}</p>
              </button>
            );
          })}
        </div>
      </section>

      {/* Live Sliders & Custom Controls */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        <section className="eb-surface p-5 space-y-4">
          <h2 className="text-sm font-semibold text-white">Ajustes personalizados</h2>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs text-[#bfa9b0] mb-1.5">Cor principal</label>
              <div className="flex items-center gap-2">
                <input
                  type="color"
                  value={theme.primaryColor}
                  onChange={(e) =>
                    onUpdateTheme({ ...theme, preset: 'custom', primaryColor: e.target.value })
                  }
                  className="w-10 h-9 rounded bg-transparent border border-white/15 cursor-pointer"
                />
                <span className="text-xs font-mono-nums text-[#e5d5da]">{theme.primaryColor}</span>
              </div>
            </div>

            <div>
              <label className="block text-xs text-[#bfa9b0] mb-1.5">Fundo principal</label>
              <div className="flex items-center gap-2">
                <input
                  type="color"
                  value={theme.canvasBg}
                  onChange={(e) =>
                    onUpdateTheme({ ...theme, preset: 'custom', canvasBg: e.target.value })
                  }
                  className="w-10 h-9 rounded bg-transparent border border-white/15 cursor-pointer"
                />
                <span className="text-xs font-mono-nums text-[#e5d5da]">{theme.canvasBg}</span>
              </div>
            </div>
          </div>

          <div className="space-y-1">
            <div className="flex justify-between text-xs text-[#bfa9b0]">
              <span>Opacidade dos painéis</span>
              <span className="font-mono-nums">{Math.round(theme.surfaceAlpha * 100)}%</span>
            </div>
            <input
              type="range"
              min={0.5}
              max={1}
              step={0.02}
              value={theme.surfaceAlpha}
              onChange={(e) =>
                onUpdateTheme({ ...theme, preset: 'custom', surfaceAlpha: Number(e.target.value) })
              }
              className="w-full accent-red-600"
            />
          </div>

          <div className="space-y-1">
            <div className="flex justify-between text-xs text-[#bfa9b0]">
              <span>Intensidade de blur (desfoque)</span>
              <span className="font-mono-nums">{theme.blurIntensity}px</span>
            </div>
            <input
              type="range"
              min={0}
              max={28}
              step={2}
              value={theme.blurIntensity}
              onChange={(e) =>
                onUpdateTheme({ ...theme, preset: 'custom', blurIntensity: Number(e.target.value) })
              }
              className="w-full accent-red-600"
            />
          </div>

          <div className="space-y-1">
            <div className="flex justify-between text-xs text-[#bfa9b0]">
              <span>Arredondamento das bordas</span>
              <span className="font-mono-nums">{theme.borderRadius}px</span>
            </div>
            <input
              type="range"
              min={4}
              max={24}
              step={2}
              value={theme.borderRadius}
              onChange={(e) =>
                onUpdateTheme({ ...theme, preset: 'custom', borderRadius: Number(e.target.value) })
              }
              className="w-full accent-red-600"
            />
          </div>
        </section>

        {/* Wallpaper & Live Preview */}
        <section className="eb-surface p-5 space-y-4">
          <h2 className="text-sm font-semibold text-white">Papel de parede local</h2>
          <p className="text-xs text-[#bfa9b0]">
            Escolha uma imagem do seu dispositivo para usar como atmosfera de fundo do aplicativo.
          </p>

          <div className="flex items-center gap-3 flex-wrap">
            <label className="px-4 py-2 rounded-xl bg-white/[0.05] hover:bg-white/[0.09] border border-red-900/40 text-xs font-medium text-white inline-flex items-center gap-2 cursor-pointer">
              <Upload className="w-4 h-4 text-red-400" />
              <span>Carregar imagem local</span>
              <input
                type="file"
                accept="image/*"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (!file) return;
                  const reader = new FileReader();
                  reader.onload = () => {
                    if (typeof reader.result === 'string') {
                      onUpdateTheme({ ...theme, wallpaperDataUrl: reader.result });
                    }
                  };
                  reader.readAsDataURL(file);
                }}
                className="hidden"
              />
            </label>

            {theme.wallpaperDataUrl && (
              <button
                type="button"
                onClick={() => onUpdateTheme({ ...theme, wallpaperDataUrl: null })}
                className="px-3 py-2 rounded-xl border border-white/15 text-xs text-[#d4c0c6] cursor-pointer"
              >
                Remover wallpaper
              </button>
            )}
          </div>

          <div className="p-4 rounded-xl border border-red-900/35 bg-black/40 space-y-2">
            <p className="text-xs font-semibold text-white">Prévia em tempo real</p>
            <p className="text-xs text-[#bfa9b0]">
              Todas as mudanças são aplicadas instantaneamente e salvas localmente.
            </p>
            <button type="button" className="eb-accent-btn px-4 py-1.5 rounded-lg text-xs font-semibold">
              Botão de destaque
            </button>
          </div>
        </section>
      </div>
    </div>
  );
};
