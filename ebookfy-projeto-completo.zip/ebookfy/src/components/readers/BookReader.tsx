import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  ArrowLeft,
  Bookmark,
  ChevronLeft,
  ChevronRight,
  List,
  Moon,
  Search,
  SlidersHorizontal,
  Sun,
  X,
} from 'lucide-react';
import type {
  BookThemeMode,
  ReaderSettings,
  ReadingProgress,
  Work,
} from '../../types/ebookfy';

interface BookReaderProps {
  work: Work;
  initialProgress?: ReadingProgress;
  initialChapterIndex?: number;
  readerSettings: ReaderSettings;
  onUpdateReaderSettings: (next: ReaderSettings) => void;
  onSaveProgress: (update: {
    chapterIndex: number;
    pageIndex: number;
    scrollRatio: number;
    percentage: number;
    completedChapter?: boolean;
  }) => void;
  onAddBookmark: (chapterIndex: number, pageIndex: number, scrollRatio: number) => void;
  onClose: () => void;
}

export const BookReader: React.FC<BookReaderProps> = ({
  work,
  initialProgress,
  initialChapterIndex,
  readerSettings,
  onUpdateReaderSettings,
  onSaveProgress,
  onAddBookmark,
  onClose,
}) => {
  const [chapterIndex, setChapterIndex] = useState<number>(() => {
    if (typeof initialChapterIndex === 'number') {
      return Math.max(0, Math.min(work.chapters.length - 1, initialChapterIndex));
    }
    return Math.max(0, Math.min(work.chapters.length - 1, initialProgress?.chapterIndex ?? 0));
  });
  const [showToc, setShowToc] = useState(false);
  const [showSearch, setShowSearch] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [bookmarkSaved, setBookmarkSaved] = useState(false);
  const [scrollPct, setScrollPct] = useState(0);

  const scrollRef = useRef<HTMLDivElement | null>(null);
  const currentChapter = work.chapters[chapterIndex];
  const paragraphs = useMemo(() => {
    const raw = currentChapter?.bookContent?.text ?? 'Sem conteúdo disponível neste capítulo.';
    return raw.split(/\n\s*\n/).filter((p) => p.trim().length > 0);
  }, [currentChapter]);

  // Restore scroll position on chapter mount
  useEffect(() => {
    const el = scrollRef.current;
    if (!el) return;
    const ratio =
      initialProgress && initialProgress.chapterIndex === chapterIndex ? initialProgress.scrollRatio : 0;
    const timer = window.setTimeout(() => {
      const max = Math.max(0, el.scrollHeight - el.clientHeight);
      el.scrollTop = Math.round(max * ratio);
    }, 60);
    return () => window.clearTimeout(timer);
  }, [chapterIndex, initialProgress]);

  const handleScroll = () => {
    const el = scrollRef.current;
    if (!el) return;
    const max = Math.max(1, el.scrollHeight - el.clientHeight);
    const ratio = Math.max(0, Math.min(1, el.scrollTop / max));
    setScrollPct(Math.round(ratio * 100));
    const overall = Math.max(
      1,
      Math.min(100, Math.round(((chapterIndex + Math.max(0.05, ratio)) / Math.max(1, work.chapters.length)) * 100))
    );
    onSaveProgress({
      chapterIndex,
      pageIndex: 0,
      scrollRatio: ratio,
      percentage: overall,
      completedChapter: ratio >= 0.92,
    });
  };

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        if (showSettings || showToc || showSearch) {
          setShowSettings(false);
          setShowToc(false);
          setShowSearch(false);
        } else {
          onClose();
        }
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [onClose, showSettings, showToc, showSearch]);

  // Explicit Claro / Escuro / Sépia reading surface:
  // Dark mode uses pure black (#000000) background + crisp white (#FFFFFF) text for maximum comfort!
  const themeStyles = useMemo(() => {
    switch (readerSettings.bookTheme) {
      case 'light':
        return {
          container: 'bg-[#FAF7F2] text-[#171416]',
          bar: 'bg-[#F2ECE3]/95 border-[#E2D8CA] text-[#171416]',
          muted: 'text-[#665B52]',
          card: 'bg-white border-[#E5DDD0] text-[#171416]',
          proseColor: '#141214',
        };
      case 'sepia':
        return {
          container: 'bg-[#F4ECD8] text-[#2D2116]',
          bar: 'bg-[#EAE0C8]/95 border-[#D6C7A8] text-[#2D2116]',
          muted: 'text-[#6B5742]',
          card: 'bg-[#FAF4E4] border-[#D8C9AA] text-[#2D2116]',
          proseColor: '#2D2116',
        };
      case 'dark':
      default:
        return {
          container: 'bg-[#000000] text-[#FFFFFF]',
          bar: 'bg-[#090608]/95 border-red-900/35 text-[#FFFFFF]',
          muted: 'text-[#A89AA0]',
          card: 'bg-[#10090c] border-red-900/40 text-[#FFFFFF]',
          proseColor: '#FFFFFF',
        };
    }
  }, [readerSettings.bookTheme]);

  const fontClass =
    readerSettings.bookFontFamily === 'serif'
      ? 'font-book-serif'
      : readerSettings.bookFontFamily === 'mono'
      ? 'font-mono'
      : 'font-sans';

  const searchResults = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    if (q.length < 2) return [];
    const hits: Array<{ chapterIndex: number; chapterTitle: string; snippet: string }> = [];
    work.chapters.forEach((ch, idx) => {
      const txt = ch.bookContent?.text ?? '';
      const pos = txt.toLowerCase().indexOf(q);
      if (pos !== -1) {
        const start = Math.max(0, pos - 40);
        const end = Math.min(txt.length, pos + q.length + 70);
        hits.push({
          chapterIndex: idx,
          chapterTitle: ch.title,
          snippet: `${start > 0 ? '...' : ''}${txt.slice(start, end)}${end < txt.length ? '...' : ''}`,
        });
      }
    });
    return hits;
  }, [searchQuery, work.chapters]);

  const renderHighlightedParagraph = (text: string) => {
    const q = searchQuery.trim();
    if (q.length < 2) return text;
    const parts = text.split(new RegExp(`(${q.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'gi'));
    return parts.map((part, i) =>
      part.toLowerCase() === q.toLowerCase() ? (
        <mark key={i} className="bg-red-600/80 text-white px-0.5 rounded">
          {part}
        </mark>
      ) : (
        part
      )
    );
  };

  return (
    <div
      data-testid="book-reader"
      data-book-theme={readerSettings.bookTheme}
      className={`fixed inset-0 z-50 flex flex-col transition-colors duration-200 ${themeStyles.container}`}
    >
      {/* Top Bar */}
      <header className={`h-14 px-3 sm:px-6 border-b flex items-center justify-between gap-3 shrink-0 ${themeStyles.bar}`}>
        <div className="flex items-center gap-2.5 min-w-0">
          <button
            type="button"
            onClick={onClose}
            aria-label="Fechar leitor de livro"
            className="min-w-[40px] min-h-[40px] rounded-xl border border-current/15 flex items-center justify-center hover:opacity-80 cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div className="min-w-0">
            <h1 className="text-sm font-semibold truncate">{work.title}</h1>
            <p className={`text-xs truncate ${themeStyles.muted}`}>
              {currentChapter?.title} · <span className="font-mono-nums">{scrollPct}%</span>
            </p>
          </div>
        </div>

        <div className="flex items-center gap-1.5 shrink-0">
          {/* Quick Claro / Escuro Toggle */}
          <button
            type="button"
            onClick={() =>
              onUpdateReaderSettings({
                ...readerSettings,
                bookTheme: readerSettings.bookTheme === 'dark' ? 'light' : 'dark',
              })
            }
            aria-label={
              readerSettings.bookTheme === 'dark'
                ? 'Mudar para modo claro'
                : 'Mudar para modo escuro (fundo preto e letras brancas)'
            }
            className="h-10 px-3 rounded-xl border border-current/20 text-xs font-medium inline-flex items-center gap-1.5 hover:opacity-85 cursor-pointer"
          >
            {readerSettings.bookTheme === 'dark' ? (
              <>
                <Sun className="w-4 h-4 text-amber-400" />
                <span className="hidden sm:inline">Modo Claro</span>
              </>
            ) : (
              <>
                <Moon className="w-4 h-4 text-red-500" />
                <span className="hidden sm:inline">Modo Escuro</span>
              </>
            )}
          </button>

          <button
            type="button"
            onClick={() => {
              setShowToc((s) => !s);
              setShowSearch(false);
              setShowSettings(false);
            }}
            aria-label="Sumário"
            className="min-w-[40px] min-h-[40px] rounded-xl border border-current/15 flex items-center justify-center cursor-pointer"
          >
            <List className="w-4 h-4" />
          </button>

          <button
            type="button"
            onClick={() => {
              setShowSearch((s) => !s);
              setShowToc(false);
              setShowSettings(false);
            }}
            aria-label="Buscar no texto"
            className="min-w-[40px] min-h-[40px] rounded-xl border border-current/15 flex items-center justify-center cursor-pointer"
          >
            <Search className="w-4 h-4" />
          </button>

          <button
            type="button"
            onClick={() => {
              const el = scrollRef.current;
              const ratio = el ? el.scrollTop / Math.max(1, el.scrollHeight - el.clientHeight) : 0;
              onAddBookmark(chapterIndex, 0, ratio);
              setBookmarkSaved(true);
              setTimeout(() => setBookmarkSaved(false), 1800);
            }}
            aria-label="Salvar marcador"
            className="min-w-[40px] min-h-[40px] rounded-xl border border-current/15 flex items-center justify-center cursor-pointer"
          >
            <Bookmark className="w-4 h-4" />
          </button>

          <button
            type="button"
            onClick={() => {
              setShowSettings((s) => !s);
              setShowToc(false);
              setShowSearch(false);
            }}
            aria-label="Aparência e tipografia"
            className="min-w-[40px] min-h-[40px] rounded-xl border border-current/15 flex items-center justify-center cursor-pointer"
          >
            <SlidersHorizontal className="w-4 h-4" />
          </button>
        </div>
      </header>

      {bookmarkSaved && (
        <div className="fixed top-16 right-4 z-40 px-3.5 py-2 rounded-lg bg-red-900 text-white text-xs shadow-lg">
          Marcador salvo em {currentChapter?.title}
        </div>
      )}

      {/* TOC Drawer */}
      {showToc && (
        <aside className={`fixed top-14 left-0 bottom-14 z-40 w-80 max-w-[85vw] border-r p-4 overflow-y-auto shadow-2xl ${themeStyles.card}`}>
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-sm font-semibold">Sumário ({work.chapters.length})</h2>
            <button type="button" onClick={() => setShowToc(false)} aria-label="Fechar sumário" className="cursor-pointer">
              <X className="w-4 h-4" />
            </button>
          </div>
          <div className="space-y-1">
            {work.chapters.map((ch, idx) => (
              <button
                key={ch.id}
                type="button"
                onClick={() => {
                  setChapterIndex(idx);
                  setShowToc(false);
                }}
                className={`w-full text-left px-3 py-2.5 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                  idx === chapterIndex
                    ? 'bg-red-800/40 border border-red-600/50 text-white'
                    : 'hover:bg-current/5'
                }`}
              >
                {ch.title}
              </button>
            ))}
          </div>
        </aside>
      )}

      {/* Search Drawer */}
      {showSearch && (
        <aside className={`fixed top-14 right-0 bottom-14 z-40 w-80 max-w-[90vw] border-l p-4 overflow-y-auto shadow-2xl ${themeStyles.card}`}>
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-sm font-semibold">Buscar no livro</h2>
            <button type="button" onClick={() => setShowSearch(false)} aria-label="Fechar busca" className="cursor-pointer">
              <X className="w-4 h-4" />
            </button>
          </div>
          <input
            type="search"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Digite palavra ou trecho..."
            className="w-full px-3 py-2 rounded-lg border border-current/20 bg-transparent text-xs focus:outline-none focus:border-red-500"
          />
          <div className="mt-3 space-y-2">
            {searchQuery.trim().length >= 2 && searchResults.length === 0 && (
              <p className={`text-xs ${themeStyles.muted}`}>Nenhum trecho encontrado.</p>
            )}
            {searchResults.map((hit, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => {
                  setChapterIndex(hit.chapterIndex);
                  setShowSearch(false);
                }}
                className="w-full text-left p-2.5 rounded-lg border border-current/15 hover:border-red-500/50 text-xs space-y-1 cursor-pointer"
              >
                <p className="font-semibold text-red-400">{hit.chapterTitle}</p>
                <p className={`line-clamp-3 ${themeStyles.muted}`}>{hit.snippet}</p>
              </button>
            ))}
          </div>
        </aside>
      )}

      {/* Typography & Theme Settings Drawer */}
      {showSettings && (
        <div className={`fixed top-16 right-4 z-40 w-80 max-w-[calc(100vw-2rem)] border rounded-2xl p-4 shadow-2xl space-y-4 ${themeStyles.card}`}>
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-semibold">Conforto de Leitura</h2>
            <button type="button" onClick={() => setShowSettings(false)} className="text-xs opacity-70 cursor-pointer">
              Fechar
            </button>
          </div>

          <div className="space-y-1.5">
            <span className="text-xs opacity-75">Tema de leitura</span>
            <div className="grid grid-cols-3 gap-1.5">
              {[
                { id: 'dark', label: 'Escuro' },
                { id: 'light', label: 'Claro' },
                { id: 'sepia', label: 'Sépia' },
              ].map((t) => (
                <button
                  key={t.id}
                  type="button"
                  onClick={() =>
                    onUpdateReaderSettings({ ...readerSettings, bookTheme: t.id as BookThemeMode })
                  }
                  className={`py-2 rounded-lg text-xs font-medium border cursor-pointer ${
                    readerSettings.bookTheme === t.id
                      ? 'bg-red-700 text-white border-red-500'
                      : 'border-current/20 opacity-80'
                  }`}
                >
                  {t.label}
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-1.5">
            <span className="text-xs opacity-75">Fonte</span>
            <div className="grid grid-cols-3 gap-1.5">
              {[
                { id: 'serif', label: 'Serifa' },
                { id: 'sans', label: 'Moderna' },
                { id: 'mono', label: 'Mono' },
              ].map((f) => (
                <button
                  key={f.id}
                  type="button"
                  onClick={() =>
                    onUpdateReaderSettings({
                      ...readerSettings,
                      bookFontFamily: f.id as ReaderSettings['bookFontFamily'],
                    })
                  }
                  className={`py-1.5 rounded-lg text-xs font-medium border cursor-pointer ${
                    readerSettings.bookFontFamily === f.id
                      ? 'bg-red-700 text-white border-red-500'
                      : 'border-current/20 opacity-80'
                  }`}
                >
                  {f.label}
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-1">
            <div className="flex justify-between text-xs opacity-80">
              <span>Tamanho da fonte</span>
              <span className="font-mono-nums">{readerSettings.bookFontSize}px</span>
            </div>
            <input
              type="range"
              min={14}
              max={30}
              value={readerSettings.bookFontSize}
              onChange={(e) =>
                onUpdateReaderSettings({ ...readerSettings, bookFontSize: Number(e.target.value) })
              }
              className="w-full accent-red-600"
            />
          </div>

          <div className="space-y-1">
            <div className="flex justify-between text-xs opacity-80">
              <span>Espaçamento entre linhas</span>
              <span className="font-mono-nums">{readerSettings.bookLineHeight.toFixed(2)}</span>
            </div>
            <input
              type="range"
              min={1.35}
              max={2.2}
              step={0.05}
              value={readerSettings.bookLineHeight}
              onChange={(e) =>
                onUpdateReaderSettings({ ...readerSettings, bookLineHeight: Number(e.target.value) })
              }
              className="w-full accent-red-600"
            />
          </div>

          <div className="space-y-1">
            <div className="flex justify-between text-xs opacity-80">
              <span>Margens laterais</span>
              <span className="font-mono-nums">{readerSettings.bookMarginPx}px</span>
            </div>
            <input
              type="range"
              min={12}
              max={96}
              step={4}
              value={readerSettings.bookMarginPx}
              onChange={(e) =>
                onUpdateReaderSettings({ ...readerSettings, bookMarginPx: Number(e.target.value) })
              }
              className="w-full accent-red-600"
            />
          </div>

          <div className="grid grid-cols-2 gap-1.5">
            <button
              type="button"
              onClick={() => onUpdateReaderSettings({ ...readerSettings, bookTextAlign: 'left' })}
              className={`py-1.5 rounded-lg text-xs border cursor-pointer ${
                readerSettings.bookTextAlign === 'left'
                  ? 'bg-red-700 text-white border-red-500'
                  : 'border-current/20 opacity-80'
              }`}
            >
              Alinhado à esquerda
            </button>
            <button
              type="button"
              onClick={() => onUpdateReaderSettings({ ...readerSettings, bookTextAlign: 'justify' })}
              className={`py-1.5 rounded-lg text-xs border cursor-pointer ${
                readerSettings.bookTextAlign === 'justify'
                  ? 'bg-red-700 text-white border-red-500'
                  : 'border-current/20 opacity-80'
              }`}
            >
              Justificado
            </button>
          </div>
        </div>
      )}

      {/* Reflowable Prose Area */}
      <main
        ref={scrollRef}
        onScroll={handleScroll}
        className="flex-1 overflow-y-auto py-8 sm:py-12"
      >
        <article
          className={`mx-auto max-w-[760px] ${fontClass}`}
          style={{
            paddingLeft: `${readerSettings.bookMarginPx}px`,
            paddingRight: `${readerSettings.bookMarginPx}px`,
            fontSize: `${readerSettings.bookFontSize}px`,
            lineHeight: readerSettings.bookLineHeight,
            textAlign: readerSettings.bookTextAlign,
            color: themeStyles.proseColor,
          }}
        >
          <h2 className="font-display-serif text-2xl sm:text-3xl font-semibold mb-8 pb-4 border-b border-current/15">
            {currentChapter?.title}
          </h2>
          <div className="space-y-6">
            {paragraphs.map((p, idx) => (
              <p key={idx} className="whitespace-pre-line">
                {renderHighlightedParagraph(p)}
              </p>
            ))}
          </div>
        </article>
      </main>

      {/* Bottom Chapter Navigation */}
      <footer className={`h-14 px-4 sm:px-8 border-t flex items-center justify-between shrink-0 ${themeStyles.bar}`}>
        <button
          type="button"
          disabled={chapterIndex === 0}
          onClick={() => setChapterIndex((c) => Math.max(0, c - 1))}
          className="inline-flex items-center gap-1.5 text-xs font-medium px-3 py-2 rounded-lg border border-current/15 disabled:opacity-35 cursor-pointer"
        >
          <ChevronLeft className="w-4 h-4" />
          <span>Capítulo anterior</span>
        </button>

        <span className={`text-xs font-mono-nums ${themeStyles.muted}`}>
          Cap. {chapterIndex + 1} de {work.chapters.length}
        </span>

        <button
          type="button"
          disabled={chapterIndex >= work.chapters.length - 1}
          onClick={() => setChapterIndex((c) => Math.min(work.chapters.length - 1, c + 1))}
          className="inline-flex items-center gap-1.5 text-xs font-medium px-3 py-2 rounded-lg border border-current/15 disabled:opacity-35 cursor-pointer"
        >
          <span>Próximo capítulo</span>
          <ChevronRight className="w-4 h-4" />
        </button>
      </footer>
    </div>
  );
};
