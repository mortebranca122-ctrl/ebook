import React, { useState } from 'react';
import {
  ArchiveRestore,
  BookOpen,
  Clock,
  Download,
  FolderHeart,
  HardDrive,
  Heart,
  Home,
  Palette,
  Search,
  Settings,
  Shield,
  User,
  X,
} from 'lucide-react';
import type { NavSection } from '../types/ebookfy';
import { RoseEmblem } from './RoseEmblem';

interface MobileNavProps {
  activeSection: NavSection;
  onSelect: (section: NavSection) => void;
  onOpenSearch: () => void;
}

export const MobileHeader: React.FC<{
  activeSection: NavSection;
  onSelect: (section: NavSection) => void;
  onOpenSearch: () => void;
}> = ({ activeSection, onSelect, onOpenSearch }) => {
  if (activeSection === 'inicio') {
    return (
      <header className="lg:hidden relative overflow-hidden border-b border-red-900/25">
        <img
          src="/src/assets/images/hero_dark_romance_1794861267461.jpg"
          alt=""
          aria-hidden="true"
          className="absolute inset-0 w-full h-full object-cover object-right opacity-35"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-[#070406]/70 via-[#070406]/80 to-[#070406]" />
        <div className="relative px-4 pt-2 pb-3.5">
          <div className="flex items-center justify-end gap-1.5">
            <button
              type="button"
              onClick={onOpenSearch}
              aria-label="Pesquisar na biblioteca"
              className="min-w-[44px] min-h-[44px] flex items-center justify-center rounded-xl text-[#e5d5da] hover:bg-white/10 transition-colors"
            >
              <Search className="w-5 h-5" />
            </button>
            <button
              type="button"
              onClick={() => onSelect('configuracoes')}
              aria-label="Configurações"
              className="min-w-[44px] min-h-[44px] flex items-center justify-center rounded-xl text-[#e5d5da] hover:bg-white/10 transition-colors"
            >
              <Settings className="w-5 h-5" />
            </button>
          </div>

          <div className="flex flex-col items-center text-center -mt-1">
            <RoseEmblem className="w-11 h-11 mb-0.5 drop-shadow-[0_0_16px_rgba(225,29,72,0.65)]" />
            <h1 className="font-display-serif italic text-4xl font-semibold tracking-tight text-white">
              Ebookfy
            </h1>
            <p className="text-xs text-[#cbb8be] mt-0.5">
              Sua biblioteca. Seus arquivos.
            </p>
          </div>
        </div>
      </header>
    );
  }

  return (
    <header className="lg:hidden sticky top-0 z-30 h-14 px-4 flex items-center justify-between bg-[#0b0508]/95 backdrop-blur-md border-b border-red-900/25">
      <button
        type="button"
        onClick={() => onSelect('inicio')}
        className="flex items-center gap-2 min-h-[44px]"
      >
        <RoseEmblem className="w-6 h-6" />
        <span className="font-display-serif italic text-2xl font-semibold text-white">Ebookfy</span>
      </button>
      <div className="flex items-center gap-1">
        <button
          type="button"
          onClick={onOpenSearch}
          aria-label="Pesquisar"
          className="min-w-[44px] min-h-[44px] flex items-center justify-center rounded-lg text-[#d8c4ca]"
        >
          <Search className="w-5 h-5" />
        </button>
        <button
          type="button"
          onClick={() => onSelect('importar')}
          aria-label="Importar arquivos"
          className="min-w-[44px] min-h-[44px] flex items-center justify-center rounded-lg text-red-400"
        >
          <Download className="w-5 h-5" />
        </button>
      </div>
    </header>
  );
};

export const MobileBottomNav: React.FC<MobileNavProps> = ({
  activeSection,
  onSelect,
}) => {
  const [menuOpen, setMenuOpen] = useState(false);

  const isMenuSection = [
    'colecoes',
    'importar',
    'armazenamento',
    'backup',
    'personalizacao',
    'seguranca',
    'configuracoes',
  ].includes(activeSection);

  const tabs: Array<{
    id: NavSection | 'perfil';
    label: string;
    icon: React.ComponentType<{ className?: string }>;
  }> = [
    { id: 'inicio', label: 'Início', icon: Home },
    { id: 'biblioteca', label: 'Biblioteca', icon: BookOpen },
    { id: 'favoritos', label: 'Favoritos', icon: Heart },
    { id: 'historico', label: 'Histórico', icon: Clock },
    { id: 'perfil', label: 'Perfil', icon: User },
  ];

  const drawerItems: Array<{
    id: NavSection;
    label: string;
    icon: React.ComponentType<{ className?: string }>;
  }> = [
    { id: 'importar', label: 'Importar Obras & ZIPs', icon: Download },
    { id: 'colecoes', label: 'Coleções Personalizadas', icon: FolderHeart },
    { id: 'armazenamento', label: 'Armazenamento Local', icon: HardDrive },
    { id: 'backup', label: 'Backup & Restore (.zip)', icon: ArchiveRestore },
    { id: 'personalizacao', label: 'Personalização & Temas', icon: Palette },
    { id: 'seguranca', label: 'Segurança & Senha', icon: Shield },
    { id: 'configuracoes', label: 'Configurações & App', icon: Settings },
  ];

  return (
    <>
      {menuOpen && (
        <div
          className="lg:hidden fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-end"
          onClick={() => setMenuOpen(false)}
        >
          <div
            className="w-full bg-[#12080c] border-t border-red-900/35 rounded-t-3xl p-5 pb-8"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="w-10 h-1 bg-red-900/50 rounded-full mx-auto mb-4" />
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <RoseEmblem className="w-6 h-6" />
                <span className="text-base font-semibold text-white">Menu Ebookfy</span>
              </div>
              <button
                type="button"
                onClick={() => setMenuOpen(false)}
                aria-label="Fechar menu"
                className="min-w-[44px] min-h-[44px] flex items-center justify-center rounded-xl text-[#bfa9b0]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="grid grid-cols-1 gap-1.5">
              {drawerItems.map((item) => {
                const Icon = item.icon;
                const active = activeSection === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => {
                      onSelect(item.id);
                      setMenuOpen(false);
                    }}
                    className={`min-h-[48px] px-4 rounded-xl flex items-center gap-3 text-sm font-medium transition-colors ${
                      active
                        ? 'bg-red-900/30 border border-red-700/40 text-white'
                        : 'bg-white/[0.03] text-[#d5c2c8] hover:bg-white/[0.06]'
                    }`}
                  >
                    <Icon className="w-4 h-4 text-red-400" />
                    <span>{item.label}</span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}

      <nav
        aria-label="Navegação inferior"
        className="lg:hidden fixed bottom-0 left-0 right-0 z-40 h-16 bg-[#0b0508]/95 backdrop-blur-md border-t border-red-900/25 grid grid-cols-5 items-center"
      >
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const active = tab.id === 'perfil' ? isMenuSection || menuOpen : activeSection === tab.id;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => {
                if (tab.id === 'perfil') {
                  setMenuOpen(true);
                } else {
                  setMenuOpen(false);
                  onSelect(tab.id);
                }
              }}
              aria-current={active ? 'page' : undefined}
              className={`min-h-[48px] flex flex-col items-center justify-center gap-1 text-[11px] font-medium transition-colors ${
                active ? 'text-red-500' : 'text-[#9d8189]'
              }`}
            >
              <Icon className="w-5 h-5" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </nav>
    </>
  );
};
