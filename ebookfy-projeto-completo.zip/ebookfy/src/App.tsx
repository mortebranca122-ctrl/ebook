import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  ArrowLeft,
  FolderPlus,
  Palette,
  Search,
  SlidersHorizontal,
  X,
} from 'lucide-react';
import type {
  CategoryType,
  Collection,
  HistoryEntry,
  NavSection,
  ReaderSettings,
  ReadingProgress,
  SecuritySettings,
  ThemeSettings,
  Work,
} from './types/ebookfy';
import {
  addHistoryEntry,
  clearHistory,
  DEFAULT_READER_SETTINGS,
  DEFAULT_SECURITY_SETTINGS,
  DEFAULT_THEME_SETTINGS,
  deleteBinaryBlob,
  deleteCollection,
  deleteWork,
  getAllCollections,
  getAllHistory,
  getAllProgress,
  getAllStoredBlobStats,
  getAllWorks,
  getSetting,
  saveCollection,
  saveProgress,
  saveSetting,
  saveWork,
} from './services/db';
import { createStarterSeedData } from './services/seedData';
import { applyThemeToDocument } from './services/themes';
import { Sidebar } from './components/Sidebar';
import { MobileBottomNav, MobileHeader } from './components/MobileNav';
import { HomeView } from './components/HomeView';
import { LibraryView } from './components/LibraryView';
import { WorkDetailView } from './components/WorkDetailView';
import { ImportView } from './components/ImportView';
import {
  CollectionsView,
  FavoritesView,
  HistoryView,
} from './components/CollectionsAndActivityView';
import { StorageView } from './components/StorageView';
import { BackupView } from './components/BackupView';
import { PersonalizationView } from './components/PersonalizationView';
import { SecurityView, SettingsView } from './components/SecurityAndSettingsView';
import { LockScreen } from './components/LockScreen';
import { ImageReader } from './components/readers/ImageReader';
import { BookReader } from './components/readers/BookReader';
import { PdfReader } from './components/readers/PdfReader';

const SEED_FLAG_KEY = 'ebookfy_seeded_v1';

export default function App() {
  const [loading, setLoading] = useState(true);
  const [activeSection, setActiveSection] = useState<NavSection>('inicio');
  const [selectedCategory, setSelectedCategory] = useState<CategoryType | 'Todas'>('Todas');
  const [searchQuery, setSearchQuery] = useState('');
  const [mobileSearchOpen, setMobileSearchOpen] = useState(false);

  const [works, setWorks] = useState<Work[]>([]);
  const [progressList, setProgressList] = useState<ReadingProgress[]>([]);
  const [collections, setCollections] = useState<Collection[]>([]);
  const [history, setHistory] = useState<HistoryEntry[]>([]);

  const [themeSettings, setThemeSettings] = useState<ThemeSettings>(DEFAULT_THEME_SETTINGS);
  const [readerSettings, setReaderSettings] = useState<ReaderSettings>(DEFAULT_READER_SETTINGS);
  const [securitySettings, setSecuritySettings] = useState<SecuritySettings>(DEFAULT_SECURITY_SETTINGS);
  const [isLocked, setIsLocked] = useState(false);

  const [detailWorkId, setDetailWorkId] = useState<string | null>(null);
  const [activeReader, setActiveReader] = useState<{
    workId: string;
    chapterIndex?: number;
  } | null>(null);

  const [storageUsedBytes, setStorageUsedBytes] = useState(0);
  const [storageQuotaBytes, setStorageQuotaBytes] = useState(8 * 1024 * 1024 * 1024);

  const refreshStorageEstimate = useCallback(async (currentWorks?: Work[]) => {
    try {
      const blobStats = await getAllStoredBlobStats();
      const workList = currentWorks ?? works;
      const sampleEstimate = workList
        .filter((w) => w.isSample)
        .reduce((sum, w) => sum + w.totalSizeBytes, 0);

      let used = blobStats.totalBytes + sampleEstimate;
      let quota = 8 * 1024 * 1024 * 1024;

      if (navigator.storage && 'estimate' in navigator.storage) {
        const est = await navigator.storage.estimate();
        if (est.usage && est.usage > used) used = est.usage;
        if (est.quota && est.quota > 0) quota = Math.min(est.quota, 64 * 1024 * 1024 * 1024);
      }

      setStorageUsedBytes(used);
      setStorageQuotaBytes(quota);
    } catch {
      // ignore storage estimate failure
    }
  }, [works]);

  // Initial local database boot
  useEffect(() => {
    let mounted = true;
    async function boot() {
      try {
        let [w, p, c, h, t, r, s] = await Promise.all([
          getAllWorks(),
          getAllProgress(),
          getAllCollections(),
          getAllHistory(),
          getSetting<ThemeSettings>('theme', DEFAULT_THEME_SETTINGS),
          getSetting<ReaderSettings>('reader', DEFAULT_READER_SETTINGS),
          getSetting<SecuritySettings>('security', DEFAULT_SECURITY_SETTINGS),
        ]);

        if (w.length === 0 && !localStorage.getItem(SEED_FLAG_KEY)) {
          const seed = createStarterSeedData();
          await Promise.all([
            ...seed.works.map((item) => saveWork(item)),
            ...seed.progress.map((item) => saveProgress(item)),
            ...seed.collections.map((item) => saveCollection(item)),
            ...seed.history.map((item) => addHistoryEntry(item)),
          ]);
          localStorage.setItem(SEED_FLAG_KEY, '1');
          w = seed.works;
          p = seed.progress;
          c = seed.collections;
          h = seed.history;
        }

        if (!mounted) return;
        setWorks(w);
        setProgressList(p);
        setCollections(c);
        setHistory(h);
        setThemeSettings(t);
        setReaderSettings(r);
        setSecuritySettings(s);
        applyThemeToDocument(t);
        if (s.lockEnabled && s.passwordHash) {
          setIsLocked(true);
        }
        await refreshStorageEstimate(w);
      } finally {
        if (mounted) setLoading(false);
      }
    }
    boot();
    return () => {
      mounted = false;
    };
  }, []);

  // Apply live theme changes
  useEffect(() => {
    applyThemeToDocument(themeSettings);
  }, [themeSettings]);

  // Inactivity lock timer
  const lastActivityRef = useRef(Date.now());
  useEffect(() => {
    if (!securitySettings.lockEnabled || securitySettings.inactivityMinutes <= 0) return;
    const bump = () => {
      lastActivityRef.current = Date.now();
    };
    window.addEventListener('pointerdown', bump);
    window.addEventListener('keydown', bump);
    const interval = window.setInterval(() => {
      const idleMs = Date.now() - lastActivityRef.current;
      if (idleMs > securitySettings.inactivityMinutes * 60_000) {
        setIsLocked(true);
      }
    }, 15_000);
    return () => {
      window.removeEventListener('pointerdown', bump);
      window.removeEventListener('keydown', bump);
      window.clearInterval(interval);
    };
  }, [securitySettings.lockEnabled, securitySettings.inactivityMinutes]);

  const progressMap = useMemo(() => {
    const map = new Map<string, ReadingProgress>();
    for (const p of progressList) map.set(p.workId, p);
    return map;
  }, [progressList]);

  const navigate = (section: NavSection, cat?: CategoryType) => {
    setDetailWorkId(null);
    setActiveSection(section);
    if (cat) setSelectedCategory(cat);
    else if (section === 'biblioteca' && !cat) {
      // keep current category
    }
  };

  const handleUpdateTheme = async (next: ThemeSettings) => {
    setThemeSettings(next);
    await saveSetting('theme', next);
  };

  const handleUpdateReaderSettings = async (next: ReaderSettings) => {
    setReaderSettings(next);
    await saveSetting('reader', next);
  };

  const handleUpdateSecurity = async (next: SecuritySettings) => {
    setSecuritySettings(next);
    await saveSetting('security', next);
  };

  const handleOpenReader = async (work: Work, chapterIndex?: number) => {
    const now = Date.now();
    const updatedWork = { ...work, lastReadAt: now };
    setWorks((prev) => prev.map((w) => (w.id === work.id ? updatedWork : w)));
    await saveWork(updatedWork);

    const existingProg = progressMap.get(work.id);
    const cIdx = chapterIndex ?? existingProg?.chapterIndex ?? 0;
    const ch = work.chapters[cIdx] ?? work.chapters[0];
    if (ch) {
      const entry: HistoryEntry = {
        id: `hist-${work.id}-${now}`,
        workId: work.id,
        workTitle: work.title,
        coverUrl: work.coverUrl,
        category: work.category,
        chapterId: ch.id,
        chapterTitle: ch.title,
        pageIndex: existingProg?.pageIndex ?? 0,
        percentage: existingProg?.percentage ?? 0,
        timestamp: now,
      };
      setHistory((prev) => [entry, ...prev.filter((h) => h.workId !== work.id)].slice(0, 60));
      await addHistoryEntry(entry);
    }

    setActiveReader({ workId: work.id, chapterIndex });
  };

  const handleSaveProgress = useCallback(
    async (
      workId: string,
      update: {
        chapterIndex: number;
        pageIndex: number;
        scrollRatio: number;
        percentage: number;
        completedChapter?: boolean;
      }
    ) => {
      const targetWork = works.find((w) => w.id === workId);
      if (!targetWork) return;
      const ch = targetWork.chapters[update.chapterIndex] ?? targetWork.chapters[0];
      if (!ch) return;

      setProgressList((prev) => {
        const existing = prev.find((p) => p.workId === workId);
        const completedSet = new Set(existing?.completedChapterIds ?? []);
        if (update.completedChapter) completedSet.add(ch.id);

        const nextProg: ReadingProgress = {
          workId,
          chapterId: ch.id,
          chapterIndex: update.chapterIndex,
          pageIndex: update.pageIndex,
          scrollRatio: update.scrollRatio,
          percentage: update.percentage,
          status: update.percentage >= 100 ? 'concluido' : 'em_andamento',
          completedChapterIds: Array.from(completedSet),
          bookmarks: existing?.bookmarks ?? [],
          updatedAt: Date.now(),
        };

        saveProgress(nextProg).catch(() => {});
        const filtered = prev.filter((p) => p.workId !== workId);
        return [nextProg, ...filtered];
      });
    },
    [works]
  );

  const handleAddBookmark = useCallback(
    async (workId: string, chapterIndex: number, pageIndex: number, scrollRatio: number) => {
      const targetWork = works.find((w) => w.id === workId);
      const ch = targetWork?.chapters[chapterIndex];
      if (!targetWork || !ch) return;

      setProgressList((prev) => {
        const existing = prev.find((p) => p.workId === workId);
        const bm = {
          id: `bm-${crypto.randomUUID()}`,
          workId,
          chapterId: ch.id,
          chapterTitle: ch.title,
          pageIndex,
          scrollRatio,
          createdAt: Date.now(),
        };
        const nextProg: ReadingProgress = existing
          ? { ...existing, bookmarks: [bm, ...existing.bookmarks], updatedAt: Date.now() }
          : {
              workId,
              chapterId: ch.id,
              chapterIndex,
              pageIndex,
              scrollRatio,
              percentage: 1,
              status: 'em_andamento',
              completedChapterIds: [],
              bookmarks: [bm],
              updatedAt: Date.now(),
            };
        saveProgress(nextProg).catch(() => {});
        return [nextProg, ...prev.filter((p) => p.workId !== workId)];
      });
    },
    [works]
  );

  const handleToggleFavorite = async (workId: string) => {
    const target = works.find((w) => w.id === workId);
    if (!target) return;
    const updated = { ...target, isFavorite: !target.isFavorite, updatedAt: Date.now() };
    setWorks((prev) => prev.map((w) => (w.id === workId ? updated : w)));
    await saveWork(updated);
  };

  const handleUpdateWork = async (updated: Work) => {
    setWorks((prev) => prev.map((w) => (w.id === updated.id ? updated : w)));
    await saveWork(updated);
  };

  const handleDeleteWorks = async (workIds: string[], deleteBlobs: boolean) => {
    const idSet = new Set(workIds);
    const targets = works.filter((w) => idSet.has(w.id));

    for (const w of targets) {
      if (deleteBlobs) {
        if (w.archiveBlobKey) await deleteBinaryBlob(w.archiveBlobKey);
        for (const ch of w.chapters) {
          for (const p of ch.pages) {
            if (p.blobKey) await deleteBinaryBlob(p.blobKey);
          }
        }
      }
      await deleteWork(w.id);
    }

    const nextWorks = works.filter((w) => !idSet.has(w.id));
    setWorks(nextWorks);
    setProgressList((prev) => prev.filter((p) => !idSet.has(p.workId)));
    if (detailWorkId && idSet.has(detailWorkId)) setDetailWorkId(null);
    await refreshStorageEstimate(nextWorks);
  };

  const handleResetProgress = async (workId: string) => {
    const target = works.find((w) => w.id === workId);
    if (!target || target.chapters.length === 0) return;
    const reset: ReadingProgress = {
      workId,
      chapterId: target.chapters[0].id,
      chapterIndex: 0,
      pageIndex: 0,
      scrollRatio: 0,
      percentage: 0,
      status: 'nao_iniciado',
      completedChapterIds: [],
      bookmarks: progressMap.get(workId)?.bookmarks ?? [],
      updatedAt: Date.now(),
    };
    setProgressList((prev) => [reset, ...prev.filter((p) => p.workId !== workId)]);
    await saveProgress(reset);
  };

  const handleImportComplete = async (imported: Work[]) => {
    for (const w of imported) {
      await saveWork(w);
    }
    const next = [...imported, ...works];
    setWorks(next);
    await refreshStorageEstimate(next);
  };

  const handleCreateCollection = async (name: string, description: string) => {
    const col: Collection = {
      id: `col-${crypto.randomUUID()}`,
      name,
      description,
      workIds: [],
      createdAt: Date.now(),
    };
    setCollections((prev) => [col, ...prev]);
    await saveCollection(col);
  };

  const handleDeleteCollection = async (id: string) => {
    setCollections((prev) => prev.filter((c) => c.id !== id));
    await deleteCollection(id);
  };

  const handleAddWorksToCollection = async (collectionId: string, workIds: string[]) => {
    const target = collections.find((c) => c.id === collectionId);
    if (!target) return;
    const merged = Array.from(new Set([...target.workIds, ...workIds]));
    const updated = { ...target, workIds: merged };
    setCollections((prev) => prev.map((c) => (c.id === collectionId ? updated : c)));
    await saveCollection(updated);
  };

  const handleRestoreComplete = async (data: {
    works: Work[];
    progress: ReadingProgress[];
    collections: Collection[];
    history: HistoryEntry[];
    themeSettings?: ThemeSettings;
    readerSettings?: ReaderSettings;
    mode: 'merge' | 'overwrite';
  }) => {
    let nextWorks = data.works;
    let nextProgress = data.progress;
    let nextCollections = data.collections;

    if (data.mode === 'merge') {
      const byId = new Map<string, Work>();
      works.forEach((w) => byId.set(w.id, w));
      data.works.forEach((w) => byId.set(w.id, w));
      nextWorks = Array.from(byId.values());

      const pById = new Map<string, ReadingProgress>();
      progressList.forEach((p) => pById.set(p.workId, p));
      data.progress.forEach((p) => pById.set(p.workId, p));
      nextProgress = Array.from(pById.values());

      const cById = new Map<string, Collection>();
      collections.forEach((c) => cById.set(c.id, c));
      data.collections.forEach((c) => cById.set(c.id, c));
      nextCollections = Array.from(cById.values());
    }

    await Promise.all([
      ...nextWorks.map((w) => saveWork(w)),
      ...nextProgress.map((p) => saveProgress(p)),
      ...nextCollections.map((c) => saveCollection(c)),
    ]);

    setWorks(nextWorks);
    setProgressList(nextProgress);
    setCollections(nextCollections);
    if (data.themeSettings) await handleUpdateTheme(data.themeSettings);
    if (data.readerSettings) await handleUpdateReaderSettings(data.readerSettings);
    await refreshStorageEstimate(nextWorks);
  };

  const handleClearSamplesOnly = async () => {
    const sampleIds = works.filter((w) => w.isSample).map((w) => w.id);
    if (sampleIds.length > 0) {
      await handleDeleteWorks(sampleIds, false);
    }
    localStorage.setItem(SEED_FLAG_KEY, '1');
  };

  const handleResetSamples = async () => {
    const seed = createStarterSeedData();
    const nonSamples = works.filter((w) => !w.isSample);
    await Promise.all([
      ...seed.works.map((w) => saveWork(w)),
      ...seed.progress.map((p) => saveProgress(p)),
    ]);
    const combined = [...seed.works, ...nonSamples];
    setWorks(combined);
    setProgressList((prev) => {
      const map = new Map(prev.map((p) => [p.workId, p]));
      seed.progress.forEach((p) => map.set(p.workId, p));
      return Array.from(map.values());
    });
    await refreshStorageEstimate(combined);
  };

  const detailWork = detailWorkId ? works.find((w) => w.id === detailWorkId) ?? null : null;
  const readingWork = activeReader ? works.find((w) => w.id === activeReader.workId) ?? null : null;

  if (loading) {
    return (
      <div className="min-h-screen bg-[#070406] flex items-center justify-center text-sm text-[#bfa9b0]">
        Carregando biblioteca local Ebookfy...
      </div>
    );
  }

  return (
    <div
      className="min-h-screen flex flex-col lg:flex-row relative"
      style={{
        backgroundColor: 'var(--eb-bg-canvas)',
        backgroundImage: themeSettings.wallpaperDataUrl
          ? `linear-gradient(rgba(7,4,6,0.82), rgba(7,4,6,0.9)), url(${themeSettings.wallpaperDataUrl})`
          : undefined,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundAttachment: 'fixed',
      }}
    >
      {/* Lock Screen */}
      {isLocked && (
        <LockScreen
          security={securitySettings}
          onUnlock={() => {
            lastActivityRef.current = Date.now();
            setIsLocked(false);
          }}
          onDisableViaRecovery={() =>
            handleUpdateSecurity({
              ...securitySettings,
              lockEnabled: false,
              passwordHash: null,
              passwordSalt: null,
              recoveryCodeHash: null,
            })
          }
        />
      )}

      {/* Specialized Fullscreen Readers */}
      {readingWork && activeReader && (
        <>
          {readingWork.readerMode === 'book' ? (
            <BookReader
              work={readingWork}
              initialProgress={progressMap.get(readingWork.id)}
              initialChapterIndex={activeReader.chapterIndex}
              readerSettings={readerSettings}
              onUpdateReaderSettings={handleUpdateReaderSettings}
              onSaveProgress={(u) => handleSaveProgress(readingWork.id, u)}
              onAddBookmark={(cIdx, pIdx, sr) => handleAddBookmark(readingWork.id, cIdx, pIdx, sr)}
              onClose={() => setActiveReader(null)}
            />
          ) : readingWork.readerMode === 'pdf' ? (
            <PdfReader
              work={readingWork}
              initialProgress={progressMap.get(readingWork.id)}
              readerSettings={readerSettings}
              onUpdateReaderSettings={handleUpdateReaderSettings}
              onSaveProgress={(u) => handleSaveProgress(readingWork.id, u)}
              onAddBookmark={(cIdx, pIdx, sr) => handleAddBookmark(readingWork.id, cIdx, pIdx, sr)}
              onClose={() => setActiveReader(null)}
            />
          ) : (
            <ImageReader
              work={readingWork}
              initialProgress={progressMap.get(readingWork.id)}
              initialChapterIndex={activeReader.chapterIndex}
              readerSettings={readerSettings}
              onUpdateReaderSettings={handleUpdateReaderSettings}
              onSaveProgress={(u) => handleSaveProgress(readingWork.id, u)}
              onAddBookmark={(cIdx, pIdx, sr) => handleAddBookmark(readingWork.id, cIdx, pIdx, sr)}
              onClose={() => setActiveReader(null)}
            />
          )}
        </>
      )}

      {/* Desktop Sidebar */}
      <Sidebar activeSection={activeSection} onSelect={(s) => navigate(s)} />

      {/* Mobile Header */}
      <MobileHeader
        activeSection={activeSection}
        onSelect={(s) => navigate(s)}
        onOpenSearch={() => setMobileSearchOpen(true)}
      />

      {/* Mobile Search Overlay */}
      {mobileSearchOpen && (
        <div className="lg:hidden fixed inset-x-0 top-0 z-50 bg-[#0b0508] border-b border-red-900/40 p-3 flex items-center gap-2">
          <Search className="w-4 h-4 text-[#9d8189] ml-1" />
          <input
            type="search"
            autoFocus
            value={searchQuery}
            onChange={(e) => {
              setSearchQuery(e.target.value);
              if (activeSection !== 'biblioteca') navigate('biblioteca');
            }}
            placeholder="Pesquisar na sua biblioteca..."
            className="flex-1 bg-transparent text-sm text-white focus:outline-none"
          />
          <button
            type="button"
            onClick={() => setMobileSearchOpen(false)}
            aria-label="Fechar pesquisa"
            className="min-w-[40px] min-h-[40px] flex items-center justify-center text-[#d4c0c6]"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      )}

      {/* Main Content Area */}
      <div className="flex-1 min-w-0 flex flex-col">
        {/* Desktop Top Search & Action Bar */}
        <div className="hidden lg:flex items-center justify-between gap-4 px-6 pt-4 pb-2">
          <div className="flex items-center gap-3 flex-1 max-w-xl">
            <button
              type="button"
              onClick={() => {
                if (detailWork) setDetailWorkId(null);
                else navigate('inicio');
              }}
              aria-label="Voltar"
              className="p-2 rounded-lg text-[#bfa9b0] hover:text-white hover:bg-white/[0.05] transition-colors cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>

            <div className="relative flex-1">
              <Search className="w-4 h-4 text-[#9d8189] absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="search"
                aria-label="Pesquisar na sua biblioteca"
                value={searchQuery}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  if (e.target.value.trim() && activeSection === 'inicio') {
                    setActiveSection('biblioteca');
                  }
                }}
                placeholder="Pesquisar na sua biblioteca..."
                className="w-full pl-10 pr-4 py-2 rounded-full bg-[#12080c]/90 border border-red-900/30 text-xs text-white placeholder-[#846a72] focus:outline-none focus:border-red-600/60"
              />
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => navigate('biblioteca')}
              aria-label="Filtrar biblioteca"
              title="Filtrar biblioteca"
              className="p-2.5 rounded-xl bg-white/[0.03] border border-white/10 text-[#d4c0c6] hover:text-white hover:border-red-800/50 cursor-pointer"
            >
              <SlidersHorizontal className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={() => navigate('importar')}
              aria-label="Importar arquivos"
              title="Importar arquivos"
              className="p-2.5 rounded-xl bg-white/[0.03] border border-white/10 text-[#d4c0c6] hover:text-white hover:border-red-800/50 cursor-pointer"
            >
              <FolderPlus className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={() => navigate('personalizacao')}
              aria-label="Personalizar aparência"
              title="Personalizar aparência"
              className="p-2.5 rounded-xl bg-white/[0.03] border border-white/10 text-[#d4c0c6] hover:text-white hover:border-red-800/50 cursor-pointer"
            >
              <Palette className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Dynamic Viewport Content */}
        <main className="flex-1 px-4 sm:px-6 pt-3 pb-24 lg:pb-8 max-w-[1440px] w-full mx-auto">
          {detailWork ? (
            <WorkDetailView
              work={detailWork}
              progress={progressMap.get(detailWork.id)}
              onBack={() => setDetailWorkId(null)}
              onOpenReader={handleOpenReader}
              onToggleFavorite={handleToggleFavorite}
              onResetProgress={handleResetProgress}
              onUpdateWork={handleUpdateWork}
            />
          ) : activeSection === 'inicio' ? (
            <HomeView
              works={works}
              progressMap={progressMap}
              theme={themeSettings}
              storageUsedBytes={storageUsedBytes}
              storageQuotaBytes={storageQuotaBytes}
              onContinueWork={(w) => handleOpenReader(w)}
              onOpenWorkDetails={(w) => setDetailWorkId(w.id)}
              onNavigate={navigate}
            />
          ) : activeSection === 'biblioteca' ? (
            <LibraryView
              works={works}
              progressMap={progressMap}
              collections={collections}
              searchQuery={searchQuery}
              selectedCategory={selectedCategory}
              viewMode={themeSettings.libraryViewMode}
              onChangeCategory={setSelectedCategory}
              onChangeViewMode={(m) => handleUpdateTheme({ ...themeSettings, libraryViewMode: m })}
              onOpenWorkDetails={(w) => setDetailWorkId(w.id)}
              onContinueWork={(w) => handleOpenReader(w)}
              onToggleFavorite={handleToggleFavorite}
              onDeleteWorks={handleDeleteWorks}
              onAddWorksToCollection={handleAddWorksToCollection}
              onUpdateWorkMeta={handleUpdateWork}
              onGoToImport={() => navigate('importar')}
            />
          ) : activeSection === 'favoritos' ? (
            <FavoritesView
              works={works}
              progressMap={progressMap}
              onOpenWork={(w) => setDetailWorkId(w.id)}
              onContinueWork={(w) => handleOpenReader(w)}
              onToggleFavorite={handleToggleFavorite}
            />
          ) : activeSection === 'historico' ? (
            <HistoryView
              history={history}
              works={works}
              onContinueWork={(w) => handleOpenReader(w)}
              onClearHistory={async () => {
                setHistory([]);
                await clearHistory();
              }}
            />
          ) : activeSection === 'colecoes' ? (
            <CollectionsView
              collections={collections}
              works={works}
              onCreateCollection={handleCreateCollection}
              onDeleteCollection={handleDeleteCollection}
              onOpenWork={(w) => setDetailWorkId(w.id)}
            />
          ) : activeSection === 'importar' ? (
            <ImportView
              existingWorks={works}
              onImportComplete={handleImportComplete}
              onOpenWork={(w) => {
                setActiveSection('biblioteca');
                setDetailWorkId(w.id);
              }}
            />
          ) : activeSection === 'armazenamento' ? (
            <StorageView
              works={works}
              storageUsedBytes={storageUsedBytes}
              storageQuotaBytes={storageQuotaBytes}
              onDeleteWorks={handleDeleteWorks}
              onRefreshEstimate={() => refreshStorageEstimate()}
            />
          ) : activeSection === 'backup' ? (
            <BackupView
              works={works}
              progress={progressList}
              collections={collections}
              history={history}
              themeSettings={themeSettings}
              readerSettings={readerSettings}
              onRestoreComplete={handleRestoreComplete}
            />
          ) : activeSection === 'personalizacao' ? (
            <PersonalizationView theme={themeSettings} onUpdateTheme={handleUpdateTheme} />
          ) : activeSection === 'seguranca' ? (
            <SecurityView
              security={securitySettings}
              onUpdateSecurity={handleUpdateSecurity}
              onLockNow={() => setIsLocked(true)}
            />
          ) : (
            <SettingsView
              readerSettings={readerSettings}
              onUpdateReaderSettings={handleUpdateReaderSettings}
              onResetSamples={handleResetSamples}
              onClearSamplesOnly={handleClearSamplesOnly}
            />
          )}
        </main>
      </div>

      {/* Mobile Fixed Bottom Navigation */}
      <MobileBottomNav
        activeSection={activeSection}
        onSelect={(s) => navigate(s)}
        onOpenSearch={() => setMobileSearchOpen(true)}
      />
    </div>
  );
}
