import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  ArrowLeft,
  Bookmark,
  ChevronLeft,
  ChevronRight,
  Columns2,
  Maximize2,
  Minimize2,
  Moon,
  SlidersHorizontal,
  Square,
  Sun,
  ZoomIn,
  ZoomOut,
} from 'lucide-react';
import type {
  PageRef,
  ReaderSettings,
  ReadingProgress,
  Work,
} from '../../types/ebookfy';
import { loadPageImageUrl } from '../../services/pageLoader';

interface ImageReaderProps {
  work: Work;
  initialProgress?: ReadingProgress;
  initialChapterIndex?: number;
  readerSettings: ReaderSettings;
  onUpdateReaderSettings: (next: ReaderSettings) => void;
  onSaveProgress: (update: {
    chapterIndex: number;
    pageIndex: number;
    scrollRatio: number;
    percentage: number;
    completedChapter?: boolean;
  }) => void;
  onAddBookmark: (chapterIndex: number, pageIndex: number, scrollRatio: number) => void;
  onClose: () => void;
}

const LazyPageImage: React.FC<{
  page: PageRef;
  className?: string;
  style?: React.CSSProperties;
  alt: string;
}> = ({ page, className, style, alt }) => {
  const [src, setSrc] = useState<string | null>(page.inlineUrl ?? null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let active = true;
    if (page.inlineUrl) {
      setSrc(page.inlineUrl);
      setError(null);
      return;
    }
    loadPageImageUrl(page)
      .then((url) => {
        if (active) {
          setSrc(url);
          setError(null);
        }
      })
      .catch((err) => {
        if (active) setError(err instanceof Error ? err.message : 'Erro ao carregar página');
      });
    return () => {
      active = false;
    };
  }, [page]);

  if (error) {
    return (
      <div className="w-full min-h-[260px] flex flex-col items-center justify-center bg-[#12080c] border border-red-900/40 rounded-lg p-6 text-center text-xs text-red-300">
        <p className="font-semibold">Falha ao decodificar página {page.pageNumber}</p>
        <p className="text-[#9d8189] mt-1">{error}</p>
      </div>
    );
  }

  if (!src) {
    return (
      <div className="w-full min-h-[420px] flex items-center justify-center bg-[#0d0709] animate-pulse text-xs text-[#846a72]">
        Carregando página {page.pageNumber}...
      </div>
    );
  }

  return <img src={src} alt={alt} className={className} style={style} loading="lazy" />;
};

export const ImageReader: React.FC<ImageReaderProps> = ({
  work,
  initialProgress,
  initialChapterIndex,
  readerSettings,
  onUpdateReaderSettings,
  onSaveProgress,
  onAddBookmark,
  onClose,
}) => {
  const isVerticalMode = work.readerMode === 'manhwa' || work.category === 'Webtoons' || work.category === 'Manhwas';
  const [chapterIndex, setChapterIndex] = useState<number>(() => {
    if (typeof initialChapterIndex === 'number') return Math.max(0, Math.min(work.chapters.length - 1, initialChapterIndex));
    return Math.max(0, Math.min(work.chapters.length - 1, initialProgress?.chapterIndex ?? 0));
  });
  const [pageIndex, setPageIndex] = useState<number>(() => initialProgress?.pageIndex ?? 0);
  const [zoom, setZoom] = useState<number>(1);
  const [showControls, setShowControls] = useState<boolean>(true);
  const [showSettings, setShowSettings] = useState<boolean>(false);
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);
  const [bookmarkToast, setBookmarkToast] = useState<boolean>(false);

  const verticalContainerRef = useRef<HTMLDivElement | null>(null);
  const currentChapter = work.chapters[chapterIndex];
  const pages = currentChapter?.pages ?? [];

  const computeOverallPercentage = useCallback(
    (cIdx: number, pIdx: number, scrollRatio = 0) => {
      if (work.chapters.length === 0) return 0;
      const chapterFrac =
        pages.length > 0
          ? isVerticalMode
            ? Math.max(0, Math.min(1, scrollRatio))
            : (pIdx + 1) / pages.length
          : 1;
      const pct = ((cIdx + chapterFrac) / work.chapters.length) * 100;
      return Math.max(1, Math.min(100, Math.round(pct)));
    },
    [work.chapters.length, pages.length, isVerticalMode]
  );

  // Preload adjacent pages lazily
  useEffect(() => {
    const count = readerSettings.preloadCount;
    for (let offset = 1; offset <= count; offset++) {
      const next = pages[pageIndex + offset];
      if (next && !next.inlineUrl) {
        loadPageImageUrl(next).catch(() => {});
      }
      const prev = pages[pageIndex - offset];
      if (prev && !prev.inlineUrl) {
        loadPageImageUrl(prev).catch(() => {});
      }
    }
  }, [pageIndex, pages, readerSettings.preloadCount]);

  // Persist page progress in paged mode
  useEffect(() => {
    if (isVerticalMode || pages.length === 0) return;
    const isLast = pageIndex >= pages.length - 1;
    onSaveProgress({
      chapterIndex,
      pageIndex,
      scrollRatio: (pageIndex + 1) / pages.length,
      percentage: computeOverallPercentage(chapterIndex, pageIndex),
      completedChapter: isLast,
    });
  }, [chapterIndex, pageIndex, isVerticalMode, pages.length, computeOverallPercentage, onSaveProgress]);

  // Restore scroll ratio in vertical manhwa/webtoon mode
  useEffect(() => {
    if (!isVerticalMode) return;
    const el = verticalContainerRef.current;
    if (!el) return;
    const targetRatio =
      initialProgress && initialProgress.chapterIndex === chapterIndex ? initialProgress.scrollRatio : 0;
    const timer = window.setTimeout(() => {
      const maxScroll = Math.max(0, el.scrollHeight - el.clientHeight);
      el.scrollTop = Math.round(maxScroll * targetRatio);
    }, 120);
    return () => window.clearTimeout(timer);
  }, [chapterIndex, isVerticalMode, initialProgress]);

  const handleVerticalScroll = useCallback(() => {
    const el = verticalContainerRef.current;
    if (!el) return;
    const maxScroll = Math.max(1, el.scrollHeight - el.clientHeight);
    const ratio = Math.max(0, Math.min(1, el.scrollTop / maxScroll));
    const approxPage = Math.min(pages.length - 1, Math.floor(ratio * pages.length));
    setPageIndex(approxPage);
    onSaveProgress({
      chapterIndex,
      pageIndex: approxPage,
      scrollRatio: ratio,
      percentage: computeOverallPercentage(chapterIndex, approxPage, ratio),
      completedChapter: ratio >= 0.92,
    });
  }, [chapterIndex, pages.length, computeOverallPercentage, onSaveProgress]);

  const stepAmount = readerSettings.mangaPageLayout === 'double' && !isVerticalMode ? 2 : 1;

  const goNext = useCallback(() => {
    if (isVerticalMode) {
      if (chapterIndex < work.chapters.length - 1) {
        setChapterIndex((c) => c + 1);
        setPageIndex(0);
      }
      return;
    }
    if (pageIndex + stepAmount < pages.length) {
      setPageIndex((p) => p + stepAmount);
    } else if (chapterIndex < work.chapters.length - 1) {
      setChapterIndex((c) => c + 1);
      setPageIndex(0);
    }
  }, [isVerticalMode, chapterIndex, work.chapters.length, pageIndex, stepAmount, pages.length]);

  const goPrev = useCallback(() => {
    if (isVerticalMode) {
      if (chapterIndex > 0) {
        setChapterIndex((c) => c - 1);
        setPageIndex(0);
      }
      return;
    }
    if (pageIndex - stepAmount >= 0) {
      setPageIndex((p) => p - stepAmount);
    } else if (chapterIndex > 0) {
      const prevChap = work.chapters[chapterIndex - 1];
      setChapterIndex((c) => c - 1);
      setPageIndex(Math.max(0, (prevChap?.pages.length ?? 1) - 1));
    }
  }, [isVerticalMode, chapterIndex, pageIndex, stepAmount, work.chapters]);

  const toggleFullscreen = useCallback(async () => {
    try {
      if (!document.fullscreenElement) {
        await document.documentElement.requestFullscreen();
        setIsFullscreen(true);
      } else {
        await document.exitFullscreen();
        setIsFullscreen(false);
      }
    } catch {
      // Fullscreen may be blocked in embedded frames
    }
  }, []);

  // Keyboard shortcuts for desktop Windows reading
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        if (showSettings) setShowSettings(false);
        else onClose();
      } else if (e.key === 'f' || e.key === 'F') {
        toggleFullscreen();
      } else if (!isVerticalMode) {
        const isRtl = readerSettings.mangaDirection === 'rtl';
        if (e.key === 'ArrowRight') {
          isRtl ? goPrev() : goNext();
        } else if (e.key === 'ArrowLeft') {
          isRtl ? goNext() : goPrev();
        } else if (e.key === ' ') {
          e.preventDefault();
          goNext();
        }
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [isVerticalMode, readerSettings.mangaDirection, goNext, goPrev, onClose, showSettings, toggleFullscreen]);

  const bgClass = useMemo(() => {
    if (readerSettings.imageBgMode === 'light') return 'bg-[#f4f1ed] text-neutral-900';
    if (readerSettings.imageBgMode === 'dark') return 'bg-[#0e080b] text-white';
    return 'bg-[#000000] text-white';
  }, [readerSettings.imageBgMode]);

  const visiblePages = useMemo(() => {
    if (isVerticalMode) return pages;
    if (readerSettings.mangaPageLayout === 'double' && pages[pageIndex + 1]) {
      const pair = [pages[pageIndex], pages[pageIndex + 1]];
      return readerSettings.mangaDirection === 'rtl' ? [pair[1], pair[0]] : pair;
    }
    return pages[pageIndex] ? [pages[pageIndex]] : [];
  }, [isVerticalMode, pages, pageIndex, readerSettings.mangaPageLayout, readerSettings.mangaDirection]);

  const imageFitStyle: React.CSSProperties = useMemo(() => {
    if (isVerticalMode) {
      return {
        width: `${Math.round(zoom * 100)}%`,
        maxWidth: `${Math.round(readerSettings.webtoonMaxWidthPx * zoom)}px`,
        height: 'auto',
      };
    }
    switch (readerSettings.imageFitMode) {
      case 'height':
        return { height: `${Math.round(84 * zoom)}vh`, width: 'auto', maxWidth: '100%' };
      case 'original':
        return { width: 'auto', height: 'auto', transform: `scale(${zoom})`, transformOrigin: 'center' };
      case 'screen':
        return { maxHeight: `${Math.round(86 * zoom)}vh`, maxWidth: `${Math.round(94 * zoom)}%`, objectFit: 'contain' };
      case 'width':
      default:
        return { width: `${Math.round(Math.min(100, 92 * zoom))}%`, maxWidth: '1000px', height: 'auto' };
    }
  }, [isVerticalMode, zoom, readerSettings.webtoonMaxWidthPx, readerSettings.imageFitMode]);

  const handleTapOverlay = (e: React.MouseEvent<HTMLDivElement>) => {
    if (isVerticalMode) {
      setShowControls((s) => !s);
      return;
    }
    const rect = e.currentTarget.getBoundingClientRect();
    const xRatio = (e.clientX - rect.left) / rect.width;
    const isRtl = readerSettings.mangaDirection === 'rtl';
    if (xRatio < 0.28) {
      isRtl ? goNext() : goPrev();
    } else if (xRatio > 0.72) {
      isRtl ? goPrev() : goNext();
    } else {
      setShowControls((s) => !s);
    }
  };

  return (
    <div
      data-testid="image-reader"
      className={`fixed inset-0 z-50 flex flex-col select-none ${bgClass}`}
    >
      {/* Floating Top Bar */}
      <header
        className={`fixed top-0 inset-x-0 z-30 transition-all duration-200 bg-gradient-to-b from-black/90 via-black/70 to-transparent px-3 sm:px-6 py-3 flex items-center justify-between gap-3 ${
          showControls ? 'opacity-100 translate-y-0' : 'opacity-0 -translate-y-4 pointer-events-none'
        }`}
      >
        <div className="flex items-center gap-2.5 min-w-0">
          <button
            type="button"
            onClick={onClose}
            aria-label="Sair do leitor"
            className="min-w-[40px] min-h-[40px] rounded-xl bg-black/70 border border-red-900/40 text-white hover:bg-red-950/60 flex items-center justify-center cursor-pointer shrink-0"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>

          <div className="min-w-0">
            <h1 className="text-sm font-semibold text-white truncate">{work.title}</h1>
            <div className="flex items-center gap-2 mt-0.5">
              <select
                aria-label="Selecionar capítulo"
                value={chapterIndex}
                onChange={(e) => {
                  setChapterIndex(Number(e.target.value));
                  setPageIndex(0);
                }}
                className="bg-[#160a0e] border border-red-900/45 text-xs text-[#f5ebee] rounded-md px-2 py-1 focus:outline-none focus:border-red-500 cursor-pointer"
              >
                {work.chapters.map((ch, idx) => (
                  <option key={ch.id} value={idx}>
                    {ch.title}
                  </option>
                ))}
              </select>
              <span className="text-xs font-mono-nums text-[#cbb8be] whitespace-nowrap">
                {pages.length > 0 ? `${pageIndex + 1} / ${pages.length}` : '0 / 0'}
              </span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-1.5 shrink-0">
          <button
            type="button"
            onClick={() => {
              onAddBookmark(chapterIndex, pageIndex, (pageIndex + 1) / Math.max(1, pages.length));
              setBookmarkToast(true);
              setTimeout(() => setBookmarkToast(false), 1800);
            }}
            aria-label="Adicionar marcador"
            className="min-w-[40px] min-h-[40px] rounded-xl bg-black/70 border border-white/15 text-white hover:border-red-500/60 flex items-center justify-center cursor-pointer"
          >
            <Bookmark className="w-4 h-4" />
          </button>

          <button
            type="button"
            onClick={() =>
              onUpdateReaderSettings({
                ...readerSettings,
                imageBgMode: readerSettings.imageBgMode === 'light' ? 'pure-black' : 'light',
              })
            }
            aria-label="Alternar fundo claro ou escuro"
            title={readerSettings.imageBgMode === 'light' ? 'Fundo Escuro' : 'Fundo Claro'}
            className="min-w-[40px] min-h-[40px] rounded-xl bg-black/70 border border-white/15 text-white hover:border-red-500/60 flex items-center justify-center cursor-pointer"
          >
            {readerSettings.imageBgMode === 'light' ? (
              <Moon className="w-4 h-4" />
            ) : (
              <Sun className="w-4 h-4" />
            )}
          </button>

          <button
            type="button"
            onClick={() => setShowSettings((s) => !s)}
            aria-label="Configurações do leitor"
            className="min-w-[40px] min-h-[40px] rounded-xl bg-black/70 border border-white/15 text-white hover:border-red-500/60 flex items-center justify-center cursor-pointer"
          >
            <SlidersHorizontal className="w-4 h-4" />
          </button>

          <button
            type="button"
            onClick={toggleFullscreen}
            aria-label="Alternar tela cheia"
            className="hidden sm:flex min-w-[40px] min-h-[40px] rounded-xl bg-black/70 border border-white/15 text-white hover:border-red-500/60 items-center justify-center cursor-pointer"
          >
            {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </button>
        </div>
      </header>

      {bookmarkToast && (
        <div className="fixed top-16 right-4 z-40 px-3.5 py-2 rounded-lg bg-[#19090e] border border-red-700/60 text-xs text-white shadow-lg">
          Marcador salvo em {currentChapter?.title} · Pág. {pageIndex + 1}
        </div>
      )}

      {/* Settings Drawer */}
      {showSettings && (
        <div className="fixed top-16 right-4 z-40 w-80 max-w-[calc(100vw-2rem)] bg-[#12080c]/95 backdrop-blur-md border border-red-900/45 rounded-2xl p-4 shadow-2xl text-white space-y-3.5">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-semibold">Opções do Leitor</h2>
            <button
              type="button"
              onClick={() => setShowSettings(false)}
              className="text-xs text-[#bfa9b0] hover:text-white cursor-pointer"
            >
              Fechar
            </button>
          </div>

          <div className="space-y-1.5">
            <span className="text-xs text-[#bfa9b0]">Fundo da leitura</span>
            <div className="grid grid-cols-3 gap-1.5">
              {[
                { id: 'pure-black', label: 'Preto' },
                { id: 'dark', label: 'Vinho' },
                { id: 'light', label: 'Claro' },
              ].map((opt) => (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() =>
                    onUpdateReaderSettings({
                      ...readerSettings,
                      imageBgMode: opt.id as ReaderSettings['imageBgMode'],
                    })
                  }
                  className={`py-1.5 rounded-lg text-xs font-medium border cursor-pointer ${
                    readerSettings.imageBgMode === opt.id
                      ? 'bg-red-800/45 border-red-500 text-white'
                      : 'bg-white/[0.04] border-white/10 text-[#cbb8be]'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          {!isVerticalMode ? (
            <>
              <div className="space-y-1.5">
                <span className="text-xs text-[#bfa9b0]">Direção de leitura</span>
                <div className="grid grid-cols-2 gap-1.5">
                  <button
                    type="button"
                    onClick={() => onUpdateReaderSettings({ ...readerSettings, mangaDirection: 'rtl' })}
                    className={`py-1.5 rounded-lg text-xs font-medium border cursor-pointer ${
                      readerSettings.mangaDirection === 'rtl'
                        ? 'bg-red-800/45 border-red-500 text-white'
                        : 'bg-white/[0.04] border-white/10 text-[#cbb8be]'
                    }`}
                  >
                    Direita → Esquerda
                  </button>
                  <button
                    type="button"
                    onClick={() => onUpdateReaderSettings({ ...readerSettings, mangaDirection: 'ltr' })}
                    className={`py-1.5 rounded-lg text-xs font-medium border cursor-pointer ${
                      readerSettings.mangaDirection === 'ltr'
                        ? 'bg-red-800/45 border-red-500 text-white'
                        : 'bg-white/[0.04] border-white/10 text-[#cbb8be]'
                    }`}
                  >
                    Esquerda → Direita
                  </button>
                </div>
              </div>

              <div className="space-y-1.5">
                <span className="text-xs text-[#bfa9b0]">Disposição de página</span>
                <div className="grid grid-cols-2 gap-1.5">
                  <button
                    type="button"
                    onClick={() => onUpdateReaderSettings({ ...readerSettings, mangaPageLayout: 'single' })}
                    className={`py-1.5 rounded-lg text-xs font-medium border inline-flex items-center justify-center gap-1.5 cursor-pointer ${
                      readerSettings.mangaPageLayout === 'single'
                        ? 'bg-red-800/45 border-red-500 text-white'
                        : 'bg-white/[0.04] border-white/10 text-[#cbb8be]'
                    }`}
                  >
                    <Square className="w-3.5 h-3.5" />
                    <span>Página única</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => onUpdateReaderSettings({ ...readerSettings, mangaPageLayout: 'double' })}
                    className={`py-1.5 rounded-lg text-xs font-medium border inline-flex items-center justify-center gap-1.5 cursor-pointer ${
                      readerSettings.mangaPageLayout === 'double'
                        ? 'bg-red-800/45 border-red-500 text-white'
                        : 'bg-white/[0.04] border-white/10 text-[#cbb8be]'
                    }`}
                  >
                    <Columns2 className="w-3.5 h-3.5" />
                    <span>Página dupla</span>
                  </button>
                </div>
              </div>

              <div className="space-y-1.5">
                <span className="text-xs text-[#bfa9b0]">Ajuste à tela</span>
                <div className="grid grid-cols-2 gap-1.5">
                  {[
                    { id: 'width', label: 'Largura' },
                    { id: 'height', label: 'Altura' },
                    { id: 'screen', label: 'Tela' },
                    { id: 'original', label: 'Original' },
                  ].map((fit) => (
                    <button
                      key={fit.id}
                      type="button"
                      onClick={() =>
                        onUpdateReaderSettings({
                          ...readerSettings,
                          imageFitMode: fit.id as ReaderSettings['imageFitMode'],
                        })
                      }
                      className={`py-1.5 rounded-lg text-xs font-medium border cursor-pointer ${
                        readerSettings.imageFitMode === fit.id
                          ? 'bg-red-800/45 border-red-500 text-white'
                          : 'bg-white/[0.04] border-white/10 text-[#cbb8be]'
                      }`}
                    >
                      {fit.label}
                    </button>
                  ))}
                </div>
              </div>
            </>
          ) : (
            <>
              <div className="space-y-1">
                <div className="flex justify-between text-xs text-[#bfa9b0]">
                  <span>Espaçamento entre painéis</span>
                  <span className="font-mono-nums">{readerSettings.webtoonGapPx}px</span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={32}
                  step={4}
                  value={readerSettings.webtoonGapPx}
                  onChange={(e) =>
                    onUpdateReaderSettings({
                      ...readerSettings,
                      webtoonMaxWidthPx: readerSettings.webtoonMaxWidthPx,
                      webtoonGapPx: Number(e.target.value),
                    })
                  }
                  className="w-full accent-red-600"
                />
              </div>
              <div className="space-y-1">
                <div className="flex justify-between text-xs text-[#bfa9b0]">
                  <span>Largura da faixa</span>
                  <span className="font-mono-nums">{readerSettings.webtoonMaxWidthPx}px</span>
                </div>
                <input
                  type="range"
                  min={520}
                  max={1100}
                  step={40}
                  value={readerSettings.webtoonMaxWidthPx}
                  onChange={(e) =>
                    onUpdateReaderSettings({
                      ...readerSettings,
                      webtoonMaxWidthPx: Number(e.target.value),
                    })
                  }
                  className="w-full accent-red-600"
                />
              </div>
            </>
          )}

          <div className="flex items-center justify-between pt-1 border-t border-white/10">
            <span className="text-xs text-[#bfa9b0]">Zoom ({Math.round(zoom * 100)}%)</span>
            <div className="flex items-center gap-1.5">
              <button
                type="button"
                onClick={() => setZoom((z) => Math.max(0.5, Number((z - 0.15).toFixed(2))))}
                aria-label="Diminuir zoom"
                className="p-1.5 rounded-lg bg-white/[0.06] hover:bg-white/10 cursor-pointer"
              >
                <ZoomOut className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => setZoom(1)}
                className="px-2 py-1 rounded-lg bg-white/[0.06] text-xs font-mono-nums cursor-pointer"
              >
                100%
              </button>
              <button
                type="button"
                onClick={() => setZoom((z) => Math.min(2.5, Number((z + 0.15).toFixed(2))))}
                aria-label="Aumentar zoom"
                className="p-1.5 rounded-lg bg-white/[0.06] hover:bg-white/10 cursor-pointer"
              >
                <ZoomIn className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Viewport Content */}
      {isVerticalMode ? (
        <div
          ref={verticalContainerRef}
          onScroll={handleVerticalScroll}
          onClick={handleTapOverlay}
          className="flex-1 overflow-y-auto pt-14 pb-20 flex flex-col items-center"
        >
          <div
            className="w-full flex flex-col items-center"
            style={{ gap: `${readerSettings.webtoonGapPx}px` }}
          >
            {pages.map((p) => (
              <LazyPageImage
                key={p.id}
                page={p}
                alt={`${work.title} - ${currentChapter?.title} - Página ${p.pageNumber}`}
                style={imageFitStyle}
                className="block select-none"
              />
            ))}
          </div>

          <div className="mt-8 mb-6 flex items-center gap-3">
            <button
              type="button"
              disabled={chapterIndex === 0}
              onClick={(e) => {
                e.stopPropagation();
                goPrev();
              }}
              className="px-4 py-2.5 rounded-xl bg-[#160a0e] border border-red-900/45 text-xs font-medium text-white disabled:opacity-40 cursor-pointer"
            >
              Capítulo anterior
            </button>
            <button
              type="button"
              disabled={chapterIndex >= work.chapters.length - 1}
              onClick={(e) => {
                e.stopPropagation();
                goNext();
              }}
              className="eb-accent-btn px-5 py-2.5 rounded-xl text-xs font-semibold disabled:opacity-40 cursor-pointer"
            >
              Próximo capítulo
            </button>
          </div>
        </div>
      ) : (
        <div
          onClick={handleTapOverlay}
          className="flex-1 overflow-auto flex items-center justify-center p-2 sm:p-6 pt-16 pb-20"
        >
          <div className="flex items-center justify-center gap-2 max-w-full">
            {visiblePages.map((p) => (
              <LazyPageImage
                key={p.id}
                page={p}
                alt={`${work.title} - Página ${p.pageNumber}`}
                style={imageFitStyle}
                className="rounded-sm shadow-2xl object-contain"
              />
            ))}
          </div>
        </div>
      )}

      {/* Floating Bottom Progress Bar */}
      <footer
        className={`fixed bottom-0 inset-x-0 z-30 transition-all duration-200 bg-gradient-to-t from-black/95 via-black/75 to-transparent px-4 sm:px-8 py-3 ${
          showControls ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4 pointer-events-none'
        }`}
      >
        <div className="max-w-3xl mx-auto flex items-center gap-3">
          <button
            type="button"
            onClick={goPrev}
            aria-label="Página ou capítulo anterior"
            className="min-w-[40px] min-h-[40px] rounded-xl bg-black/70 border border-white/15 text-white hover:border-red-500/60 flex items-center justify-center cursor-pointer"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>

          <input
            type="range"
            aria-label="Navegar páginas"
            min={0}
            max={Math.max(0, pages.length - 1)}
            value={pageIndex}
            onChange={(e) => {
              const target = Number(e.target.value);
              setPageIndex(target);
              if (isVerticalMode && verticalContainerRef.current && pages.length > 0) {
                const maxScroll = Math.max(
                  0,
                  verticalContainerRef.current.scrollHeight - verticalContainerRef.current.clientHeight
                );
                verticalContainerRef.current.scrollTop = Math.round(
                  (target / Math.max(1, pages.length - 1)) * maxScroll
                );
              }
            }}
            className="flex-1 accent-red-600 cursor-pointer"
          />

          <span className="text-xs font-mono-nums text-[#e5d5da] min-w-[60px] text-center">
            {pageIndex + 1} / {Math.max(1, pages.length)}
          </span>

          <button
            type="button"
            onClick={goNext}
            aria-label="Próxima página ou capítulo"
            className="min-w-[40px] min-h-[40px] rounded-xl bg-black/70 border border-white/15 text-white hover:border-red-500/60 flex items-center justify-center cursor-pointer"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </footer>
    </div>
  );
};
